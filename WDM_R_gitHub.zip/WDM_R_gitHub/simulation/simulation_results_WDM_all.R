load("./simulation/simulation_scenarios_WDM_all.RData")
load("./simulation/simulation_intermediate_WDM_all.RData")
#############################
#### Simulation Analysis ####
#############################
####No relevance####
#small sd
sig_runs_norelev.smallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_norelev.smallsd[i]<-Est_norelev.smallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_norelev.smallsd)

#msmall sd
sig_runs_norelev.msmallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_norelev.msmallsd[i]<-Est_norelev.msmallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_norelev.msmallsd)


#medium sd
sig_runs_norelev.mediumsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_norelev.mediumsd[i]<-Est_norelev.mediumsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_norelev.mediumsd)


#lmarge sd
sig_runs_norelev.mlargesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_norelev.mlargesd[i]<-Est_norelev.mlargesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_norelev.mlargesd)


#large sd
sig_runs_norelev.largesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_norelev.largesd[i]<-Est_norelev.largesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_norelev.largesd)


####smalljump####
#small sd
sig_runs_smalljump.smallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_smalljump.smallsd[i]<-Est_smalljump.smallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_smalljump.smallsd)

Time_frames_smalljump.smallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_smalljump.smallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_smalljump.smallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_smalljump.smallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_smalljump.smallsd<-rbind(Time_frames_smalljump.smallsd,as.numeric(tf))
  }
}
Time_frames_smalljump.smallsd<-Time_frames_smalljump.smallsd[-1,]

sum(ifelse(is.na(Time_frames_smalljump.smallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_smalljump.smallsd[,3])==F,1,0))
sum(sig_runs_smalljump.smallsd)-sum(ifelse(is.na(Time_frames_smalljump.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.smallsd[,3])==F,1,0))


Time_frames_smalljump.smallsd_na<-Time_frames_smalljump.smallsd[-c(which(is.na(Time_frames_smalljump.smallsd[,2])==T), which(is.na(Time_frames_smalljump.smallsd[,3])==F)),]
mean(Time_frames_smalljump.smallsd_na[,1])
var(Time_frames_smalljump.smallsd_na[,1])
mean(Time_frames_smalljump.smallsd_na[,2])
var(Time_frames_smalljump.smallsd_na[,2])



#msmall sd
sig_runs_smalljump.msmallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_smalljump.msmallsd[i]<-Est_smalljump.msmallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_smalljump.msmallsd)

Time_frames_smalljump.msmallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_smalljump.msmallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_smalljump.msmallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_smalljump.msmallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_smalljump.msmallsd<-rbind(Time_frames_smalljump.msmallsd,as.numeric(tf))
  }
}
Time_frames_smalljump.msmallsd<-Time_frames_smalljump.msmallsd[-1,]

sum(ifelse(is.na(Time_frames_smalljump.msmallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_smalljump.msmallsd[,3])==F,1,0))
sum(sig_runs_smalljump.msmallsd)-sum(ifelse(is.na(Time_frames_smalljump.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.msmallsd[,3])==F,1,0))


Time_frames_smalljump.msmallsd_na<-Time_frames_smalljump.msmallsd[-c(which(is.na(Time_frames_smalljump.msmallsd[,2])==T), which(is.na(Time_frames_smalljump.msmallsd[,3])==F)),]
mean(Time_frames_smalljump.msmallsd_na[,1])
var(Time_frames_smalljump.msmallsd_na[,1])
mean(Time_frames_smalljump.msmallsd_na[,2])
var(Time_frames_smalljump.msmallsd_na[,2])



#medium sd
sig_runs_smalljump.mediumsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_smalljump.mediumsd[i]<-Est_smalljump.mediumsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_smalljump.mediumsd)


Time_frames_smalljump.mediumsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_smalljump.mediumsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_smalljump.mediumsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_smalljump.mediumsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_smalljump.mediumsd<-rbind(Time_frames_smalljump.mediumsd,as.numeric(tf))
  }
}
Time_frames_smalljump.mediumsd<-Time_frames_smalljump.mediumsd[-1,]

sum(ifelse(is.na(Time_frames_smalljump.mediumsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_smalljump.mediumsd[,3])==F,1,0))
sum(sig_runs_smalljump.mediumsd)-sum(ifelse(is.na(Time_frames_smalljump.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.mediumsd[,3])==F,1,0))


Time_frames_smalljump.mediumsd_na<-Time_frames_smalljump.mediumsd[-c(which(is.na(Time_frames_smalljump.mediumsd[,2])==T), which(is.na(Time_frames_smalljump.mediumsd[,3])==F)),]
mean(Time_frames_smalljump.mediumsd_na[,1])
var(Time_frames_smalljump.mediumsd_na[,1])
mean(Time_frames_smalljump.mediumsd_na[,2])
var(Time_frames_smalljump.mediumsd_na[,2])


#mlarge sd
sig_runs_smalljump.mlargesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_smalljump.mlargesd[i]<-Est_smalljump.mlargesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_smalljump.mlargesd)


Time_frames_smalljump.mlargesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_smalljump.mlargesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_smalljump.mlargesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_smalljump.mlargesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_smalljump.mlargesd<-rbind(Time_frames_smalljump.mlargesd,as.numeric(tf))
  }
}
Time_frames_smalljump.mlargesd<-Time_frames_smalljump.mlargesd[-1,]

sum(ifelse(is.na(Time_frames_smalljump.mlargesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_smalljump.mlargesd[,3])==F,1,0))
sum(sig_runs_smalljump.mlargesd)-sum(ifelse(is.na(Time_frames_smalljump.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.mlargesd[,3])==F,1,0))


Time_frames_smalljump.mlargesd_na<-Time_frames_smalljump.mlargesd[-c(which(is.na(Time_frames_smalljump.mlargesd[,2])==T), which(is.na(Time_frames_smalljump.mlargesd[,3])==F)),]
mean(Time_frames_smalljump.mlargesd_na[,1])
var(Time_frames_smalljump.mlargesd_na[,1])
mean(Time_frames_smalljump.mlargesd_na[,2])
var(Time_frames_smalljump.mlargesd_na[,2])



#large sd
sig_runs_smalljump.largesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_smalljump.largesd[i]<-Est_smalljump.largesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_smalljump.largesd)


Time_frames_smalljump.largesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_smalljump.largesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_smalljump.largesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_smalljump.largesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_smalljump.largesd<-rbind(Time_frames_smalljump.largesd,as.numeric(tf))
  }
}
Time_frames_smalljump.largesd<-Time_frames_smalljump.largesd[-1,]

sum(ifelse(is.na(Time_frames_smalljump.largesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_smalljump.largesd[,3])==F,1,0))
sum(sig_runs_smalljump.largesd)-sum(ifelse(is.na(Time_frames_smalljump.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.largesd[,3])==F,1,0))


Time_frames_smalljump.largesd_na<-Time_frames_smalljump.largesd[-c(which(is.na(Time_frames_smalljump.largesd[,2])==T), which(is.na(Time_frames_smalljump.largesd[,3])==F)),]
mean(Time_frames_smalljump.largesd_na[,1])
var(Time_frames_smalljump.largesd_na[,1])
mean(Time_frames_smalljump.largesd_na[,2])
var(Time_frames_smalljump.largesd_na[,2])


####Wider####
#small sd
sig_runs_wider.smallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_wider.smallsd[i]<-Est_wider.smallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_wider.smallsd)

Time_frames_wider.smallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_wider.smallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_wider.smallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_wider.smallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_wider.smallsd<-rbind(Time_frames_wider.smallsd,as.numeric(tf))
  }
}
Time_frames_wider.smallsd<-Time_frames_wider.smallsd[-1,]

sum(ifelse(is.na(Time_frames_wider.smallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_wider.smallsd[,3])==F,1,0))
sum(sig_runs_wider.smallsd)-sum(ifelse(is.na(Time_frames_wider.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.smallsd[,3])==F,1,0))


Time_frames_wider.smallsd_na<-Time_frames_wider.smallsd[-c(which(is.na(Time_frames_wider.smallsd[,2])==T), which(is.na(Time_frames_wider.smallsd[,3])==F)),]
mean(Time_frames_wider.smallsd_na[,1])
var(Time_frames_wider.smallsd_na[,1])
mean(Time_frames_wider.smallsd_na[,2])
var(Time_frames_wider.smallsd_na[,2])


#msmall sd
sig_runs_wider.msmallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_wider.msmallsd[i]<-Est_wider.msmallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_wider.msmallsd)

Time_frames_wider.msmallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_wider.msmallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_wider.msmallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_wider.msmallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_wider.msmallsd<-rbind(Time_frames_wider.msmallsd,as.numeric(tf))
  }
}
Time_frames_wider.msmallsd<-Time_frames_wider.msmallsd[-1,]

sum(ifelse(is.na(Time_frames_wider.msmallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_wider.msmallsd[,3])==F,1,0))
sum(sig_runs_wider.msmallsd)-sum(ifelse(is.na(Time_frames_wider.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.msmallsd[,3])==F,1,0))


Time_frames_wider.msmallsd_na<-Time_frames_wider.msmallsd[-c(which(is.na(Time_frames_wider.msmallsd[,2])==T), which(is.na(Time_frames_wider.msmallsd[,3])==F)),]
mean(Time_frames_wider.msmallsd_na[,1])
var(Time_frames_wider.msmallsd_na[,1])
mean(Time_frames_wider.msmallsd_na[,2])
var(Time_frames_wider.msmallsd_na[,2])


#medium sd
sig_runs_wider.mediumsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_wider.mediumsd[i]<-Est_wider.mediumsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_wider.mediumsd)

Time_frames_wider.mediumsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_wider.mediumsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_wider.mediumsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_wider.mediumsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_wider.mediumsd<-rbind(Time_frames_wider.mediumsd,as.numeric(tf))
  }
}
Time_frames_wider.mediumsd<-Time_frames_wider.mediumsd[-1,]

sum(ifelse(is.na(Time_frames_wider.mediumsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_wider.mediumsd[,3])==F,1,0))
sum(sig_runs_wider.mediumsd)-sum(ifelse(is.na(Time_frames_wider.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.mediumsd[,3])==F,1,0))


Time_frames_wider.mediumsd_na<-Time_frames_wider.mediumsd[-c(which(is.na(Time_frames_wider.mediumsd[,2])==T), which(is.na(Time_frames_wider.mediumsd[,3])==F)),]
mean(Time_frames_wider.mediumsd_na[,1])
var(Time_frames_wider.mediumsd_na[,1])
mean(Time_frames_wider.mediumsd_na[,2])
var(Time_frames_wider.mediumsd_na[,2])


#mlarge sd
sig_runs_wider.mlargesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_wider.mlargesd[i]<-Est_wider.mlargesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_wider.mlargesd)

Time_frames_wider.mlargesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_wider.mlargesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_wider.mlargesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_wider.mlargesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_wider.mlargesd<-rbind(Time_frames_wider.mlargesd,as.numeric(tf))
  }
}
Time_frames_wider.mlargesd<-Time_frames_wider.mlargesd[-1,]

sum(ifelse(is.na(Time_frames_wider.mlargesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_wider.mlargesd[,3])==F,1,0))
sum(sig_runs_wider.mlargesd)-sum(ifelse(is.na(Time_frames_wider.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.mlargesd[,3])==F,1,0))


Time_frames_wider.mlargesd_na<-Time_frames_wider.mlargesd[-c(which(is.na(Time_frames_wider.mlargesd[,2])==T), which(is.na(Time_frames_wider.mlargesd[,3])==F)),]
mean(Time_frames_wider.mlargesd_na[,1])
var(Time_frames_wider.mlargesd_na[,1])
mean(Time_frames_wider.mlargesd_na[,2])
var(Time_frames_wider.mlargesd_na[,2])


#large sd
sig_runs_wider.largesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_wider.largesd[i]<-Est_wider.largesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_wider.largesd)

Time_frames_wider.largesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_wider.largesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_wider.largesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_wider.largesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_wider.largesd<-rbind(Time_frames_wider.largesd,as.numeric(tf))
  }
}
Time_frames_wider.largesd<-Time_frames_wider.largesd[-1,]

sum(ifelse(is.na(Time_frames_wider.largesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_wider.largesd[,3])==F,1,0))
sum(sig_runs_wider.largesd)-sum(ifelse(is.na(Time_frames_wider.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.largesd[,3])==F,1,0))


Time_frames_wider.largesd_na<-Time_frames_wider.largesd[-c(which(is.na(Time_frames_wider.largesd[,2])==T), which(is.na(Time_frames_wider.largesd[,3])==F)),]
mean(Time_frames_wider.largesd_na[,1])
var(Time_frames_wider.largesd_na[,1])
mean(Time_frames_wider.largesd_na[,2])
var(Time_frames_wider.largesd_na[,2])

####No Dip####
#small sd
sig_runs_nodip.smallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_nodip.smallsd[i]<-Est_nodip.smallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_nodip.smallsd)


Time_frames_nodip.smallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_nodip.smallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_nodip.smallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_nodip.smallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_nodip.smallsd<-rbind(Time_frames_nodip.smallsd,as.numeric(tf))
  }
}
Time_frames_nodip.smallsd<-Time_frames_nodip.smallsd[-1,]

sum(ifelse(is.na(Time_frames_nodip.smallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_nodip.smallsd[,3])==F,1,0))
sum(sig_runs_nodip.smallsd)-sum(ifelse(is.na(Time_frames_nodip.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.smallsd[,3])==F,1,0))


Time_frames_nodip.smallsd_na<-Time_frames_nodip.smallsd[-c(which(is.na(Time_frames_nodip.smallsd[,2])==T), which(is.na(Time_frames_nodip.smallsd[,3])==F)),]
mean(Time_frames_nodip.smallsd_na[,1])
var(Time_frames_nodip.smallsd_na[,1])
mean(Time_frames_nodip.smallsd_na[,2])
var(Time_frames_nodip.smallsd_na[,2])


#msmall sd
sig_runs_nodip.msmallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_nodip.msmallsd[i]<-Est_nodip.msmallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_nodip.msmallsd)


Time_frames_nodip.msmallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_nodip.msmallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_nodip.msmallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_nodip.msmallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_nodip.msmallsd<-rbind(Time_frames_nodip.msmallsd,as.numeric(tf))
  }
}
Time_frames_nodip.msmallsd<-Time_frames_nodip.msmallsd[-1,]

sum(ifelse(is.na(Time_frames_nodip.msmallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_nodip.msmallsd[,3])==F,1,0))
sum(sig_runs_nodip.msmallsd)-sum(ifelse(is.na(Time_frames_nodip.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.msmallsd[,3])==F,1,0))


Time_frames_nodip.msmallsd_na<-Time_frames_nodip.msmallsd[-c(which(is.na(Time_frames_nodip.msmallsd[,2])==T), which(is.na(Time_frames_nodip.msmallsd[,3])==F)),]
mean(Time_frames_nodip.msmallsd_na[,1])
var(Time_frames_nodip.msmallsd_na[,1])
mean(Time_frames_nodip.msmallsd_na[,2])
var(Time_frames_nodip.msmallsd_na[,2])


#medium sd
sig_runs_nodip.mediumsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_nodip.mediumsd[i]<-Est_nodip.mediumsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_nodip.mediumsd)


Time_frames_nodip.mediumsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_nodip.mediumsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_nodip.mediumsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_nodip.mediumsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_nodip.mediumsd<-rbind(Time_frames_nodip.mediumsd,as.numeric(tf))
  }
}
Time_frames_nodip.mediumsd<-Time_frames_nodip.mediumsd[-1,]

sum(ifelse(is.na(Time_frames_nodip.mediumsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_nodip.mediumsd[,3])==F,1,0))
sum(sig_runs_nodip.mediumsd)-sum(ifelse(is.na(Time_frames_nodip.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.mediumsd[,3])==F,1,0))


Time_frames_nodip.mediumsd_na<-Time_frames_nodip.mediumsd[-c(which(is.na(Time_frames_nodip.mediumsd[,2])==T), which(is.na(Time_frames_nodip.mediumsd[,3])==F)),]
mean(Time_frames_nodip.mediumsd_na[,1])
var(Time_frames_nodip.mediumsd_na[,1])
mean(Time_frames_nodip.mediumsd_na[,2])
var(Time_frames_nodip.mediumsd_na[,2])


#mlarge sd
sig_runs_nodip.mlargesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_nodip.mlargesd[i]<-Est_nodip.mlargesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_nodip.mlargesd)

Time_frames_nodip.mlargesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_nodip.mlargesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_nodip.mlargesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_nodip.mlargesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_nodip.mlargesd<-rbind(Time_frames_nodip.mlargesd,as.numeric(tf))
  }
}
Time_frames_nodip.mlargesd<-Time_frames_nodip.mlargesd[-1,]

sum(ifelse(is.na(Time_frames_nodip.mlargesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_nodip.mlargesd[,3])==F,1,0))
sum(sig_runs_nodip.mlargesd)-sum(ifelse(is.na(Time_frames_nodip.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.mlargesd[,3])==F,1,0))


Time_frames_nodip.mlargesd_na<-Time_frames_nodip.mlargesd[-c(which(is.na(Time_frames_nodip.mlargesd[,2])==T), which(is.na(Time_frames_nodip.mlargesd[,3])==F)),]
mean(Time_frames_nodip.mlargesd_na[,1])
var(Time_frames_nodip.mlargesd_na[,1])
mean(Time_frames_nodip.mlargesd_na[,2])
var(Time_frames_nodip.mlargesd_na[,2])


#large sd
sig_runs_nodip.largesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_nodip.largesd[i]<-Est_nodip.largesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_nodip.largesd)

Time_frames_nodip.largesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_nodip.largesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_nodip.largesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_nodip.largesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_nodip.largesd<-rbind(Time_frames_nodip.largesd,as.numeric(tf))
  }
}
Time_frames_nodip.largesd<-Time_frames_nodip.largesd[-1,]

sum(ifelse(is.na(Time_frames_nodip.largesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_nodip.largesd[,3])==F,1,0))
sum(sig_runs_nodip.largesd)-sum(ifelse(is.na(Time_frames_nodip.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.largesd[,3])==F,1,0))


Time_frames_nodip.largesd_na<-Time_frames_nodip.largesd[-c(which(is.na(Time_frames_nodip.largesd[,2])==T), which(is.na(Time_frames_nodip.largesd[,3])==F)),]
mean(Time_frames_nodip.largesd_na[,1])
var(Time_frames_nodip.largesd_na[,1])
mean(Time_frames_nodip.largesd_na[,2])
var(Time_frames_nodip.largesd_na[,2])

####Dip####
#small sd
sig_runs_dip.smallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip.smallsd[i]<-Est_dip.smallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip.smallsd)

Time_frames_dip.smallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip.smallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip.smallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip.smallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip.smallsd<-rbind(Time_frames_dip.smallsd,as.numeric(tf))
  }
}
Time_frames_dip.smallsd<-Time_frames_dip.smallsd[-1,]

sum(ifelse(is.na(Time_frames_dip.smallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.smallsd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.smallsd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.smallsd[,5])==F,1,0))

sum(sig_runs_dip.smallsd)-sum(ifelse(is.na(Time_frames_dip.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.smallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.smallsd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.smallsd[,5])==F,1,0))


Time_frames_dip.smallsd_na<-Time_frames_dip.smallsd[-c(which(is.na(Time_frames_dip.smallsd[,2])==T), which(is.na(Time_frames_dip.smallsd[,3])==T),which(is.na(Time_frames_dip.smallsd[,4])==T), which(is.na(Time_frames_dip.smallsd[,5])==F)),]
mean(Time_frames_dip.smallsd_na[,1])
var(Time_frames_dip.smallsd_na[,1])
mean(Time_frames_dip.smallsd_na[,2])
var(Time_frames_dip.smallsd_na[,2])
mean(Time_frames_dip.smallsd_na[,3])
var(Time_frames_dip.smallsd_na[,3])
mean(Time_frames_dip.smallsd_na[,4])
var(Time_frames_dip.smallsd_na[,4])


#msmall sd
sig_runs_dip.msmallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip.msmallsd[i]<-Est_dip.msmallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip.msmallsd)

Time_frames_dip.msmallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip.msmallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip.msmallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip.msmallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip.msmallsd<-rbind(Time_frames_dip.msmallsd,as.numeric(tf))
  }
}
Time_frames_dip.msmallsd<-Time_frames_dip.msmallsd[-1,]

sum(ifelse(is.na(Time_frames_dip.msmallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.msmallsd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.msmallsd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.msmallsd[,5])==F,1,0))

sum(sig_runs_dip.msmallsd)-sum(ifelse(is.na(Time_frames_dip.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.msmallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.msmallsd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.msmallsd[,5])==F,1,0))


Time_frames_dip.msmallsd_na<-Time_frames_dip.msmallsd[-c(which(is.na(Time_frames_dip.msmallsd[,2])==T), which(is.na(Time_frames_dip.msmallsd[,3])==T),which(is.na(Time_frames_dip.msmallsd[,4])==T), which(is.na(Time_frames_dip.msmallsd[,5])==F)),]
mean(Time_frames_dip.msmallsd_na[,1])
var(Time_frames_dip.msmallsd_na[,1])
mean(Time_frames_dip.msmallsd_na[,2])
var(Time_frames_dip.msmallsd_na[,2])
mean(Time_frames_dip.msmallsd_na[,3])
var(Time_frames_dip.msmallsd_na[,3])
mean(Time_frames_dip.msmallsd_na[,4])
var(Time_frames_dip.msmallsd_na[,4])



#medium sd
sig_runs_dip.mediumsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip.mediumsd[i]<-Est_dip.mediumsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip.mediumsd)

Time_frames_dip.mediumsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip.mediumsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip.mediumsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip.mediumsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip.mediumsd<-rbind(Time_frames_dip.mediumsd,as.numeric(tf))
  }
}
Time_frames_dip.mediumsd<-Time_frames_dip.mediumsd[-1,]

sum(ifelse(is.na(Time_frames_dip.mediumsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.mediumsd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.mediumsd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.mediumsd[,5])==F,1,0))

sum(sig_runs_dip.mediumsd)-sum(ifelse(is.na(Time_frames_dip.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mediumsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mediumsd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mediumsd[,5])==F,1,0))


Time_frames_dip.mediumsd_na<-Time_frames_dip.mediumsd[-c(which(is.na(Time_frames_dip.mediumsd[,2])==T), which(is.na(Time_frames_dip.mediumsd[,3])==T),which(is.na(Time_frames_dip.mediumsd[,4])==T), which(is.na(Time_frames_dip.mediumsd[,5])==F)),]
mean(Time_frames_dip.mediumsd_na[,1])
var(Time_frames_dip.mediumsd_na[,1])
mean(Time_frames_dip.mediumsd_na[,2])
var(Time_frames_dip.mediumsd_na[,2])
mean(Time_frames_dip.mediumsd_na[,3])
var(Time_frames_dip.mediumsd_na[,3])
mean(Time_frames_dip.mediumsd_na[,4])
var(Time_frames_dip.mediumsd_na[,4])


#mlarge sd
sig_runs_dip.mlargesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip.mlargesd[i]<-Est_dip.mlargesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip.mlargesd)

Time_frames_dip.mlargesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip.mlargesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip.mlargesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip.mlargesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip.mlargesd<-rbind(Time_frames_dip.mlargesd,as.numeric(tf))
  }
}
Time_frames_dip.mlargesd<-Time_frames_dip.mlargesd[-1,]

sum(ifelse(is.na(Time_frames_dip.mlargesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.mlargesd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.mlargesd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.mlargesd[,5])==F,1,0))

sum(sig_runs_dip.mlargesd)-sum(ifelse(is.na(Time_frames_dip.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mlargesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mlargesd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mlargesd[,5])==F,1,0))


Time_frames_dip.mlargesd_na<-Time_frames_dip.mlargesd[-c(which(is.na(Time_frames_dip.mlargesd[,2])==T), which(is.na(Time_frames_dip.mlargesd[,3])==T),which(is.na(Time_frames_dip.mlargesd[,4])==T), which(is.na(Time_frames_dip.mlargesd[,5])==F)),]
mean(Time_frames_dip.mlargesd_na[,1])
var(Time_frames_dip.mlargesd_na[,1])
mean(Time_frames_dip.mlargesd_na[,2])
var(Time_frames_dip.mlargesd_na[,2])
mean(Time_frames_dip.mlargesd_na[,3])
var(Time_frames_dip.mlargesd_na[,3])
mean(Time_frames_dip.mlargesd_na[,4])
var(Time_frames_dip.mlargesd_na[,4])



#large sd
sig_runs_dip.largesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip.largesd[i]<-Est_dip.largesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip.largesd)

Time_frames_dip.largesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip.largesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip.largesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip.largesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip.largesd<-rbind(Time_frames_dip.largesd,as.numeric(tf))
  }
}
Time_frames_dip.largesd<-Time_frames_dip.largesd[-1,]

sum(ifelse(is.na(Time_frames_dip.largesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.largesd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.largesd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip.largesd[,5])==F,1,0))

sum(sig_runs_dip.largesd)-sum(ifelse(is.na(Time_frames_dip.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.largesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.largesd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.largesd[,5])==F,1,0))


Time_frames_dip.largesd_na<-Time_frames_dip.largesd[-c(which(is.na(Time_frames_dip.largesd[,2])==T), which(is.na(Time_frames_dip.largesd[,3])==T),which(is.na(Time_frames_dip.largesd[,4])==T), which(is.na(Time_frames_dip.largesd[,5])==F)),]
mean(Time_frames_dip.largesd_na[,1])
var(Time_frames_dip.largesd_na[,1])
mean(Time_frames_dip.largesd_na[,2])
var(Time_frames_dip.largesd_na[,2])
mean(Time_frames_dip.largesd_na[,3])
var(Time_frames_dip.largesd_na[,3])
mean(Time_frames_dip.largesd_na[,4])
var(Time_frames_dip.largesd_na[,4])

####Dip different slope####
#small sd
sig_runs_dip_ds.smallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip_ds.smallsd[i]<-Est_dip_ds.smallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip_ds.smallsd)

Time_frames_dip_ds.smallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip_ds.smallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip_ds.smallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip_ds.smallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip_ds.smallsd<-rbind(Time_frames_dip_ds.smallsd,as.numeric(tf))
  }
}
Time_frames_dip_ds.smallsd<-Time_frames_dip_ds.smallsd[-1,]

sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,5])==F,1,0))

sum(sig_runs_dip_ds.smallsd)-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,5])==F,1,0))


Time_frames_dip_ds.smallsd_na<-Time_frames_dip_ds.smallsd[-c(which(is.na(Time_frames_dip_ds.smallsd[,2])==T), which(is.na(Time_frames_dip_ds.smallsd[,3])==T),which(is.na(Time_frames_dip_ds.smallsd[,4])==T), which(is.na(Time_frames_dip_ds.smallsd[,5])==F)),]
mean(Time_frames_dip_ds.smallsd_na[,1])
var(Time_frames_dip_ds.smallsd_na[,1])
mean(Time_frames_dip_ds.smallsd_na[,2])
var(Time_frames_dip_ds.smallsd_na[,2])
mean(Time_frames_dip_ds.smallsd_na[,3])
var(Time_frames_dip_ds.smallsd_na[,3])
mean(Time_frames_dip_ds.smallsd_na[,4])
var(Time_frames_dip_ds.smallsd_na[,4])


#msmall sd
sig_runs_dip_ds.msmallsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip_ds.msmallsd[i]<-Est_dip_ds.msmallsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip_ds.msmallsd)

Time_frames_dip_ds.msmallsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip_ds.msmallsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip_ds.msmallsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip_ds.msmallsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip_ds.msmallsd<-rbind(Time_frames_dip_ds.msmallsd,as.numeric(tf))
  }
}
Time_frames_dip_ds.msmallsd<-Time_frames_dip_ds.msmallsd[-1,]

sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,5])==F,1,0))

sum(sig_runs_dip_ds.msmallsd)-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,5])==F,1,0))


Time_frames_dip_ds.msmallsd_na<-Time_frames_dip_ds.msmallsd[-c(which(is.na(Time_frames_dip_ds.msmallsd[,2])==T), which(is.na(Time_frames_dip_ds.msmallsd[,3])==T),which(is.na(Time_frames_dip_ds.msmallsd[,4])==T), which(is.na(Time_frames_dip_ds.msmallsd[,5])==F)),]
mean(Time_frames_dip_ds.msmallsd_na[,1])
var(Time_frames_dip_ds.msmallsd_na[,1])
mean(Time_frames_dip_ds.msmallsd_na[,2])
var(Time_frames_dip_ds.msmallsd_na[,2])
mean(Time_frames_dip_ds.msmallsd_na[,3])
var(Time_frames_dip_ds.msmallsd_na[,3])
mean(Time_frames_dip_ds.msmallsd_na[,4])
var(Time_frames_dip_ds.msmallsd_na[,4])


#medium sd
sig_runs_dip_ds.mediumsd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip_ds.mediumsd[i]<-Est_dip_ds.mediumsd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip_ds.mediumsd)

Time_frames_dip_ds.mediumsd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip_ds.mediumsd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip_ds.mediumsd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip_ds.mediumsd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip_ds.mediumsd<-rbind(Time_frames_dip_ds.mediumsd,as.numeric(tf))
  }
}
Time_frames_dip_ds.mediumsd<-Time_frames_dip_ds.mediumsd[-1,]

sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,5])==F,1,0))

sum(sig_runs_dip_ds.mediumsd)-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,5])==F,1,0))


Time_frames_dip_ds.mediumsd_na<-Time_frames_dip_ds.mediumsd[-c(which(is.na(Time_frames_dip_ds.mediumsd[,2])==T), which(is.na(Time_frames_dip_ds.mediumsd[,3])==T),which(is.na(Time_frames_dip_ds.mediumsd[,4])==T), which(is.na(Time_frames_dip_ds.mediumsd[,5])==F)),]
mean(Time_frames_dip_ds.mediumsd_na[,1])
var(Time_frames_dip_ds.mediumsd_na[,1])
mean(Time_frames_dip_ds.mediumsd_na[,2])
var(Time_frames_dip_ds.mediumsd_na[,2])
mean(Time_frames_dip_ds.mediumsd_na[,3])
var(Time_frames_dip_ds.mediumsd_na[,3])
mean(Time_frames_dip_ds.mediumsd_na[,4])
var(Time_frames_dip_ds.mediumsd_na[,4])

#mlarge sd
sig_runs_dip_ds.mlargesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip_ds.mlargesd[i]<-Est_dip_ds.mlargesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip_ds.mlargesd)

Time_frames_dip_ds.mlargesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip_ds.mlargesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip_ds.mlargesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip_ds.mlargesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip_ds.mlargesd<-rbind(Time_frames_dip_ds.mlargesd,as.numeric(tf))
  }
}
Time_frames_dip_ds.mlargesd<-Time_frames_dip_ds.mlargesd[-1,]

sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,5])==F,1,0))

sum(sig_runs_dip_ds.mlargesd)-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,5])==F,1,0))


Time_frames_dip_ds.mlargesd_na<-Time_frames_dip_ds.mlargesd[-c(which(is.na(Time_frames_dip_ds.mlargesd[,2])==T), which(is.na(Time_frames_dip_ds.mlargesd[,3])==T),which(is.na(Time_frames_dip_ds.mlargesd[,4])==T), which(is.na(Time_frames_dip_ds.mlargesd[,5])==F)),]
mean(Time_frames_dip_ds.mlargesd_na[,1])
var(Time_frames_dip_ds.mlargesd_na[,1])
mean(Time_frames_dip_ds.mlargesd_na[,2])
var(Time_frames_dip_ds.mlargesd_na[,2])
mean(Time_frames_dip_ds.mlargesd_na[,3])
var(Time_frames_dip_ds.mlargesd_na[,3])
mean(Time_frames_dip_ds.mlargesd_na[,4])
var(Time_frames_dip_ds.mlargesd_na[,4])



#large sd
sig_runs_dip_ds.largesd<-numeric(1000)
for(i in 1:1000){
  sig_runs_dip_ds.largesd[i]<-Est_dip_ds.largesd[[i]]$decision[[1]]$result_relev
}

sum(sig_runs_dip_ds.largesd)

Time_frames_dip_ds.largesd<-matrix(NA,nrow=1,ncol=10)
for(i in 1:1000){
  if(Est_dip_ds.largesd[[i]]$decision[[1]]$result_relev==1){
    tf<-rep(NA,times=10)
    tf[1:length(t_points_change(Est_dip_ds.largesd[[i]]$decision[[1]]$timeframe_relev))]<-t_points_change(Est_dip_ds.largesd[[i]]$decision[[1]]$timeframe_relev)
    Time_frames_dip_ds.largesd<-rbind(Time_frames_dip_ds.largesd,as.numeric(tf))
  }
}
Time_frames_dip_ds.largesd<-Time_frames_dip_ds.largesd[-1,]

sum(ifelse(is.na(Time_frames_dip_ds.largesd[,2])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.largesd[,3])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.largesd[,4])==T,1,0))
sum(ifelse(is.na(Time_frames_dip_ds.largesd[,5])==F,1,0))

sum(sig_runs_dip_ds.largesd)-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,4])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,5])==F,1,0))


Time_frames_dip_ds.largesd_na<-Time_frames_dip_ds.largesd[-c(which(is.na(Time_frames_dip_ds.largesd[,2])==T), which(is.na(Time_frames_dip_ds.largesd[,3])==T),which(is.na(Time_frames_dip_ds.largesd[,4])==T), which(is.na(Time_frames_dip_ds.largesd[,5])==F)),]
mean(Time_frames_dip_ds.largesd_na[,1])
var(Time_frames_dip_ds.largesd_na[,1])
mean(Time_frames_dip_ds.largesd_na[,2])
var(Time_frames_dip_ds.largesd_na[,2])
mean(Time_frames_dip_ds.largesd_na[,3])
var(Time_frames_dip_ds.largesd_na[,3])
mean(Time_frames_dip_ds.largesd_na[,4])
var(Time_frames_dip_ds.largesd_na[,4])


####Tables####
#Number of H0 rejected
Table_H0reject<-data.frame("Scenario 1"=c(sum(sig_runs_norelev.smallsd),sum(sig_runs_norelev.msmallsd),sum(sig_runs_norelev.mediumsd),sum(sig_runs_norelev.mlargesd),sum(sig_runs_norelev.largesd)),
                           "Scenario 2"=c(sum(sig_runs_smalljump.smallsd),sum(sig_runs_smalljump.msmallsd),sum(sig_runs_smalljump.mediumsd),sum(sig_runs_smalljump.mlargesd),sum(sig_runs_smalljump.largesd)),
                           "Scenario 3"=c(sum(sig_runs_wider.smallsd),sum(sig_runs_wider.msmallsd),sum(sig_runs_wider.mediumsd),sum(sig_runs_wider.mlargesd),sum(sig_runs_wider.largesd)),
                           "Scenario 4"=c(sum(sig_runs_dip.smallsd),sum(sig_runs_dip.msmallsd),sum(sig_runs_dip.mediumsd),sum(sig_runs_dip.mlargesd),sum(sig_runs_dip.largesd)),
                           "Scenario 5"=c(sum(sig_runs_dip_ds.smallsd),sum(sig_runs_dip_ds.msmallsd),sum(sig_runs_dip_ds.mediumsd),sum(sig_runs_dip_ds.mlargesd),sum(sig_runs_dip_ds.largesd)),
                           "Scenario 6"=c(sum(sig_runs_nodip.smallsd),sum(sig_runs_nodip.msmallsd),sum(sig_runs_nodip.mediumsd),sum(sig_runs_nodip.mlargesd),sum(sig_runs_nodip.largesd))
)

rownames(Table_H0reject)<-c("small sd","mid-small sd", "medium sd","mid-large sd" ,"large sd")

write_xlsx(Table_H0reject, path = "./plots_tables/Table_H0reject_all.xlsx")



Scens<-c(rep("Sce. 2", times=5),rep("Sce. 3", times=5),rep("Sce. 4", times=5),rep("Sce. 5", times=5),rep("Sce. 6", times=5))
Sds<-rep(c("small sd", "mid-small sd", "medium sd", "mid-large sd", "large sd"),5)
CorRuns<-c(sum(sig_runs_smalljump.smallsd)-sum(ifelse(is.na(Time_frames_smalljump.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.smallsd[,3])==F,1,0)),
           sum(sig_runs_smalljump.msmallsd)-sum(ifelse(is.na(Time_frames_smalljump.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.msmallsd[,3])==F,1,0)),
           sum(sig_runs_smalljump.mediumsd)-sum(ifelse(is.na(Time_frames_smalljump.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.mediumsd[,3])==F,1,0)),
           sum(sig_runs_smalljump.mlargesd)-sum(ifelse(is.na(Time_frames_smalljump.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.mlargesd[,3])==F,1,0)),
           sum(sig_runs_smalljump.largesd)-sum(ifelse(is.na(Time_frames_smalljump.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_smalljump.largesd[,3])==F,1,0)),
           sum(sig_runs_wider.smallsd)-sum(ifelse(is.na(Time_frames_wider.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.smallsd[,3])==F,1,0)),
           sum(sig_runs_wider.msmallsd)-sum(ifelse(is.na(Time_frames_wider.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.msmallsd[,3])==F,1,0)),
           sum(sig_runs_wider.mediumsd)-sum(ifelse(is.na(Time_frames_wider.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.mediumsd[,3])==F,1,0)),
           sum(sig_runs_wider.mlargesd)-sum(ifelse(is.na(Time_frames_wider.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.mlargesd[,3])==F,1,0)),
           sum(sig_runs_wider.largesd)-sum(ifelse(is.na(Time_frames_wider.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_wider.largesd[,3])==F,1,0)),
           sum(sig_runs_dip.smallsd)-sum(ifelse(is.na(Time_frames_dip.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.smallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.smallsd[,4])==T&is.na(Time_frames_dip.smallsd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip.smallsd[,5])==F,1,0)),
           sum(sig_runs_dip.msmallsd)-sum(ifelse(is.na(Time_frames_dip.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.msmallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.msmallsd[,4])==T&is.na(Time_frames_dip.msmallsd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip.msmallsd[,5])==F,1,0)),
           sum(sig_runs_dip.mediumsd)-sum(ifelse(is.na(Time_frames_dip.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mediumsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mediumsd[,4])==T&is.na(Time_frames_dip.mediumsd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip.mediumsd[,5])==F,1,0)),
           sum(sig_runs_dip.mlargesd)-sum(ifelse(is.na(Time_frames_dip.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mlargesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.mlargesd[,4])==T&is.na(Time_frames_dip.mlargesd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip.mlargesd[,5])==F,1,0)),
           sum(sig_runs_dip.largesd)-sum(ifelse(is.na(Time_frames_dip.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.largesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip.largesd[,4])==T&is.na(Time_frames_dip.largesd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip.largesd[,5])==F,1,0)),
           sum(sig_runs_dip_ds.smallsd)-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,4])==T&is.na(Time_frames_dip_ds.smallsd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.smallsd[,5])==F,1,0)),
           sum(sig_runs_dip_ds.msmallsd)-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,4])==T&is.na(Time_frames_dip_ds.msmallsd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.msmallsd[,5])==F,1,0)),
           sum(sig_runs_dip_ds.mediumsd)-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,4])==T&is.na(Time_frames_dip_ds.mediumsd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mediumsd[,5])==F,1,0)),
           sum(sig_runs_dip_ds.mlargesd)-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,4])==T&is.na(Time_frames_dip_ds.mlargesd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.mlargesd[,5])==F,1,0)),
           sum(sig_runs_dip_ds.largesd)-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,3])==T,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,4])==T&is.na(Time_frames_dip_ds.largesd[,3])==F,1,0))-sum(ifelse(is.na(Time_frames_dip_ds.largesd[,5])==F,1,0)),
           sum(sig_runs_nodip.smallsd)-sum(ifelse(is.na(Time_frames_nodip.smallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.smallsd[,3])==F,1,0)),
           sum(sig_runs_nodip.msmallsd)-sum(ifelse(is.na(Time_frames_nodip.msmallsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.msmallsd[,3])==F,1,0)),
           sum(sig_runs_nodip.mediumsd)-sum(ifelse(is.na(Time_frames_nodip.mediumsd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.mediumsd[,3])==F,1,0)),
           sum(sig_runs_nodip.mlargesd)-sum(ifelse(is.na(Time_frames_nodip.mlargesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.mlargesd[,3])==F,1,0)),
           sum(sig_runs_nodip.largesd)-sum(ifelse(is.na(Time_frames_nodip.largesd[,2])==T,1,0))-sum(ifelse(is.na(Time_frames_nodip.largesd[,3])==F,1,0))
           )

mean_start_first<-c(mean(Time_frames_smalljump.smallsd[which(is.na(Time_frames_smalljump.smallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_smalljump.msmallsd[which(is.na(Time_frames_smalljump.msmallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_smalljump.mediumsd[which(is.na(Time_frames_smalljump.mediumsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_smalljump.mlargesd[which(is.na(Time_frames_smalljump.mlargesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_smalljump.largesd[which(is.na(Time_frames_smalljump.largesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_wider.smallsd[which(is.na(Time_frames_wider.smallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_wider.msmallsd[which(is.na(Time_frames_wider.msmallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_wider.mediumsd[which(is.na(Time_frames_wider.mediumsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_wider.mlargesd[which(is.na(Time_frames_wider.mlargesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_wider.largesd[which(is.na(Time_frames_wider.largesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_nodip.smallsd[which(is.na(Time_frames_nodip.smallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_nodip.msmallsd[which(is.na(Time_frames_nodip.msmallsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_nodip.mediumsd[which(is.na(Time_frames_nodip.mediumsd[,2])==F),1],na.rm=T),
                   mean(Time_frames_nodip.mlargesd[which(is.na(Time_frames_nodip.mlargesd[,2])==F),1],na.rm=T),
                   mean(Time_frames_nodip.largesd[which(is.na(Time_frames_nodip.largesd[,2])==F),1],na.rm=T)
)


True_start_first<-c(rep(11.7,times=5),rep(5.9,times=5),rep(0.1,times=5),rep(5.7,times=5),rep(0.1,times=5))
Bias_start_first<-mean_start_first-True_start_first

var_start_first<-c(var(Time_frames_smalljump.smallsd[which(is.na(Time_frames_smalljump.smallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_smalljump.msmallsd[which(is.na(Time_frames_smalljump.msmallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_smalljump.mediumsd[which(is.na(Time_frames_smalljump.mediumsd[,2])==F),1],na.rm=T),
                    var(Time_frames_smalljump.mlargesd[which(is.na(Time_frames_smalljump.mlargesd[,2])==F),1],na.rm=T),
                    var(Time_frames_smalljump.largesd[which(is.na(Time_frames_smalljump.largesd[,2])==F),1],na.rm=T),
                    var(Time_frames_wider.smallsd[which(is.na(Time_frames_wider.smallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_wider.msmallsd[which(is.na(Time_frames_wider.msmallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_wider.mediumsd[which(is.na(Time_frames_wider.mediumsd[,2])==F),1],na.rm=T),
                    var(Time_frames_wider.mlargesd[which(is.na(Time_frames_wider.mlargesd[,2])==F),1],na.rm=T),
                    var(Time_frames_wider.largesd[which(is.na(Time_frames_wider.largesd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,2])==F),1],na.rm=T),
                    var(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,2])==F),1],na.rm=T),
                    var(Time_frames_nodip.smallsd[which(is.na(Time_frames_nodip.smallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_nodip.msmallsd[which(is.na(Time_frames_nodip.msmallsd[,2])==F),1],na.rm=T),
                    var(Time_frames_nodip.mediumsd[which(is.na(Time_frames_nodip.mediumsd[,2])==F),1],na.rm=T),
                    var(Time_frames_nodip.mlargesd[which(is.na(Time_frames_nodip.mlargesd[,2])==F),1],na.rm=T),
                    var(Time_frames_nodip.largesd[which(is.na(Time_frames_nodip.largesd[,2])==F),1],na.rm=T)
)
MSE_start_first<-var_start_first+Bias_start_first^2


mean_end_first<-c(mean(rowMaxs(Time_frames_smalljump.smallsd[which(is.na(Time_frames_smalljump.smallsd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_smalljump.msmallsd[which(is.na(Time_frames_smalljump.msmallsd[,2])==F),2:10],na.rm=T)),
                    mean(rowMaxs(Time_frames_smalljump.mediumsd[which(is.na(Time_frames_smalljump.mediumsd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_smalljump.mlargesd[which(is.na(Time_frames_smalljump.mlargesd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_smalljump.largesd[which(is.na(Time_frames_smalljump.largesd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_wider.smallsd[which(is.na(Time_frames_wider.smallsd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_wider.msmallsd[which(is.na(Time_frames_wider.msmallsd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_wider.mediumsd[which(is.na(Time_frames_wider.mediumsd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_wider.mlargesd[which(is.na(Time_frames_wider.mlargesd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(rowMaxs(Time_frames_wider.largesd[which(is.na(Time_frames_wider.largesd[,2])==F),2:10],na.rm=T),na.rm=T),
                    mean(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,2])==F),2],na.rm=T),
                    mean(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,2])==F),2],na.rm=T),
                    mean(Time_frames_nodip.smallsd[which(is.na(Time_frames_nodip.smallsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_nodip.msmallsd[which(is.na(Time_frames_nodip.msmallsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_nodip.mediumsd[which(is.na(Time_frames_nodip.mediumsd[,2])==F),2],na.rm=T),
                    mean(Time_frames_nodip.mlargesd[which(is.na(Time_frames_nodip.mlargesd[,2])==F),2],na.rm=T),
                    mean(Time_frames_nodip.largesd[which(is.na(Time_frames_nodip.largesd[,2])==F),2],na.rm=T)
)


True_end_first<-c(rep(24.5,times=5),rep(36.3,times=5),rep(33.6,times=5),rep(38.1,times=5),rep(28.9,times=5))
Bias_end_first<-mean_end_first-True_end_first

var_end_first<-c(var(rowMaxs(Time_frames_smalljump.smallsd[which(is.na(Time_frames_smalljump.smallsd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_smalljump.msmallsd[which(is.na(Time_frames_smalljump.msmallsd[,2])==F),2:10],na.rm=T)),
                  var(rowMaxs(Time_frames_smalljump.mediumsd[which(is.na(Time_frames_smalljump.mediumsd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_smalljump.mlargesd[which(is.na(Time_frames_smalljump.mlargesd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_smalljump.largesd[which(is.na(Time_frames_smalljump.largesd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_wider.smallsd[which(is.na(Time_frames_wider.smallsd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_wider.msmallsd[which(is.na(Time_frames_wider.msmallsd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_wider.mediumsd[which(is.na(Time_frames_wider.mediumsd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_wider.mlargesd[which(is.na(Time_frames_wider.mlargesd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(rowMaxs(Time_frames_wider.largesd[which(is.na(Time_frames_wider.largesd[,2])==F),2:10],na.rm=T),na.rm=T),
                  var(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,2])==F),2],na.rm=T),
                  var(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,2])==F),2],na.rm=T),
                  var(Time_frames_nodip.smallsd[which(is.na(Time_frames_nodip.smallsd[,2])==F),2],na.rm=T),
                  var(Time_frames_nodip.msmallsd[which(is.na(Time_frames_nodip.msmallsd[,2])==F),2],na.rm=T),
                  var(Time_frames_nodip.mediumsd[which(is.na(Time_frames_nodip.mediumsd[,2])==F),2],na.rm=T),
                  var(Time_frames_nodip.mlargesd[which(is.na(Time_frames_nodip.mlargesd[,2])==F),2],na.rm=T),
                  var(Time_frames_nodip.largesd[which(is.na(Time_frames_nodip.largesd[,2])==F),2],na.rm=T)
)

MSE_end_first<-var_end_first+Bias_end_first^2


mean_start_second<-c(mean(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,4])==F),3],na.rm=T),
                    mean(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,4])==F),3],na.rm=T)
                   )

True_start_second<-c(rep(41.2,times=5),rep(39.4,times=5))
Bias_start_second<-mean_start_second-True_start_second

var_start_second<-c(var(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,4])==F),3],na.rm=T),
                     var(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,4])==F),3],na.rm=T)
)
MSE_start_second<-var_start_second+Bias_start_second^2


mean_end_second<-c(mean(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,4])==F),4],na.rm=T),
                     mean(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,4])==F),4],na.rm=T)
)

True_end_second<-c(rep(45,times=5),rep(45,times=5))
Bias_end_second<-mean_end_second-True_end_second

var_end_second<-c(var(Time_frames_dip.smallsd[which(is.na(Time_frames_dip.smallsd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip.msmallsd[which(is.na(Time_frames_dip.msmallsd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip.mediumsd[which(is.na(Time_frames_dip.mediumsd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip.mlargesd[which(is.na(Time_frames_dip.mlargesd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip.largesd[which(is.na(Time_frames_dip.largesd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip_ds.smallsd[which(is.na(Time_frames_dip_ds.smallsd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip_ds.msmallsd[which(is.na(Time_frames_dip_ds.msmallsd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip_ds.mediumsd[which(is.na(Time_frames_dip_ds.mediumsd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip_ds.mlargesd[which(is.na(Time_frames_dip_ds.mlargesd[,4])==F),4],na.rm=T),
                   var(Time_frames_dip_ds.largesd[which(is.na(Time_frames_dip_ds.largesd[,4])==F),4],na.rm=T)
)

MSE_end_second<-var_end_second+Bias_end_second^2

Table_timeframes<-data.frame("Sci."=Scens,
                             "Sd"=Sds,
                             "CorRuns"=CorRuns,
                             "Mean_s1"=round(mean_start_first,3),
                             "Bias_s1"=round(Bias_start_first,3),
                             "Var_s1"=round(var_start_first,3),
                             "MSE_s1"=round(MSE_start_first,3),
                             "Mean_e1"=round(mean_end_first,3),
                             "Bias_e1"=round(Bias_end_first,3),
                             "Var_e1"=round(var_end_first,3),
                             "MSE_e1"=round(MSE_end_first,3),
                             "Mean_s2"=c(rep("-",times=10),round(mean_start_second,3),rep("-",times=5)),
                             "Bias_s2"=c(rep("-",times=10),round(Bias_start_second,3),rep("-",times=5)),
                             "Var_s2"=c(rep("-",times=10),round(var_start_second,3),rep("-",times=5)),
                             "MSE_s2"=c(rep("-",times=10),round(MSE_start_second,3),rep("-",times=5))
                             )
write_xlsx(Table_timeframes, path = "./plots_tables/Table_timeframes_all.xlsx")


####Save Workspace####
save.image(file="./simulation/simulation_results_WDM_all.RData")
