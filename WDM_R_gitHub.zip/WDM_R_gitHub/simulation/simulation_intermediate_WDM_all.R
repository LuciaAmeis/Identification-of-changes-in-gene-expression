load("./simulation/simulation_scenarios_WDM_all.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

##############################################
####Application to the simulated data sets####
##############################################
####No relevance####
set.seed(28)
seeds_norelev.smallsd<-list()
for(i in 1:Nsim){
  seeds_norelev.smallsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_norelev.smallsd.RData")){
  load("./simulation/intermediate_results_all/Est_norelev.smallsd.RData")
}else{
  Est_norelev.smallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_norelev.smallsd[[i]]
    seeds<-seeds_norelev.smallsd[[i]]
    Est_norelev.smallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_norelev.smallsd,file="./simulation/intermediate_results_all/Est_norelev.smallsd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_norelev.msmallsd.RData")){
  load("./simulation/intermediate_results_all/Est_norelev.msmallsd.RData")
}else{
  Est_norelev.msmallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_norelev.msmallsd[[i]]
    seeds<-seeds_norelev.smallsd[[i]]
    Est_norelev.msmallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_norelev.msmallsd,file="./simulation/intermediate_results_all/Est_norelev.msmallsd.RData")
}

set.seed(280)
seeds_norelev.mediumsd<-list()
for(i in 1:Nsim){
  seeds_norelev.mediumsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_norelev.mediumsd.RData")){
  load("./simulation/intermediate_results_all/Est_norelev.mediumsd.RData")
}else{
  Est_norelev.mediumsd<-list()
  for(i in 1:Nsim){
    data<-Sim_norelev.mediumsd[[i]]
    seeds<-seeds_norelev.mediumsd[[i]]
    Est_norelev.mediumsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_norelev.mediumsd,file="./simulation/intermediate_results_all/Est_norelev.mediumsd.RData")
}

set.seed(2800)
seeds_norelev.largesd<-list()
for(i in 1:Nsim){
  seeds_norelev.largesd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_norelev.mlargesd.RData")){
  load("./simulation/intermediate_results_all/Est_norelev.mlargesd.RData")
}else{
  Est_norelev.mlargesd<-list()
  for(i in 1:Nsim){
    data<-Sim_norelev.mlargesd[[i]]
    seeds<-seeds_norelev.largesd[[i]]
    Est_norelev.mlargesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_norelev.mlargesd,file="./simulation/intermediate_results_all/Est_norelev.mlargesd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_norelev.largesd.RData")){
  load("./simulation/intermediate_results_all/Est_norelev.largesd.RData")
}else{
  Est_norelev.largesd<-list()
  for(i in 1:Nsim){
    data<-Sim_norelev.largesd[[i]]
    seeds<-seeds_norelev.largesd[[i]]
    Est_norelev.largesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_norelev.largesd,file="./simulation/intermediate_results_all/Est_norelev.largesd.RData")
}

####Smalljump####
set.seed(29)
seeds_smalljump.smallsd<-list()
for(i in 1:Nsim){
  seeds_smalljump.smallsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_smalljump.smallsd.RData")){
  load("./simulation/intermediate_results_all/Est_smalljump.smallsd.RData")
}else{
  Est_smalljump.smallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_smalljump.smallsd[[i]]
    seeds<-seeds_smalljump.smallsd[[i]]
    Est_smalljump.smallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_smalljump.smallsd,file="./simulation/intermediate_results_all/Est_smalljump.smallsd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_smalljump.msmallsd.RData")){
  load("./simulation/intermediate_results_all/Est_smalljump.msmallsd.RData")
}else{
  Est_smalljump.msmallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_smalljump.msmallsd[[i]]
    seeds<-seeds_smalljump.smallsd[[i]]
    Est_smalljump.msmallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_smalljump.msmallsd,file="./simulation/intermediate_results_all/Est_smalljump.msmallsd.RData")
}

set.seed(290)
seeds_smalljump.mediumsd<-list()
for(i in 1:Nsim){
  seeds_smalljump.mediumsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_smalljump.mediumsd.RData")){
  load("./simulation/intermediate_results_all/Est_smalljump.mediumsd.RData")
}else{
  Est_smalljump.mediumsd<-list()
  for(i in 1:Nsim){
    data<-Sim_smalljump.mediumsd[[i]]
    seeds<-seeds_smalljump.mediumsd[[i]]
    Est_smalljump.mediumsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_smalljump.mediumsd,file="./simulation/intermediate_results_all/Est_smalljump.mediumsd.RData")
}

set.seed(2900)
seeds_smalljump.largesd<-list()
for(i in 1:Nsim){
  seeds_smalljump.largesd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_smalljump.mlargesd.RData")){
  load("./simulation/intermediate_results_all/Est_smalljump.mlargesd.RData")
}else{
  Est_smalljump.mlarge<-list()
  for(i in 1:Nsim){
    data<-Sim_smalljump.mlargesd[[i]]
    seeds<-seeds_smalljump.largesd[[i]]
    Est_smalljump.mlargesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_smalljump.mlarge,file="./simulation/intermediate_results_all/Est_smalljump.mlargesd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_smalljump.largesd.RData")){
  load("./simulation/intermediate_results_all/Est_smalljump.largesd.RData")
}else{
  Est_smalljump.largesd<-list()
  for(i in 1:Nsim){
    data<-Sim_smalljump.largesd[[i]]
    seeds<-seeds_smalljump.largesd[[i]]
    Est_smalljump.largesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_smalljump.largesd,file="./simulation/intermediate_results_all/Est_smalljump.largesd.RData")
}
####No Dip####
set.seed(32)
seeds_nodip.smallsd<-list()
for(i in 1:Nsim){
  seeds_nodip.smallsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_nodip.smallsd.RData")){
  load("./simulation/intermediate_results_all/Est_nodip.smallsd.RData")
}else{
  Est_nodip.smallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_nodip.smallsd[[i]]
    seeds<-seeds_nodip.smallsd[[i]]
    Est_nodip.smallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_nodip.smallsd,file="./simulation/intermediate_results_all/Est_nodip.smallsd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_nodip.msmallsd.RData")){
  load("./simulation/intermediate_results_all/Est_nodip.msmallsd.RData")
}else{
  Est_nodip.msmallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_nodip.msmallsd[[i]]
    seeds<-seeds_nodip.smallsd[[i]]
    Est_nodip.msmallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_nodip.msmallsd,file="./simulation/intermediate_results_all/Est_nodip.msmallsd.RData")
}


set.seed(320)
seeds_nodip.mediumsd<-list()
for(i in 1:Nsim){
  seeds_nodip.mediumsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_nodip.mediumsd.RData")){
  load("./simulation/intermediate_results_all/Est_nodip.mediumsd.RData")
}else{
  Est_nodip.mediumsd<-list()
  for(i in 1:Nsim){
    data<-Sim_nodip.mediumsd[[i]]
    seeds<-seeds_nodip.mediumsd[[i]]
    Est_nodip.mediumsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_nodip.mediumsd,file="./simulation/intermediate_results_all/Est_nodip.mediumsd.RData")
}

set.seed(3200)
seeds_nodip.largesd<-list()
for(i in 1:Nsim){
  seeds_nodip.largesd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_nodip.mlargesd.RData")){
  load("./simulation/intermediate_results_all/Est_nodip.mlargesd.RData")
}else{
  Est_nodip.mlargesd<-list()
  for(i in 1:Nsim){
    data<-Sim_nodip.mlargesd[[i]]
    seeds<-seeds_nodip.largesd[[i]]
    Est_nodip.mlargesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_nodip.mlargesd,file="./simulation/intermediate_results_all/Est_nodip.mlargesd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_nodip.largesd.RData")){
  load("./simulation/intermediate_results_all/Est_nodip.largesd.RData")
}else{
  Est_nodip.largesd<-list()
  for(i in 1:Nsim){
    data<-Sim_nodip.largesd[[i]]
    seeds<-seeds_nodip.largesd[[i]]
    Est_nodip.largesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_nodip.largesd,file="./simulation/intermediate_results_all/Est_nodip.largesd.RData")
}

####Dip####
set.seed(33)
seeds_dip.smallsd<-list()
for(i in 1:Nsim){
  seeds_dip.smallsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_dip.smallsd.RData")){
  load("./simulation/intermediate_results_all/Est_dip.smallsd.RData")
}else{
  Est_dip.smallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip.smallsd[[i]]
    seeds<-seeds_dip.smallsd[[i]]
    Est_dip.smallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip.smallsd,file="./simulation/intermediate_results_all/Est_dip.smallsd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_dip.msmallsd.RData")){
  load("./simulation/intermediate_results_all/Est_dip.msmallsd.RData")
}else{
  Est_dip.msmallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip.msmallsd[[i]]
    seeds<-seeds_dip.smallsd[[i]]
    Est_dip.msmallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip.msmallsd,file="./simulation/intermediate_results_all/Est_dip.msmallsd.RData")
}

set.seed(330)
seeds_dip.mediumsd<-list()
for(i in 1:Nsim){
  seeds_dip.mediumsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_dip.mediumsd.RData")){
  load("./simulation/intermediate_results_all/Est_dip.mediumsd.RData")
}else{
  Est_dip.mediumsd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip.mediumsd[[i]]
    seeds<-seeds_dip.mediumsd[[i]]
    Est_dip.mediumsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip.mediumsd,file="./simulation/intermediate_results_all/Est_dip.mediumsd.RData")
}

set.seed(3300)
seeds_dip.largesd<-list()
for(i in 1:Nsim){
  seeds_dip.largesd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_dip.mlargesd.RData")){
  load("./simulation/intermediate_results_all/Est_dip.mlargesd.RData")
}else{
  Est_dip.mlargesd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip.mlargesd[[i]]
    seeds<-seeds_dip.largesd[[i]]
    Est_dip.mlargesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip.mlargesd,file="./simulation/intermediate_results_all/Est_dip.mlargesd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_dip.largesd.RData")){
  load("./simulation/intermediate_results_all/Est_dip.largesd.RData")
}else{
  Est_dip.largesd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip.largesd[[i]]
    seeds<-seeds_dip.largesd[[i]]
    Est_dip.largesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip.largesd,file="./simulation/intermediate_results_all/Est_dip.largesd.RData")
}

####Dip different slope####
set.seed(35)
seeds_dip_ds.smallsd<-list()
for(i in 1:Nsim){
  seeds_dip_ds.smallsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_dip_ds.smallsd.RData")){
  load("./simulation/intermediate_results_all/Est_dip_ds.smallsd.RData")
}else{
  Est_dip_ds.smallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip_ds.smallsd[[i]]
    seeds<-seeds_dip_ds.smallsd[[i]]
    Est_dip_ds.smallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip_ds.smallsd,file="./simulation/intermediate_results_all/Est_dip_ds.smallsd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_dip_ds.msmallsd.RData")){
  load("./simulation/intermediate_results_all/Est_dip_ds.msmallsd.RData")
}else{
  Est_dip_ds.msmallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip_ds.msmallsd[[i]]
    seeds<-seeds_dip_ds.smallsd[[i]]
    Est_dip_ds.msmallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip_ds.msmallsd,file="./simulation/intermediate_results_all/Est_dip_ds.msmallsd.RData")
}

set.seed(350)
seeds_dip_ds.mediumsd<-list()
for(i in 1:Nsim){
  seeds_dip_ds.mediumsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_dip_ds.mediumsd.RData")){
  load("./simulation/intermediate_results_all/Est_dip_ds.mediumsd.RData")
}else{
  Est_dip_ds.mediumsd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip_ds.mediumsd[[i]]
    seeds<-seeds_dip_ds.mediumsd[[i]]
    Est_dip_ds.mediumsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip_ds.mediumsd,file="./simulation/intermediate_results_all/Est_dip_ds.mediumsd.RData")
}

set.seed(3500)
seeds_dip_ds.largesd<-list()
for(i in 1:Nsim){
  seeds_dip_ds.largesd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_dip_ds.mlargesd.RData")){
  load("./simulation/intermediate_results_all/Est_dip_ds.mlargesd.RData")
}else{
  Est_dip_ds.mlargesd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip_ds.mlargesd[[i]]
    seeds<-seeds_dip_ds.largesd[[i]]
    Est_dip_ds.mlargesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip_ds.mlargesd,file="./simulation/intermediate_results_all/Est_dip_ds.mlargesd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_dip_ds.largesd.RData")){
  load("./simulation/intermediate_results_all/Est_dip_ds.largesd.RData")
}else{
  Est_dip_ds.largesd<-list()
  for(i in 1:Nsim){
    data<-Sim_dip_ds.largesd[[i]]
    seeds<-seeds_dip_ds.largesd[[i]]
    Est_dip_ds.largesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_dip_ds.largesd,file="./simulation/intermediate_results_all/Est_dip_ds.largesd.RData")
}

####Wider####
set.seed(36)
seeds_wider.smallsd<-list()
for(i in 1:Nsim){
  seeds_wider.smallsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_wider.smallsd.RData")){
  load("./simulation/intermediate_results_all/Est_wider.smallsd.RData")
}else{
  Est_wider.smallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_wider.smallsd[[i]]
    seeds<-seeds_wider.smallsd[[i]]
    Est_wider.smallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_wider.smallsd,file="./simulation/intermediate_results_all/Est_wider.smallsd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_wider.msmallsd.RData")){
  load("./simulation/intermediate_results_all/Est_wider.msmallsd.RData")
}else{
  Est_wider.msmallsd<-list()
  for(i in 1:Nsim){
    data<-Sim_wider.msmallsd[[i]]
    seeds<-seeds_wider.smallsd[[i]]
    Est_wider.msmallsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_wider.msmallsd,file="./simulation/intermediate_results_all/Est_wider.msmallsd.RData")
}

set.seed(360)
seeds_wider.mediumsd<-list()
for(i in 1:Nsim){
  seeds_wider.mediumsd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_wider.mediumsd.RData")){
  load("./simulation/intermediate_results_all/Est_wider.mediumsd.RData")
}else{
  Est_wider.mediumsd<-list()
  for(i in 1:Nsim){
    data<-Sim_wider.mediumsd[[i]]
    seeds<-seeds_wider.mediumsd[[i]]
    Est_wider.mediumsd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_wider.mediumsd,file="./simulation/intermediate_results_all/Est_wider.mediumsd.RData")
}

set.seed(3600)
seeds_wider.largesd<-list()
for(i in 1:Nsim){
  seeds_wider.largesd[[i]]<-seeds_example.d<-sample(1:100000000,B1,replace=F)
}

if(file.exists("./simulation/intermediate_results_all/Est_wider.mlargesd.RData")){
  load("./simulation/intermediate_results_all/Est_wider.mlargesd.RData")
}else{
  Est_wider.mlargesd<-list()
  for(i in 1:Nsim){
    data<-Sim_wider.mlargesd[[i]]
    seeds<-seeds_wider.largesd[[i]]
    Est_wider.mlargesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_wider.mlargesd,file="./simulation/intermediate_results_all/Est_wider.mlargesd.RData")
}

if(file.exists("./simulation/intermediate_results_all/Est_wider.largesd.RData")){
  load("./simulation/intermediate_results_all/Est_wider.largesd.RData")
}else{
  Est_wider.largesd<-list()
  for(i in 1:Nsim){
    data<-Sim_wider.largesd[[i]]
    seeds<-seeds_wider.largesd[[i]]
    Est_wider.largesd[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in=B2,lambda=lambda_45weeks,seeds=seeds)
  }
  save(Est_wider.largesd,file="./simulation/intermediate_results_all/Est_wider.largesd.RData")
}

####Save Workspace####
save.image(file="./simulation/simulation_intermediate_WDM_all.RData")