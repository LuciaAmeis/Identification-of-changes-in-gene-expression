load("./base/base_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)
#######################
####Some parameters####
#######################
#See Case Study
theta_example.d<-c(8.791445, -1.891194, 17.588670, 10.000000)
sd_example.d<-0.5948822

theta_example.i<-c(6.9968256, 2.9518712, 0.5055933, 0.2149507)
sd_example.i<-0.5658513

epsilon <- 0.1
grid <- seq(0.1,45,epsilon) #45 because we regard 48 weeks starting at week 3
#and we will transform age to time on study
#Please change if another data set is regarded

#Some specific parameters used for the analysis later
#See data preparation
timepoints <- c(0,  3,  9, 15, 21, 27, 33, 39, 45) #different time points
timevector<-c(0,  0,  0,  0,  0,  
              3,  3,  3,  3,  3,  
              9,  9,  9,  9,  9,
              15, 15, 15, 15, 15, 
              21, 21, 21, 21, 21, 
              27, 27, 27, 27, 27, 
              33, 33, 33, 33, 33, 
              39, 39, 39, 39,
              45, 45, 45, 45, 45, 45, 45, 45)#vector of time points
scal<-54

lambda_45weeks<-lambda.fct(tdiff=45,lambda_absolute = log2(1.5)) #45 weeks on study

lambda_3weeks<-lambda.fct(tdiff=3,lambda_absolute = log2(1.5)) #3 weeks 
lambda_9weeks<-lambda.fct(tdiff=9,lambda_absolute = log2(1.5)) #9 weeks  
lambda_15weeks<-lambda.fct(tdiff=15,lambda_absolute = log2(1.5)) #15 weeks  
lambda_21weeks<-lambda.fct(tdiff=21,lambda_absolute = log2(1.5)) #21 weeks  
lambda_27weeks<-lambda.fct(tdiff=27,lambda_absolute = log2(1.5)) #27 weeks  
lambda_33weeks<-lambda.fct(tdiff=33,lambda_absolute = log2(1.5)) #33 weeks  
lambda_39weeks<-lambda.fct(tdiff=39,lambda_absolute = log2(1.5)) #39 weeks  

lambda_vec<-c(lambda_45weeks,lambda_39weeks,lambda_33weeks,lambda_27weeks,lambda_21weeks,lambda_15weeks,lambda_9weeks,lambda_3weeks)

#Number of Simulations
Nsim<-1000

alpha <- 0.05 #significance level of the test
B1 <- 500 # "outer" bootstrap for critical value (=quantile)
B2 <- 25 # "inner" bootstrap for standard error
############################
####Simulation Scenarios####
############################
####No relevance####
theta_norelev<-c(theta_example.d[1],-max(timevector)*lambda_45weeks*0.152,theta_example.d[3],theta_example.d[4])

model_sigmoid_norelev<-function(t){
  count<-modelfunction_sigmoid(t,theta_norelev)
  return(count)
}


modelderiv_sigmoid_norelev<-function(t){
  slope<-modelderiv_sigmoid(t,theta_norelev)
  return(slope)
}


grid[which(abs(modelderiv_sigmoid_norelev(grid))>=0)]
grid[which(abs(modelderiv_sigmoid_norelev(grid))>=lambda_45weeks)]

####Small Jump####
theta_smalljump<-c(theta_example.d[1],theta_example.d[2]*0.5,theta_example.d[3],theta_example.d[4])

model_sigmoid_smalljump<-function(t){
  count<-modelfunction_sigmoid(t,theta_smalljump)
  return(count)
}


modelderiv_sigmoid_smalljump<-function(t){
  slope<-modelderiv_sigmoid(t,theta_smalljump)
  return(slope)
}

grid[which(abs(modelderiv_sigmoid_smalljump(grid))>=0)]
grid[which(abs(modelderiv_sigmoid_smalljump(grid))>=lambda_45weeks)]


####No Dip####
theta_nodip<-c(theta_example.i[1],theta_example.i[2],theta_example.i[3]*0.45,theta_example.i[4]*0.39)

model_nodip<-function(t){
  count<-modelfunction_beta(t,theta_nodip)
  return(count)
}

modelderiv_nodip<-function(t){
  slope<-modelderiv_beta(t,theta_nodip)
  return(slope)
}

grid[which(abs(modelderiv_nodip(grid))>=0)]
grid[which(abs(modelderiv_nodip(grid))>=lambda_45weeks)]

####Dip####
theta_dip<-c(theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4])

model_beta_dip<-function(t){
  count<-modelfunction_beta(t,theta_dip)
  return(count)
}

modelderiv_beta_dip<-function(t){
  slope<-modelderiv_beta(t,theta_dip)
  return(slope)
}

grid[which(abs(modelderiv_beta_dip(grid))>=0)]
grid[which(abs(modelderiv_beta_dip(grid))>=lambda_45weeks)]

####Sigmoidal wider####
theta_wider<-c(theta_example.d[1],2*theta_example.d[2],theta_example.d[3],5)

model_sigmoid_wider<-function(t){
  count<-modelfunction_sigmoid(t,theta_wider)
  return(count)
}

modelderiv_sigmoid_wider<-function(t){
  count<-modelderiv_sigmoid(t,theta_wider)
  return(count)
}


grid[which(abs(modelderiv_sigmoid_wider(grid))>=0)]
grid[which(abs(modelderiv_sigmoid_wider(grid))>=lambda_45weeks)]

####Dip different slope####
theta_dip_ds<-c(theta_example.i[1],theta_example.i[2],theta_example.i[3]*6.5,theta_example.i[4]*6)

model_beta_dip_ds<-function(t){
  count<-modelfunction_beta(t,theta_dip_ds)
  return(count)
}

modelderiv_beta_dip_ds<-function(t){
  slope<-modelderiv_beta(t,theta_dip_ds)
  return(slope)
}

grid[which(abs(modelderiv_beta_dip_ds(grid))>=0)]
grid[which(abs(modelderiv_beta_dip_ds(grid))>=lambda_45weeks)]

######################
####SDs Calculated####
######################
#We calculate the corresponding sds from a linear transformation of the estimated
#sds
sd_linear<-function(eMax,eMax_base,sd_base){ 
  linear_factor<-eMax/eMax_base
  sd_new<-linear_factor*sd_base
  return(sd_new)
}

#calculate sd
sd_norelev<-sd_linear(eMax=theta_norelev[2],eMax_base=theta_example.d[2],sd_base = sd_example.d)
sd_smalljump<-sd_linear(eMax=theta_smalljump[2],eMax_base=theta_example.d[2],sd_base = sd_example.d)
sd_nodip<-sd_linear(eMax=theta_nodip[2],eMax_base=theta_example.i[2],sd_base = sd_example.i)
sd_beta_dip<-sd_linear(eMax=theta_dip[2],eMax_base=theta_example.i[2],sd_base = sd_example.i)
sd_wider<-sd_linear(eMax=theta_wider[2],eMax_base=theta_example.d[2],sd_base = sd_example.d)
sd_beta_dip_ds<-sd_linear(eMax=theta_dip_ds[2],eMax_base=theta_example.i[2],sd_base = sd_example.i)



#Cases small (time 0.5), medium (times 1) and large (times 2)
SD_norelev<-c(0.5*sd_norelev,sd_norelev,2*sd_norelev)
SD_smalljump<-c(0.5*sd_smalljump,sd_smalljump,2*sd_smalljump)
SD_nodip<-c(0.5*sd_nodip,sd_nodip,2*sd_nodip)
SD_dip<-c(0.5*sd_beta_dip,sd_beta_dip,2*sd_beta_dip)
SD_wider<-c(0.5*sd_wider,sd_wider,2*sd_wider)
SD_dip_ds<-c(0.5*sd_beta_dip_ds,sd_beta_dip_ds,2*sd_beta_dip_ds)


#Cases msmall (times 0.75), medium (times 1) and mlarge (times 2)
SD_norelev_alt<-c(0.75*sd_norelev,sd_norelev,1.5*sd_norelev)
SD_smalljump_alt<-c(0.75*sd_smalljump,sd_smalljump,1.5*sd_smalljump)
SD_nodip_alt<-c(0.75*sd_nodip,sd_nodip,1.5*sd_nodip)
SD_dip_alt<-c(0.75*sd_beta_dip,sd_beta_dip,1.5*sd_beta_dip)
SD_wider_alt<-c(0.75*sd_wider,sd_wider,1.5*sd_wider)
SD_dip_ds_alt<-c(0.75*sd_beta_dip_ds,sd_beta_dip_ds,1.5*sd_beta_dip_ds)
#######################
####Data Simulation####
#######################
####No relevance####
set.seed(8)
Sim_norelev.smallsd<-list()
for(i in 1:Nsim){
  Sim_norelev.smallsd[[i]]<-simul(theta = theta_norelev,sd=SD_norelev[1],tvector=timevector,model_name = "sigEmax")
}

set.seed(8)
Sim_norelev.msmallsd<-list()
for(i in 1:Nsim){
  Sim_norelev.msmallsd[[i]]<-simul(theta = theta_norelev,sd=SD_norelev_alt[1],tvector=timevector,model_name = "sigEmax")
}

set.seed(9)
Sim_norelev.mediumsd<-list()
for(i in 1:Nsim){
  Sim_norelev.mediumsd[[i]]<-simul(theta = theta_norelev,sd=SD_norelev[2],tvector=timevector,model_name = "sigEmax")
}

set.seed(10)
Sim_norelev.mlargesd<-list()
for(i in 1:Nsim){
  Sim_norelev.mlargesd[[i]]<-simul(theta = theta_norelev,sd=SD_norelev_alt[3],tvector=timevector,model_name = "sigEmax")
}

set.seed(10)
Sim_norelev.largesd<-list()
for(i in 1:Nsim){
  Sim_norelev.largesd[[i]]<-simul(theta = theta_norelev,sd=SD_norelev[3],tvector=timevector,model_name = "sigEmax")
}


####Small Jump####
set.seed(11)
Sim_smalljump.smallsd<-list()
for(i in 1:Nsim){
  Sim_smalljump.smallsd[[i]]<-simul(theta = theta_smalljump,sd=SD_smalljump[1],tvector=timevector,model_name = "sigEmax")
}

set.seed(11)
Sim_smalljump.msmallsd<-list()
for(i in 1:Nsim){
  Sim_smalljump.msmallsd[[i]]<-simul(theta = theta_smalljump,sd=SD_smalljump_alt[1],tvector=timevector,model_name = "sigEmax")
}

set.seed(12)
Sim_smalljump.mediumsd<-list()
for(i in 1:Nsim){
  Sim_smalljump.mediumsd[[i]]<-simul(theta = theta_smalljump,sd=SD_smalljump[2],tvector=timevector,model_name = "sigEmax")
}

set.seed(13)
Sim_smalljump.mlargesd<-list()
for(i in 1:Nsim){
  Sim_smalljump.mlargesd[[i]]<-simul(theta = theta_smalljump,sd=SD_smalljump_alt[3],tvector=timevector,model_name = "sigEmax")
}

set.seed(13)
Sim_smalljump.largesd<-list()
for(i in 1:Nsim){
  Sim_smalljump.largesd[[i]]<-simul(theta = theta_smalljump,sd=SD_smalljump[3],tvector=timevector,model_name = "sigEmax")
}

####No Dip####
set.seed(17)
Sim_nodip.smallsd<-list()
for(i in 1:Nsim){
  Sim_nodip.smallsd[[i]]<-simul(theta = theta_nodip,sd=SD_nodip[1],tvector=timevector,model_name = "betaMod")
}

set.seed(17)
Sim_nodip.msmallsd<-list()
for(i in 1:Nsim){
  Sim_nodip.msmallsd[[i]]<-simul(theta = theta_nodip,sd=SD_nodip_alt[1],tvector=timevector,model_name = "betaMod")
}

set.seed(18)
Sim_nodip.mediumsd<-list()
for(i in 1:Nsim){
  Sim_nodip.mediumsd[[i]]<-simul(theta = theta_nodip,sd=SD_nodip[2],tvector=timevector,model_name = "betaMod")
}

set.seed(19)
Sim_nodip.mlargesd<-list()
for(i in 1:Nsim){
  Sim_nodip.mlargesd[[i]]<-simul(theta = theta_nodip,sd=SD_nodip_alt[3],tvector=timevector,model_name = "betaMod")
}

set.seed(19)
Sim_nodip.largesd<-list()
for(i in 1:Nsim){
  Sim_nodip.largesd[[i]]<-simul(theta = theta_nodip,sd=SD_nodip[3],tvector=timevector,model_name = "betaMod")
}


####Dip####
set.seed(20)
Sim_dip.smallsd<-list()
for(i in 1:Nsim){
  Sim_dip.smallsd[[i]]<-simul(theta = theta_dip,sd=SD_dip[1],tvector=timevector,model_name = "betaMod")
}

set.seed(20)
Sim_dip.msmallsd<-list()
for(i in 1:Nsim){
  Sim_dip.msmallsd[[i]]<-simul(theta = theta_dip,sd=SD_dip_alt[1],tvector=timevector,model_name = "betaMod")
}

set.seed(21)
Sim_dip.mediumsd<-list()
for(i in 1:Nsim){
  Sim_dip.mediumsd[[i]]<-simul(theta = theta_dip,sd=SD_dip[2],tvector=timevector,model_name = "betaMod")
}

set.seed(22)
Sim_dip.mlargesd<-list()
for(i in 1:Nsim){
  Sim_dip.mlargesd[[i]]<-simul(theta = theta_dip,sd=SD_dip_alt[3],tvector=timevector,model_name = "betaMod")
}

set.seed(22)
Sim_dip.largesd<-list()
for(i in 1:Nsim){
  Sim_dip.largesd[[i]]<-simul(theta = theta_dip,sd=SD_dip[3],tvector=timevector,model_name = "betaMod")
}

####Sigmoidal wider####
set.seed(26)
Sim_wider.smallsd<-list()
for(i in 1:Nsim){
  Sim_wider.smallsd[[i]]<-simul(theta = theta_wider,sd=SD_wider[1],tvector=timevector,model_name = "sigEmax")
}

set.seed(26)
Sim_wider.msmallsd<-list()
for(i in 1:Nsim){
  Sim_wider.msmallsd[[i]]<-simul(theta = theta_wider,sd=SD_wider_alt[1],tvector=timevector,model_name = "sigEmax")
}

set.seed(27)
Sim_wider.mediumsd<-list()
for(i in 1:Nsim){
  Sim_wider.mediumsd[[i]]<-simul(theta = theta_wider,sd=SD_wider[2],tvector=timevector,model_name = "sigEmax")
}

set.seed(28)
Sim_wider.mlargesd<-list()
for(i in 1:Nsim){
  Sim_wider.mlargesd[[i]]<-simul(theta = theta_wider,sd=SD_wider_alt[3],tvector=timevector,model_name = "sigEmax")
}

set.seed(28)
Sim_wider.largesd<-list()
for(i in 1:Nsim){
  Sim_wider.largesd[[i]]<-simul(theta = theta_wider,sd=SD_wider[3],tvector=timevector,model_name = "sigEmax")
}

####Dip different slope####
set.seed(29)
Sim_dip_ds.smallsd<-list()
for(i in 1:Nsim){
  Sim_dip_ds.smallsd[[i]]<-simul(theta = theta_dip_ds,sd=SD_dip_ds[1],tvector=timevector,model_name = "betaMod")
}

set.seed(29)
Sim_dip_ds.msmallsd<-list()
for(i in 1:Nsim){
  Sim_dip_ds.msmallsd[[i]]<-simul(theta = theta_dip_ds,sd=SD_dip_ds_alt[1],tvector=timevector,model_name = "betaMod")
}

set.seed(30)
Sim_dip_ds.mediumsd<-list()
for(i in 1:Nsim){
  Sim_dip_ds.mediumsd[[i]]<-simul(theta = theta_dip_ds,sd=SD_dip_ds[2],tvector=timevector,model_name = "betaMod")
}

set.seed(31)
Sim_dip_ds.mlargesd<-list()
for(i in 1:Nsim){
  Sim_dip_ds.mlargesd[[i]]<-simul(theta = theta_dip_ds,sd=SD_dip_ds_alt[3],tvector=timevector,model_name = "betaMod")
}

set.seed(31)
Sim_dip_ds.largesd<-list()
for(i in 1:Nsim){
  Sim_dip_ds.largesd[[i]]<-simul(theta = theta_dip_ds,sd=SD_dip_ds[3],tvector=timevector,model_name = "betaMod")
}

####Save Workingspace####
save.image(file="./simulation/simulation_scenarios_WDM_all.RData")

