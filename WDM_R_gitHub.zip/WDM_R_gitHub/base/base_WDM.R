###################
####Preparation####
###################
#finding the lambda for relevance
lambda.fct<-function(tdiff,lambda_absolute){
  #tdiff time difference from beginn to end of study
  #lambda_absolute absolute fold change over the whole time on study (often log2(1.5))
  lambda_slope<-lambda_absolute/tdiff
  return(lambda_slope)
}

lambda_45weeks<-lambda.fct(tdiff=45,lambda_absolute = log2(1.5)) #please change 45
                                                                 #to fitting time on 
                                                                 #study if another
                                                                 #data set is regarded

#Model Sigmoid case
model_sigmoid <- sigEmax

#As function regading theta
modelfunction_sigmoid<-function(t,theta){
  #t time point
  #theta=c(e0,eMax,ed50,h) model parameters
  
  e0<-theta[1]
  eMax<-theta[2]
  ed50<-theta[3]
  h<-theta[4]
  count<-e0+eMax*(t^h/(ed50^h+t^h))
  return(count)
}


#Derivation expression
modexpr_sigmoid<-expression(e0+eMax*(t^h/(ed50^h+t^h)))
D(modexpr_sigmoid,'t')

#Derivation function
modelderiv_sigmoid<-function(t,theta){
  #t time point
  #theta=c(e0,eMax,ed50,h) model parameter
  
  e0<-theta[1]
  eMax<-theta[2]
  ed50<-theta[3]
  h<-theta[4]
  
  slope<-eMax * (t^(h - 1) * h/(ed50^h + t^h) - t^h * (t^(h - 1) * h)/(ed50^h + 
                                                                         t^h)^2)
  return(slope)
}


#Model Beta
model_beta <- function(dose, e0, eMax, delta1, delta2) {
  betaMod(dose, e0, eMax, delta1, delta2,scal=scal)
}

#As function of theta
modelfunction_beta<-function(t,theta){
  #t time point
  #theta=c(e0,eMax,delta1,delta2) model parameters
  
  e0<-theta[1]
  eMax<-theta[2]
  delta1<-theta[3]
  delta2<-theta[4]
  
  B_delta<-((delta1+delta2)^(delta1+delta2))/((delta1^delta1)*(delta2^delta2))
  count<-e0+eMax*B_delta*((t/scal)^delta1)*((1-t/scal)^delta2)
  return(count)
}

#derivation expression
modexpr_beta<-expression(e0+eMax*B_delta*((t/scal)^delta1)*((1-t/scal)^delta2))
D(modexpr_beta,'t')

#derivation function
modelderiv_beta<-function(t,theta){
  #t time point
  #theta=c(e0,eMax,delta1,delta2) model parameters
  
  e0<-theta[1]
  eMax<-theta[2]
  delta1<-theta[3]
  delta2<-theta[4]
  
  B_delta<-((delta1+delta2)^(delta1+delta2))/((delta1^delta1)*(delta2^delta2))
  
  slope<-eMax * B_delta * ((t/scal)^(delta1 - 1) * (delta1 * (1/scal))) * 
    ((1 - t/scal)^delta2) - eMax * B_delta * ((t/scal)^delta1) * 
    ((1 - t/scal)^(delta2 - 1) * (delta2 * (1/scal)))
  return(slope)
}


#Exponential
model_exp <- exponential
modelfunction_exp<-function(t,theta){
  #t time point
  #theta=c(e0,e1,delta) model parameters
  
  e0<-theta[1]
  e1<-theta[2]
  delta<-theta[3]
  count<-e0 + e1 * (exp(t/delta) - 1)
  return(count)
}
modexpr_exp<-expression(e0 + e1 * (exp(t/delta) - 1))
D(modexpr_exp,'t')
modelderiv_exp<-function(t,theta){
  #t time point
  #theta=c(e0,e1,delta) model parameter
  
  e0<-theta[1]
  e1<-theta[2]
  delta<-theta[3]
  
  slope<-e1 * (exp(t/delta) * (1/delta))
  return(slope)
}


#quadratic
model_quad <- quadratic
modelfunction_quad<-function(t,theta){
  #t time point
  #theta=c(e0,b1,b2) model parameter
  
  e0<-theta[1]
  b1<-theta[2]
  b2<-theta[3]
  count<-e0 + b1 * t + b2 * t^2
  return(count)
}
modexpr_quad<-expression(e0 + b1 * t + b2 * t^2)
D(modexpr_quad,'t')
modelderiv_quad<-function(t,theta){
  #t time point
  #theta=c(e0,b1,b2) model parameter
  
  e0<-theta[1]
  b1<-theta[2]
  b2<-theta[3]
  
  slope<-b1 + b2 * (2 * t)
  return(slope)
}


#Simulation
simul <- function(theta,sd,tvector,model_name){
  #theta parameter vector
  #sd standard deviation of the model
  #tvector time points for samples
  #model_name indicating sigEmax or betaMod,exponential or quadratic
  
  #model choice
  if(model_name=="sigEmax"){
    model<-modelfunction_sigmoid
  } else{
    if(model_name=="betaMod"){
      model<-modelfunction_beta   
    } else{
      if(model_name=="exponential"){
        model<-modelfunction_exp   
      } else{
        if(model_name=="quadratic"){
          model<-modelfunction_quad   
    }
  }
    }
  }
  
  #eveluate model with given theta at sample times
  resp <- model(tvector,theta)
  
  #draw normally distributed error
  resp + rnorm(length(resp), mean = 0, sd = sd)
}

#Bootstrap fuction
bootstrap <- function(theta,sd,B_out,tvector,model_name){
  #theta parameter vector
  #sd standard deviation of the model
  #B_out number of runs for outer bootstrap
  #tvector time points for samples
  #model_name indicating sigEmax, betaMod,exponential or quadratic
  
  #model choice
  if(model_name=="sigEmax"){
    model<-modelfunction_sigmoid
    modelderiv<-modelderiv_sigmoid
  } else{
    if(model_name=="betaMod"){
      model<-modelfunction_beta   
      modelderiv<-modelderiv_beta
    } else{
      if(model_name=="exponential"){
        model<-modelfunction_exp 
        modelderiv<-modelderiv_exp
      } else{
        if(model_name=="quadratic"){
          model<-modelfunction_quad 
          modelderiv<-modelderiv_quad
        }
      }
    }
  }
  
  # store bootstrap results
  boot <- matrix(NA,nrow=B_out,ncol=length(grid))
  theta_boot_vec <- matrix(NA,nrow=B_out,ncol=length(theta))
  sd_boot <- numeric(B_out)
  
  #bootstrap loop
  for(m in 1:B_out){
    #simulate
    data_boot <- simul(theta,sd,tvector,model_name)
    
    #estimate
    try(mod_boot <- suppressMessages(fitMod(dose=tvector,    resp=data_boot, model=model_name)))
    theta_boot <- unname(mod_boot$coef)
    theta_boot_vec[m,] <- theta_boot  
    sd_boot[m] <- sqrt(mod_boot$RSS/mod_boot$df)
    
    #calculate derivation at grid
    boot[m,] <- abs(modelderiv(grid,theta_boot))
  }
  return(list(boot=boot,theta_boot=theta_boot_vec,sd_boot=sd_boot))
}


#Critical Value Bootstrap
crit.val.boot <- function(theta,B_out,B_in,outerbootstrap,model_name,tvector,seeds){
  #theta parameter vector
  #B_out number of runs for outer bootstrap
  #B_in number of runs for inner boostrap
  #outerboostrap results of outerboostrap
  #tvector time points for samples
  #model_name indicating sigEmax, betaMod,exponential or quadratic
  
  #model choice
  if(model_name=="sigEmax"){
    model<-modelfunction_sigmoid
    modelderiv<-modelderiv_sigmoid
  } else{
    if(model_name=="betaMod"){
      model<-modelfunction_beta   
      modelderiv<-modelderiv_beta
    } else{
      if(model_name=="exponential"){
        model<-modelfunction_exp 
        modelderiv<-modelderiv_exp
      } else{
        if(model_name=="quadratic"){
          model<-modelfunction_quad 
          modelderiv<-modelderiv_quad
        }
      }
    }
  }
  #to store results
  D<- numeric(length(grid))
  
  #inner boostrap using parallelization
  doParallel::registerDoParallel(cl=my.cluster)
  res <- foreach (m=1:B_out,.combine = "rbind",
                  .export=c("bootstrap","simul","grid",
                            "modelfunction_sigmoid","modelfunction_beta","modelfunction_exp","modelfunction_quad",
                            "modelderiv_sigmoid","modelderiv_beta","modelderiv_exp","modelderiv_quad","scal"),
                  .packages = c("drc","DoseFinding")) %dopar% {
    set.seed(seeds[m])
    #inner boostrap
    inner_boot <- bootstrap(outerbootstrap$theta_boot[m,],sd=outerbootstrap$sd_boot[m],B=B_in,tvector,model_name)$boot # inner bootstrap for estimating the SE*
    for(l in 1:(length(grid))){
      #calculate difference 
      D[l] <-(outerbootstrap$boot[m,l]-abs(modelderiv(grid[l], theta)))/sd(inner_boot[,l])
    }
    D<-as.numeric(D)
    D
  }
  stopImplicitCluster()
  
  #return results
  return(res)
}

#calculate crit value
crit.val<-function(crit.val.boot){
  #crit.val.boot results of function crit.val.boot
  
  #calculate max of difference over time for each run
  Dmax<-rowMax(crit.val.boot) 
  crit<-as.numeric(Dmax)
  
  #calculate quantile
  c<-quantile(crit,1-alpha,na.rm=TRUE)
  return(c)
}

#Confidence interval
conf.bands <- function(theta,c,outerboot,model_name){
  #theta parameter vector of model
  #c result from function crit.val (quantile of difference)
  #outerboot results outer boostrap
  #model_name indicating sigEmax, betaMod,exponential or quadratic
  
  #model choice
  if(model_name=="sigEmax"){
    model<-modelfunction_sigmoid
    modelderiv<-modelderiv_sigmoid
  } else{
    if(model_name=="betaMod"){
      model<-modelfunction_beta   
      modelderiv<-modelderiv_beta
    } else{
      if(model_name=="exponential"){
        model<-modelfunction_exp 
        modelderiv<-modelderiv_exp
      } else{
        if(model_name=="quadratic"){
          model<-modelfunction_quad 
          modelderiv<-modelderiv_quad
        }
      }
    }
  }
  
  #store confidence band
  low.cf<-numeric(length(grid))
  
  #calculate confidence band for grid
  for(l in 1:(length(grid))){
    derivfx <- abs(modelderiv(grid[l],theta))
    #pointwise estimated variance (each l is one point of the grid)
    var.FC <- var(outerboot$boot[,l])
    low.cf[l] <- derivfx - c*sqrt(var.FC)
  }
  return(low.cf=low.cf)
}

#test decision 
Test.decision<-function(conf,lambda){
  #conf confidence band
  #lambda pre-specified threshold
  
  #store results
  result_sign<-numeric(1)
  active_sign<-vector()
  result_relev<-numeric(1)
  active_relev<-vector()
  
  #results significance
  if(any(conf>=0)){ result_sign[1]<-1
  active_sign<-grid[which(conf>=0)]}
  else{result_sign<-0
  active_sign[1]<-NA
  } 
  #results relevance
  if(any(conf>=lambda)){
    result_relev[1]<-1
    active_relev<-grid[which(conf>=lambda)]}
  else{result_relev<-0
  active_relev[1]<-NA
  } 
  return(list(result_sign=result_sign,timeframe_sign=active_sign,result_relev=result_relev,timeframe_relev=active_relev))
}


#Function that performes full analysis
Full.Analysis<-function(dataset,tvector,model_name,B_out,B_in,lambda,seeds){
  #dataset vector with counts ordered fitting to tvector
  #tvector vector of time points at which samples were taken
  #model_name chosen model  sigEmax, betaMod,exponential or quadratic
  #B_out number of runs outer boostrap
  #B_in number of runs inner bootstrao
  #lambda pre-specified threshold(s) (here it can be a vector if multiple lambdas 
  #are tested
  #seeds vector of length B_out including seeds for inner bootstrap
  

  #estimate
  mod_analysis <- suppressMessages(fitMod(dose=tvector, resp=dataset, model=model_name))
  
  sd_analysis <- sqrt(mod_analysis$RSS/mod_analysis$df)
  theta_analysis <- unname(coef(mod_analysis))
  
  #outer bootstrap
  outerboot_analysis<-bootstrap(theta=theta_analysis,sd=sd_analysis,B_out=B_out,tvector=tvector,model_name = model_name)
  
  #estimate critical value
  crit.val.boot_analysis<-crit.val.boot(theta = theta_analysis,B_out=B_out,B_in=B_in,outerboot_analysis,model_name = model_name,tvector=tvector,seeds=seeds)
  
  #calculate critical value
  c_analysis<-crit.val(crit.val.boot =crit.val.boot_analysis)
  
  #calculate confidence band
  conf_analysis<-conf.bands(theta = theta_analysis,c=c_analysis,outerboot=outerboot_analysis,model_name = model_name)
  
  #test decision
  decision_analysis<-list()
  for(i in 1:length(lambda)){
  decision_analysis[[i]]<-Test.decision(conf= conf_analysis,lambda=lambda[i])
  }
  
  #output
  return(list(mod_est=mod_analysis,c=c_analysis,conf=conf_analysis,decision=decision_analysis))
}

#function to identify beginning and end of time of increased change 
#Only use if results=1
t_points_change<-function(decision_timeframe){
  #decision output of function Test.decision$timeframe_sign or Test.decision$timeframe_relev
  
  #to store
  t_change<-numeric(1)
  
  #first is always beginning of change
  t_change[1]<-decision_timeframe[1]
  if(length(decision_timeframe)>1){
  for(i in 2:length(decision_timeframe)){
    x<-decision_timeframe[i] #time point of activity
    x_<-decision_timeframe[i-1] #time point of activity before that
    if((x-x_)>=(2*epsilon)){ #if there is a difference of more than epsilon
                      #there is a time of inactivity in between
                      #therefore activity ends with x_ and starts anew with x
      #inactive_interval<-c(x_,x)
      #names(inactive_interval)=c("end","beginnig")
      
      #ad to t_change
      t_change[length(t_change)+1]<-x_
      t_change[length(t_change)+1]<-x
    }}
    #last is always end of activity
    end_activity<-decision_timeframe[length(decision_timeframe)]
    #ad
    t_change[length(t_change)+1]<-end_activity
  }
    #name for better readibility
    names(t_change)=rep(c("beginning","end"),times=length(t_change))[1:length(t_change)]
    return(t_change)
  }



#CIs for the limits of the time intervals
t_CI_boot<-function(B_out,B_in,B3,theta,sd,tvector,model_name,seeds,lambda){
  #B_out number of simulation runs for outer boostrap
  #B_in number of simulation runs for inner boostrap
  #B3 number of simulation runs for third bootstrap
  #theta estimated parameters from the original data set
  #sd estimated sd from the original data set
  #tvector times measures were conducted including multiple measures at one time point
  #model_name name of the assumed model
  #seeds vector of length (B3*B_out) with seeds for each inner bootstrap
  #lambda is threshold
  
  #To Store
  decision_boot3<-list()
  for(i in 1:B3){
    seeds_run<-seeds[((i-1)*B_out+1):(i*B_out)]
    #simulate
    data_boot3<-  simul(theta = theta,sd=sd,tvector=tvector,model_name = model_name) #simulate data from estimated info
    
    #proceed with analysis as above
    mod_boot3 <- suppressMessages(fitMod(dose=tvector, resp=data_boot3, model=model_name)) #estimate
    sd_boot3 <- sqrt(mod_boot3$RSS/mod_boot3$df)  #sd of new fit
    theta_boot3<- unname(coef(mod_boot3))         #theta of new fit
    
    outerboot_boot3<-bootstrap(theta=theta_boot3,sd=sd_boot3,B_out=B1,tvector=tvector,model_name = model_name) #run outer boot
    crit.val.boot_boot3<-crit.val.boot(theta = theta_boot3,B_out=B1,B_in=B2,outerboot_boot3,model_name = model_name,tvector=tvector,seeds=seeds_run) #run inner boot
    c_boot3<-crit.val(crit.val.boot =crit.val.boot_boot3) #calculate critical value
    conf_boot3<-conf.bands(theta = theta_boot3,c=c_boot3,outerboot=outerboot_boot3,model_name =model_name) #calculate CB for simulated data set
    decision_boot3[[i]]<-Test.decision(conf= conf_boot3,lambda=lambda) #test decision for simulated data set
  }
  return(decision_boot3)
}

t_CI_quantile<-function(decision_boot,n_changepoints_sign=NA,n_changepoints_relev){
  #decision_boot output t_CI_boot
  #n_changepoints number of change time points identified using Test.decision
  #n_changepoint_sign is set to NA on default
  
  #check only the relevant jump points
  if(is.na(n_changepoints_sign)==T){
    decision_relev<-list()
    for(i in 1:length(decision_boot)){
      if(decision_boot[[i]]$result_relev==1){
      timeframe_relev<-decision_boot[[i]]$timeframe_relev
      #check if number of change points between relevant change and no 
      #relevant change is the same as in the original data set
      if(length(t_points_change(timeframe_relev))==n_changepoints_relev){
        decision_relev[[length(decision_relev)+1]]<-t_points_change(timeframe_relev)
      }} else{
        decision_relev[[length(decision_relev)+1]]<-rep(NA,times=n_changepoints_relev)
      }
    }
    
    mat_decision_relev<-matrix(NA,ncol=n_changepoints_relev,nrow=1)
    mat_decision_relev[1,]<-decision_relev[[1]]
    for(i in 2:length(decision_relev)){
      mat_decision_relev<-rbind(mat_decision_relev,decision_relev[[i]])
    }
   
    
    mat_quantils_relev<-matrix(NA,ncol=2,nrow=n_changepoints_relev)
    for(i in 1:n_changepoints_relev){
      mat_quantils_relev[i,1]<-quantile(mat_decision_relev[,i],alpha/2,na.rm=TRUE)
      mat_quantils_relev[i,2]<-quantile(mat_decision_relev[,i],1-alpha/2,na.rm=TRUE)
    }
    rownames(mat_quantils_relev)<-rep(c("beginning","end"),times=n_changepoints_relev)[1:nrow(mat_quantils_relev)]
    
      
    
    #return matrix
    #return runs to check how many runs were removed for a different
    #number of time points of interest
    return(list("relev"=mat_quantils_relev,"runs"=nrow(mat_decision_relev)))
    
  }else{
  #Bootstrap also the significant results
  #to store
  decision_sign<-list()
  decision_relev<-list()
    for(i in 1:length(decision_boot)){
    if(decision_boot[[i]]$result_sign==1){
    timeframe_sign<-decision_boot[[i]]$timeframe_sign
    #check if number of change points between significant change and no 
    #significant change is the same as in the original data set
    if(length(t_points_change(timeframe_sign))==n_changepoints_sign){
      decision_sign[[length(decision_sign)+1]]<-t_points_change(timeframe_sign)
    }
    }else{      decision_sign[[length(decision_sign)+1]]<-rep(NA,times=n_changepoints_sign)
    }
    
    if(decision_boot[[i]]$result_relev==1){
    timeframe_relev<-decision_boot[[i]]$timeframe_relev
    #check if number of change points between relevant change and no 
    #relevant change is the same as in the original data set
    if(length(t_points_change(timeframe_relev))==n_changepoints_relev){
      decision_relev[[length(decision_relev)+1]]<-t_points_change(timeframe_relev)
    }} else{
      decision_relev[[length(decision_relev)+1]]<-rep(NA,times=n_changepoints_relev)
    }
    }
  
  #bring both into matrix form with column wise values of the corresponding change
  #time point
  mat_decision_sign<-matrix(NA,ncol=n_changepoints_sign,nrow=1)
  mat_decision_sign[1,]<-decision_sign[[1]]
  for(i in 2:length(decision_sign)){
    mat_decision_sign<-rbind(mat_decision_sign,decision_sign[[i]])
  }
  
  mat_decision_relev<-matrix(NA,ncol=n_changepoints_relev,nrow=1)
  mat_decision_relev[1,]<-decision_relev[[1]]
  for(i in 2:length(decision_relev)){
    mat_decision_relev<-rbind(mat_decision_relev,decision_relev[[i]])
  }
  
  #calculate emirical quantils and store in matrix                                                   
  mat_quantils_sign<-matrix(NA,ncol=2,nrow=n_changepoints_sign)
  for(i in 1:n_changepoints_sign){
    mat_quantils_sign[i,1]<-quantile(mat_decision_sign[,i],alpha/2,na.rm=TRUE)
    mat_quantils_sign[i,2]<-quantile(mat_decision_sign[,i],1-alpha/2,na.rm=TRUE)
  }
  rownames(mat_quantils_sign)<-rep(c("beginning","end"),times=n_changepoints_sign)[1:nrow(mat_quantils_sign)]

  mat_quantils_relev<-matrix(NA,ncol=2,nrow=n_changepoints_relev)
  for(i in 1:n_changepoints_relev){
    mat_quantils_relev[i,1]<-quantile(mat_decision_relev[,i],alpha/2,na.rm=TRUE)
    mat_quantils_relev[i,2]<-quantile(mat_decision_relev[,i],1-alpha/2,na.rm=TRUE)
  }
  rownames(mat_quantils_relev)<-rep(c("beginning","end"),times=n_changepoints_relev)[1:nrow(mat_quantils_relev)]
  
  #return matrix
  return(list("sign"=mat_quantils_sign,"relev"=mat_quantils_relev))
}}


#CI differnece of two groups
t_CI_quantile_diff<-function(decision_boot1,decision_boot2,n_changepoints_relev){
  #decision_boot output t_CI_boot
  #n_changepoints number of change time points identified using Test.decision
  
  #to store
  decision_relev1<-list()
  for(i in 1:length(decision_boot1)){
    if(decision_boot1[[i]]$result_relev==1){
      timeframe_relev1<-decision_boot1[[i]]$timeframe_relev
      #check if number of change points between relevant change and no 
      #relevant change is the same as in the original data set
      if(length(t_points_change(timeframe_relev1))==n_changepoints_relev){
        decision_relev1[[length(decision_relev1)+1]]<-t_points_change(timeframe_relev1)
      }} else{
        decision_relev1[[length(decision_relev1)+1]]<-rep(NA,times=n_changepoints_relev)
      }
  }
  
  decision_relev2<-list()
  for(i in 1:length(decision_boot2)){
    if(decision_boot2[[i]]$result_relev==1){
      timeframe_relev2<-decision_boot2[[i]]$timeframe_relev
      #check if number of change points between relevant change and no 
      #relevant change is the same as in the original data set
      if(length(t_points_change(timeframe_relev2))==n_changepoints_relev){
        decision_relev2[[length(decision_relev2)+1]]<-t_points_change(timeframe_relev2)
      }} else{
        decision_relev2[[length(decision_relev2)+1]]<-rep(NA,times=n_changepoints_relev)
      }
  }
  
  
  #bring both into matrix form with column wise values of the corresponding change
  #time point
  mat_decision_relev1<-matrix(NA,ncol=n_changepoints_relev,nrow=1)
  mat_decision_relev1[1,]<-decision_relev1[[1]]
  for(i in 2:length(decision_relev1)){
    mat_decision_relev1<-rbind(mat_decision_relev1,decision_relev1[[i]])
  }
  
  mat_decision_relev2<-matrix(NA,ncol=n_changepoints_relev,nrow=1)
  mat_decision_relev2[1,]<-decision_relev2[[1]]
  for(i in 2:length(decision_relev2)){
    mat_decision_relev2<-rbind(mat_decision_relev2,decision_relev2[[i]])
  }
  
  #reduce, if different number of runs worked
  nrow_min <- min(nrow(mat_decision_relev1),nrow(mat_decision_relev2))
  mat_decision_diff<-mat_decision_relev1[1:nrow_min,]-mat_decision_relev2[1:nrow_min,]
  
  #matrix for quantiles
  mat_quantils_relev<-matrix(NA,ncol=2,nrow=n_changepoints_relev)
  for(i in 1:n_changepoints_relev){
    mat_quantils_relev[i,1]<-quantile(mat_decision_diff[,i],alpha/2,na.rm=TRUE)
    mat_quantils_relev[i,2]<-quantile(mat_decision_diff[,i],1-alpha/2,na.rm=TRUE)
  }
  rownames(mat_quantils_relev)<-rep(c("beginning","end"),times=n_changepoints_relev)[1:nrow(mat_quantils_relev)]
  
  #return matrix
  return("diff"=mat_quantils_relev)
  
}

####Save Working Directory####
save.image(file="./base/base_WDM.RData")