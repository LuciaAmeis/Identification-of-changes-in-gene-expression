load("./base/base_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

###########################################################
#### Change base functions for analysis with B-splines ####
###########################################################

simul <- function(mod,sd,tvector,Bb)
{ #mod estimated b-splines, result from lm() 
  #sd standard deviation of the model
  #tvector time points for samples
  #Bb bspline basis
  
  #eveluate model with given the estimated model at sample times
  resp <- cbind(rep(1,length(tvector)),Bb)%*%coef(mod)
  #draw normally distributed error
  resp + rnorm(length(resp), mean = 0, sd = sd)
}

#Bootstrap fuction
bootstrap <- function(mod,sd,B_out,tvector,Bb,Bb_deriv){
  #mod lm output
  #sd standard deviation of the model
  #B_out number of runs for outer bootstrap
  #tvector time points for samples
  #Bb bspline bais
  #Bb_deriv first derivative of bspline basis
  
  # store bootstrap results
  boot <- matrix(NA,nrow=B_out,ncol=length(grid))
  mod_list <- list()
  sd_boot <- numeric(B_out)
  
  #bootstrap loop
  for(m in 1:B_out){
    #simulate
    data_boot <- simul(mod,sd,tvector,Bb)
    df_boot <- data.frame(time=tvector,count=data_boot)
    #estimate
    mod_boot <- lm(df_boot$count ~ Bb)
    mod_list[[m]] <- mod_boot
    sd_boot[m] <- sqrt(RSS(mod_boot)/mod_boot$df.residual)
    
    #calculate derivation at grid
    boot[m,] <- abs(Bb_deriv %*% coef(mod_boot)[-1])
  }
  return(list(boot=boot,mod_boot=mod_list,sd_boot=sd_boot))
}

#Critical Value Bootstrap
crit.val.boot <- function(mod,B_out,B_in,outerbootstrap,tvector,seeds,Bb,Bb_deriv){
  #mod lm output
  #B_out number of runs for outer bootstrap
  #B_in number of runs for inner boostrap
  #outerboostrap results of outerboostrap
  #tvector time points for samples
  #seeds vector of length B_out including seeds 
  #Bb bspline bais
  #Bb_deriv first derivative of bspline basis
  
  
  #to store results
  D<- numeric(length(grid))
  
  #inner boostrap using parallelization
  doParallel::registerDoParallel(cl=my.cluster)
  res <- foreach (m=1:B_out,.combine = "rbind",.export=c("bootstrap","simul","grid"),.packages = c("drc","splines","splines2","qpcR")) %dopar% {
    
    set.seed(seeds[m])
    #inner boostrap
    inner_boot <- bootstrap(outerbootstrap$mod_boot[[m]],sd=outerbootstrap$sd_boot[m],B=B_in,tvector,Bb=Bb,Bb_deriv=Bb_deriv)$boot # inner bootstrap for estimating the SE*
    for(l in 1:(length(grid))){
      #calculate difference 
      D[l] <-(outerbootstrap$boot[m,l]-abs(Bb_deriv %*% coef(mod)[-1])[l])/sd(inner_boot[,l])
    }
    D<-as.numeric(D)
    D
  }
  stopImplicitCluster()
  
  #return results
  return(res)
}

#Confidence interval
conf.bands <- function(mod,c,outerboot,Bb_deriv){
  #mod lm output
  #c result from function crit.val (quantile of dufference)
  #outerboot results outer boostrap
  #Bb_deriv first derivative of bspline basis
  
  
  #store confidence band
  low.cf<-numeric(length(grid))
  
  #calculate confidence band for grid
  for(l in 1:(length(grid))){
    derivfx <- abs(Bb_deriv %*% coef(mod)[-1])[l]
    #pointwise estimated variance (each l is one point of the grid)
    var.FC <- var(outerboot$boot[,l])
    low.cf[l] <- derivfx - c*sqrt(var.FC)
  }
  return(low.cf=low.cf)
}


#Function that performes full analysis
Full.Analysis<-function(dataset,tvector,Bb,Bb_deriv,B_out,B_in,lambda,seeds){
  #dataset vector with counts ordered fitting to tvector
  #tvector vector of time points at which samples were taken
  #Bb Splines basis
  #Bb_deriv spline basis derived
  #B_out number of runs outer boostrap
  #B_in number of runs inner bootstrao
  #lambda pre-specified threshold(s) (here it can be a vector if multiple lambdas 
  #are tested
  #seeds vector of length B_out including seeds for inner bootstrap

  
  data.frame_analysis <- data.frame("count"=dataset,"time"=timevector)
  
  mod_analysis <- lm(data.frame_analysis$count ~ Bb)
  #    summary(model)
  sd_analysis<-RSS(mod_analysis)/mod_analysis$df.residual
  
  
  #coef <- coef(mod_analysis)
  
  
  #outer bootstrap
  outerboot_analysis<-bootstrap(mod=mod_analysis,sd=sd_analysis,B_out=B_out,tvector=tvector,Bb = Bb,Bb_deriv=Bb_deriv)
  
  #estimate critical value
  crit.val.boot_analysis<-crit.val.boot(mod = mod_analysis,B_out=B_out,B_in=B_in,outerboot_analysis,Bb = Bb,Bb_deriv=Bb_deriv,tvector=tvector,seeds=seeds)
  
  #calculate critical value
  c_analysis<-crit.val(crit.val.boot =crit.val.boot_analysis)
  
  #calculate confidence band
  conf_analysis<-conf.bands(mod = mod_analysis,c=c_analysis,outerboot=outerboot_analysis,Bb_deriv=Bb_deriv)
  
  #test decision
  decision_analysis<-list()
  for(i in 1:length(lambda)){
    decision_analysis[[i]]<-Test.decision(conf= conf_analysis,lambda=lambda[i])
  }
  
  #output
  return(list(mod_est=mod_analysis,c=c_analysis,conf=conf_analysis,decision=decision_analysis))
}



#CIs for the limits of the time intervals
t_CI_boot<-function(B_out,B_in,B3,mod,sd,tvector,Bb,Bb_deriv,seeds,lambda){
  #B_out number of simulation runs for outer boostrap
  #B_in number of simulation runs for inner boostrap
  #B3 number of simulation runs for third bootstrap
  #mod estimated parameters from the original data set
  #sd estimated sd from the original data set
  #tvector times measures were conducted including multiple measures at one time point
  #Bb,Bb_deriv Bspline Basis and first derivative
  #seeds vector of length (B3*B_out) with seeds for each inner bootstrap
  
  #To Store
  decision_boot3<-list()
  for(i in 1:B3){
    seeds_run<-seeds[((i-1)*B_out+1):(i*B_out)]
    #simulate
    data_boot3<-  simul(mod = mod,sd=sd,tvector=tvector,Bb) #simulate data from estimated info
    
    #proceed with analysis as above
    mod_boot3 <- lm(data.frame("count"=data_boot3,"time"=tvector)$count ~ Bb)
    #    summary(model)
    sd_boot3<-RSS(mod_boot3)/mod_boot3$df.residual
    

    outerboot_boot3<-bootstrap(mod=mod_boot3,sd=sd_boot3,B_out=B1,tvector=tvector,Bb,Bb_deriv) #run outer boot
    crit.val.boot_boot3<-crit.val.boot(mod = mod_boot3,B_out=B1,B_in=B2,outerboot_boot3,Bb,Bb_deriv,tvector=tvector,seeds=seeds_run) #run inner boot
    c_boot3<-crit.val(crit.val.boot =crit.val.boot_boot3) #calculate critical value
    conf_boot3<-conf.bands(mod = mod_boot3,c=c_boot3,outerboot=outerboot_boot3,Bb_deriv) #calculate CB for simulated data set
    decision_boot3[[i]]<-Test.decision(conf= conf_boot3,lambda=lambda) #test decision for simulated data set
  }
  return(decision_boot3)
}
####Save Working Directory####
save.image(file="./base/base_add_bsplines_WDM.RData")
