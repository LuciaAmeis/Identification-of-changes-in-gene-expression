#############
####Start####
#############
#Library
library(tximeta)
library(DESeq2)
library(ashr) # For shrinkage of "only due to noise" large log2FCs
library(tidyr)
library(tibble)
library(DT) # for nice tables
library(drc)
library(matrixStats)
library(DoseFinding)
library(parallel)
library(foreach)
library(doParallel)
library(dplyr)
library(doSNOW)
library(reshape)
library(ggplot2)
library(topGO) # for gene set enrichment / GO analysis
library(patchwork)
library(writexl)
library(splines2)
library(spatstat)
#url <- "https://cran.r-project.org/src/contrib/Archive/qpcR/qpcR_1.4-1.tar.gz"
#install.packages(url, repos = NULL, type = "source")
library(qpcR)


####Session Info###
#Of note, as the main manuscript stated, the parametric analysis was 
#conducted on R version 4.3.2
#The simulation study was calculated on a server with R version 4.3.1
#The session Info depicted below is the newest session info
#Only, the b-splines analysis was conducted using the listed packages
#This should however not influence most of the results
#The only exception is the GO analysis conducted for the case study
#Since the results depend on the annotation of gene to GO groups. These
#fluctuate between versions due to advancements in research
#The important influence here is the version of Bioconductor
#The version of Bioconductor version compatible with R version 4.3.x
#is 3.18
#Using newer versions most likely will influence the results
#Nevertheless, this will not influence massage presented in the paper,
#since the goal was to demonstrate a combination of the methods
#And the basic nature of the annotated genes will not change overall
#between versions

#sessionInfo()
#R version 4.5.0 (2025-04-11 ucrt)
#Platform: x86_64-w64-mingw32/x64
#Running under: Windows 11 x64 (build 26100)

#Matrix products: default
#LAPACK version 3.12.1

#locale:
#[1] LC_COLLATE=German_Germany.utf8  LC_CTYPE=German_Germany.utf8   
#[3] LC_MONETARY=German_Germany.utf8 LC_NUMERIC=C                   
#[5] LC_TIME=German_Germany.utf8    

#time zone: Europe/Berlin
#tzcode source: internal

#attached base packages:
#[1] parallel  stats4    stats     graphics  grDevices utils     datasets  methods  
#[9] base     

#other attached packages:
#[1] qpcR_1.4-1                  Matrix_1.7-3               
#[3] robustbase_0.99-4-1         rgl_1.3.18                 
#[5] minpack.lm_1.2-4            spatstat_3.3-2             
#[7] spatstat.linnet_3.2-5       spatstat.model_3.3-5       
#[9] rpart_4.1.24                spatstat.explore_3.4-2     
#[11] nlme_3.1-168                spatstat.random_3.3-3      
#[13] spatstat.geom_3.3-6         spatstat.univar_3.1-3      
#[15] spatstat.data_3.1-6         splines2_0.5.4             
#[17] writexl_1.5.4               patchwork_1.3.0            
#[19] topGO_2.59.0                SparseM_1.84-2             
#[21] GO.db_3.21.0                AnnotationDbi_1.70.0       
#[23] graph_1.86.0                ggplot2_3.5.2              
#[25] reshape_0.8.9               doSNOW_1.0.20              
#[27] snow_0.4-4                  dplyr_1.1.4                
#[29] doParallel_1.0.17           iterators_1.0.14           
#[31] foreach_1.5.2               DoseFinding_1.3-1          
#[33] drc_3.0-1                   MASS_7.3-65                
#[35] DT_0.33                     tibble_3.2.1               
#[37] tidyr_1.3.1                 ashr_2.2-63                
#[39] DESeq2_1.48.0               SummarizedExperiment_1.38.1
#[41] Biobase_2.68.0              MatrixGenerics_1.20.0      
#[43] matrixStats_1.5.0           GenomicRanges_1.60.0       
#[45] GenomeInfoDb_1.44.0         IRanges_2.42.0             
#[47] S4Vectors_0.46.0            BiocGenerics_0.54.0        
#[49] generics_0.1.3              tximeta_1.26.0             

#loaded via a namespace (and not attached):
#[1] splines_4.5.0            BiocIO_1.19.0            bitops_1.0-9            
#[4] filelock_1.0.3           polyclip_1.10-7          XML_3.99-0.18           
#[7] lifecycle_1.0.4          httr2_1.1.2              mixsqp_0.3-54           
#[10] lattice_0.22-7           ensembldb_2.33.0         magrittr_2.0.3          
#[13] yaml_2.3.10              plotrix_3.8-4            spatstat.sparse_3.1-0   
#[16] DBI_1.2.3                RColorBrewer_1.1-3       multcomp_1.4-28         
#[19] abind_1.4-8              purrr_1.0.4              AnnotationFilter_1.33.0 
#[22] RCurl_1.98-1.17          TH.data_1.1-3            rappdirs_0.3.3          
#[25] sandwich_3.1-1           GenomeInfoDbData_1.2.14  irlba_2.3.5.1           
#[28] spatstat.utils_3.1-3     goftest_1.2-3            codetools_0.2-20        
#[31] DelayedArray_0.34.1      xml2_1.3.8               tidyselect_1.2.1        
#[34] UCSC.utils_1.5.0         farver_2.1.2             base64enc_0.1-3         
#[37] BiocFileCache_2.99.0     GenomicAlignments_1.44.0 jsonlite_2.0.0          
#[40] Formula_1.2-5            survival_3.8-3           tools_4.5.0             
#[43] progress_1.2.3           Rcpp_1.0.14              glue_1.8.0              
#[46] SparseArray_1.8.0        xfun_0.52                mgcv_1.9-3              
#[49] withr_3.0.2              BiocManager_1.30.25      fastmap_1.2.0           
#[52] digest_0.6.37            truncnorm_1.0-9          R6_2.6.1                
#[55] gtools_3.9.5             tensor_1.5               biomaRt_2.65.0          
#[58] RSQLite_2.3.10           rtracklayer_1.68.0       prettyunits_1.2.0       
#[61] httr_1.4.7               htmlwidgets_1.6.4        S4Arrays_1.8.0          
#[64] pkgconfig_2.0.3          gtable_0.3.6             blob_1.2.4              
#[67] XVector_0.48.0           htmltools_0.5.8.1        carData_3.0-5           
#[70] ProtGenerics_1.41.0      scales_1.4.0             png_0.1-8               
#[73] knitr_1.50               rstudioapi_0.17.1        rjson_0.2.23            
#[76] curl_6.2.2               cachem_1.1.0             zoo_1.8-14              
#[79] stringr_1.5.1            BiocVersion_3.22.0       restfulr_0.0.15         
#[82] pillar_1.10.2            grid_4.5.0               vctrs_0.6.5             
#[85] car_3.1-3                dbplyr_2.5.0             tximport_1.37.0         
#[88] evaluate_1.0.3           invgamma_1.1             GenomicFeatures_1.61.0  
#[91] mvtnorm_1.3-3            cli_3.6.5                locfit_1.5-9.12         
#[94] compiler_4.5.0           Rsamtools_2.24.0         rlang_1.1.6             
#[97] crayon_1.5.3             SQUAREM_2021.1           plyr_1.8.9              
#[100] stringi_1.8.7            deldir_2.0-4             BiocParallel_1.42.0     
#[103] txdbmaker_1.5.1          Biostrings_2.76.0        lazyeval_0.2.2          
#[106] hms_1.1.3                bit64_4.6.0-1            KEGGREST_1.49.0         
#[109] AnnotationHub_3.99.0     memoise_2.0.1            DEoptimR_1.1-3-1        
#[112] bit_4.6.0

#R version 4.5.0 seems to produce problems when used in combination with 
#DESeq2 version 1.48.0 
#Running the following line should help
#If there is a problem running source("./data_preparation/data_preparation_EDm.RData")
#try rerunning this line
setOldClass("ExpData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

#Set Workingdirectory (Please change before running)
setwd("C:/Users/Lucia Ameis/Documents/Western Diet Mice/DerivationCode-LV/WDM_R")



###################
####Preparation####
###################
#Here all basic functions needed for the analysis and simulation are defined. 
#Please, always run first.
#If the analysis is conducted with b-splines, run line 212  below
source("./base/base_WDM.R")


#Here we prepare the data set for analysis and basis of the simulation study
#The genes Cd163, Fam83a, Dpb and Tm7sf2 are extracted from the data set
source("./data_preparation/data_preparation_WDM.R")

#Simulation scenarios
source("./simulation/simulation_scenarios_WDM_all.R")

#Simulation intermediate results
#Of note, since the simulation runs take a lot of time, the code was written 
#such that saved working directories are loaded
#The intermediate results are stored in the subfolder 'intermediate'
#We recomend running the simulations on a server and loading them as written
#in the file
source("./simulation/simulation_intermediate_WDM_all.R")

############################
####Results - Parametric####
############################
#Simulation results
#results are automatically stored in the subfolder plots_tables
source("./simulation/simulation_results_all.R")

#Case study example genes Cd163, Fam83a and Tm7sf2
source("./case_study/case_study_WDM.R")

#CIs for the case study (WARNING: RUNS A LONG TIME)
#Please load the prepared Work Space
#source("./case_study/case_study_ci_WDM.R")
load("./case_study/case_study_ci_WDM.RData")

#Case study aging
#Part of this code runs a long time. Therefore, the code as is is written such 
#that a prepared .RData file is loaded instead of the most time consuming part of the
#code. 
#The analysis of the WD-fed mice is also used as an example for the exponential
#model
source("./case_study/case_study_aging_WDM.R")

#Case study GO analysis
#Part of this code runs a long time. Therefore, the code as is is written such 
#that a prepared .RData file is loaded instead of the most time consuming part of the
#code. 
source("./case_study/case_study_GO_WDM.R")


############################
####Results - Parametric####
############################
#Add functions to perform method using B-splines
source("./base/base_add_bsplines_WDM.R")

#Case study example genes Cd163, Fam83a and Tm7sf2 and Dbp using bsplins
source("./case_study/case_study_bsplines_WDM.R")

#CIs for the case study (WARNING: RUNS A LONG TIME IF CODE IS FULLY RUN)
#Therefore, the code as is is written such 
#that a prepared .RData file is loaded instead of the most time consuming part of the
#code. 
source("./case_study/case_study_bsplines_ci_WDM.R")


#######################
####Results - Plots####
#######################
#Plot generation
#Of note, can take a few hours to run due to the large number of
#plots
#most plots can be run individually
source("./plot_generation/plot_generation_WDM.R")
