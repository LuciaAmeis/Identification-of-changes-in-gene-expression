#Disclaimer: As of now, only application with independent observations along
#            the time axis are supported
#            Multivariate outcomes are to be included in the future

#If the master file was not run beforehand, we start with the library and the 
#WD

####################
#####Preliminary####
####################
library(tximeta)
library(DESeq2)
library(ashr) # For shrinkage of "only due to noise" large log2FCs
library(tidyr)
library(tibble)
library(DT) # for nice tables
library(drc)
library(matrixStats)
library(DoseFinding)
library(parallel)
library(foreach)
library(doParallel)
library(dplyr)
library(doSNOW)
library(reshape)
library(ggplot2)
library(topGO) # for gene set enrichment / GO analysis
library(patchwork)
library(writexl)
library(splines2)
library(spatstat)
#url <- "https://cran.r-project.org/src/contrib/Archive/qpcR/qpcR_1.4-1.tar.gz"
#install.packages(url, repos = NULL, type = "source")
library(qpcR)

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

#Set Workingdirectory to the file, where master_WDM.R is stored
setwd("...")

#####################################
#####Description of the data set#####
#####################################
#'The data set should consist of two vectors. For example
#'time/dose = c(1,1,1,2,2,2,2,3,3,...)
#'response = c(12,13,14,12,15,9,7,4,3,...)

#Please load your data set and save the time/dose-response values into
#two numeric vectors
#In the following we will assume, that these vectors were named:
#timevector
#response

######################
####Some variables####
######################
alpha <- 0.05 #significance level of the test
B1 <- 500 # "outer" bootstrap for critical value (=quantile)
B2 <- 25 # "inner" bootstrap for standard error
B3<-500  #thrid bootstrap for confidence intervals (=quantile)

# here we construct a grid 
epsilon <- 0.1              #This is the fineness of the grid
                            #feel free to adjust this value to a fitting
                            #size


grid <- seq(min(timevector),max(timevector),epsilon) #grid over the span of the study

#Some specific parameters used for the analysis later
timepoints <- unique(timevector) #different time points
scal<-max(timevector)*1.2        #for the beta model


#Next, we set the threshold
#In the paper we recommend log2(1.5) divided by the study period
#However, this value can be freely adjusted
lambda_threshold<- log2(1.5)/(max(timevector)-min(timevector)) 


#############################
####Analysis - Parametric####
#############################
#Now, we load the base functions
source("./base/base_WDM.R")


#We start with a model selection step
#sigmoid
mod_sigmoid <- suppressMessages(fitMod(dose=timevector, resp=response, model="sigEmax"))

#beta
mod_beta <- suppressMessages(fitMod(dose=timevector, resp=response, model="betaMod"))

#exp
mod_exp <- suppressMessages(fitMod(dose=timevector, resp=response, model="exponential"))

#quad
mod_quad <- suppressMessages(fitMod(dose=timevector, resp=response, model="quadratic"))


#We chose the model with the smallest AIC
mod_fit <- c(mod_sigmoid, mod_beta, mod_exp, mod_quad)[which.min(c(AIC(mod_sigmoid),
                                                                   AIC(mod_beta),
                                                                   AIC(mod_exp),
                                                                   AIC(mod_quad)))]
#Please select the model name
mod_name <- "sigEmax"
#mod_name <- "betaMod"
#mod_name <- "quadratic"
#mod_name <- "exponential"

#Extract variables
sd_fit <- sqrt(mod_fit$RSS/mod_fit$df)
theta_fit <- unname(coef(mod_fit))


#Perform analysis
#We start with setting a seed
set.seed(1)

#draw seeds for inner bootstrap
seeds_vector<-sample(1:100000000,B1,replace=F)

#Perform the outer bootstrap
outerboot_res<-bootstrap(theta=theta_fit,sd=sd_fit,B_out=B1,tvector=timevector,model_name = mod_name)

#Perform second level bootstrap
crit.val.boot_res<-crit.val.boot(theta = theta_fit,B_out=B1,B_in=B2,outerboot=outerboot_res,model_name = mod_name,tvector=timevector,seeds=seeds_vector)

#Estimate c
c_res<-crit.val(crit.val.boot =crit.val.boot_res)

#Estimate confidence band
conf_res<-conf.bands(theta = theta_fit,c=c_res,outerboot=outerboot_res,model_name = mod_name)

#Test decision
decision_res<-Test.decision(conf= conf_res,lambda=lambda_threshold)

#Is the H0 rejected for lambda=0
decision_res$result_sign

#If yes, whats the time span?
t_points_change(decision_res$timeframe_sign)

#Is the H0 rejected for the lambda chosen above
decision_res$result_relev

#If yes, whats the time span?
t_points_change(decision_res$timeframe_relev)




#Run the following code to estimate confidence intervals
#DISCLAMER: This can take a few hours

#For the analysis, we need to fix the number of time points of interest
#(beginning and end of a time period of significant change in expression)
n_tp_relev <- 2
#If wished, the case lambda=0 can be included
#However, the default is set to F
#n_tp_sign <- 2

#seeds for the analysis
set.seed(3)
seeds_ci_vector<-sample(1:100000000,B1*B3,replace=F)

#third bootstrap
T_CI_boot_res<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_fit,sd=sd_fit,model_name=mod_name,seeds=seeds_ci_vector,lambda=lambda_threshold)

#calculate quantiles
T_CI_quantiles_res<-t_CI_quantile(T_CI_boot_res,n_changepoints_relev=n_tp_relev)

#Check the results
T_CI_quantiles_res




############################
####Analysis - B-splines####
############################
#Now, we load the base function and add the b_splines function
source("./base/base_WDM.R")
source("./base/base_add_bsplines_WDM.R")

#create data frame for analysis
df_data <- data.frame(time=timevector,
                      count=response)

#Define Basis for the rest of the analysis 
#set degree of basis function
a <- 2
#set number of knots
b <- 2
Bbasis <- bSpline(df_data$time,degree=a,df=a+b)
Bbasis_deriv <- dbs(grid,degree=a,df=a+b)

#fit lm model
mod_fit <- lm(df_data$count ~ Bbasis)
sd_fit<-sqrt(RSS(mod_fit)/mod_fit$df.residual)

#proceed with application of the method
#set seeds
set.seed(13)
seeds_vector<-sample(1:100000000,500,replace=F)

#Outer bootstrap
outerboot_res<-bootstrap(mod=mod_fit,sd=sd_fit,B_out=500,tvector=timevector,Bb=Bbasis,Bb_deriv=Bbasis_deriv)

#Second level bootstrap
critval_boot_res<-crit.val.boot(mod=mod_fit,B_out=500,B_in=25,tvector=timevector,seeds=seeds_vector,outerboot=outerboot_res,Bb=Bbasis,Bb_deriv=Bbasis_deriv)

#Estimate critical value
c_res <- crit.val(critval_boot_res)

#Estimate confidence band
conf_res <- conf.bands(mod_fit,c_res,outerboot = outerboot_res,Bb_deriv=Bbasis_deriv)


#Test decision
decision_res<-Test.decision(conf= conf_res,lambda=lambda_threshold)

#Is the H0 rejected for lambda=0
decision_res$result_sign

#If yes, whats the time span?
t_points_change(decision_res$timeframe_sign)

#Is the H0 rejected for the lambda chosen above
decision_res$result_relev

#If yes, whats the time span?
t_points_change(decision_res$timeframe_relev)







#Run the following code to estimate confidence intervals
#DISCLAMER: This can take a few hours

#For the analysis, we need to fix the number of time points of interest
#(beginning and end of a time period of significant change in expression)
n_tp_relev <- 2
#If wished, the case lambda=0 can be included
#However, the default is set to F
#n_tp_sign <- 2

#seeds for the analysis
set.seed(3)
seeds_ci_vector<-sample(1:100000000,B1*B3,replace=F)

#third bootstrap
T_CI_boot_res<-t_CI_boot(Bb=Bbasis,Bb_deriv = Bbasis_deriv,B3=B3,B_out=B1,B_in=B2,tvector=timevector,mod=mod_fit,sd=sd_fit,seeds=seeds_vector,lambda=lambda_threshold)

#calculate quantiles
T_CI_quantiles_res<-t_CI_quantile(T_CI_boot_res,n_changepoints_relev=n_tp_relev)

#Check the results
T_CI_quantiles_res
