load("./case_study/case_study_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

######################
####Some Variables####
######################
B3<-500

######################
####Analysis Cd163####
######################
set.seed(3)
seeds_ci_example.d<-sample(1:100000000,B1*B3,replace=F)

#third bootstrap
T_CI_boot_Cd163<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_example.d,sd=sd_example.d,model_name="sigEmax",seeds=seeds_ci_example.d,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Cd163<-t_CI_quantile(T_CI_boot_Cd163,n_changepoints_sign=2,n_changepoints_relev=2)

#######################
####Analysis Fam83a####
#######################
set.seed(4)
seeds_ci_example.i<-sample(1:100000000,B1*B3,replace=F)


#third bootstrap
T_CI_boot_Fam83a<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_example.i,sd=sd_example.i,model_name="betaMod",seeds=seeds_ci_example.i,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Fam83a<-t_CI_quantile(T_CI_boot_Fam83a,n_changepoints_sign=2,n_changepoints_relev=2)


##############################################
####Analysis Dbp (WD) See case study aging####
##############################################


#######################
####Analysis Tm7sf2####
#######################
set.seed(7)
seeds_ci_example.quad<-sample(1:100000000,B1*B3,replace=F)


#third bootstrap
T_CI_boot_Tm7sf2<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_example.quad,sd=sd_example.quad,model_name="quadratic",seeds=seeds_ci_example.quad,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Tm7sf2<-t_CI_quantile(T_CI_boot_Tm7sf2,n_changepoints_sign=2,n_changepoints_relev=2)




####Save Working directory####
save.image(file="./case_study/case_study_ci_WDM.RData")
