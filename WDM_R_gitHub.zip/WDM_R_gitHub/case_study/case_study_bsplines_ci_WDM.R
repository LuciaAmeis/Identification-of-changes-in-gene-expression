load("./case_study/case_study_bsplines_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

######################
####Some Variables####
######################
B3<-500

#################################
####Analysis Cd163 - Bsplines####
#################################
#fix number of jump points identified for the different cases
n_changepoints_Cd163 <- c(2,2,2,2)
if(file.exists("./case_study/CI_Cd163_bsplines.RData")){
  load("./case_study/CI_Cd163_bsplines.RData")
}else{
  #to store
  Cd163_CI_Bsplines_boot_list <- list()
  Cd163_CI_Bsplines_quantile_list <- list()
for(i in 1:4){
#set preliminaries for case
set.seed(3+i)
seeds_ci_example<-sample(1:100000000,B1*B3,replace=F)
res <- comparison_B_splines_Cd163[[i]]
Bbasis <- bSpline(timevector,degree=res$degree,df=res$df,intercept = F)
Bbasis_deriv <- dbs(grid,degree=res$degree,df=res$df, intercept = F)
sd_Cd163<-sqrt(RSS(res$fit)/res$fit$df.residual)

#third bootstrap
T_CI_boot_Cd163_Bsplines<-t_CI_boot(Bb=Bbasis,Bb_deriv = Bbasis_deriv,B3=B3,B_out=B1,B_in=B2,tvector=timevector,mod=res$fit,sd=sd_Cd163,seeds=seeds_ci_example,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Cd163_Bsplines<-t_CI_quantile(T_CI_boot_Cd163_Bsplines,n_changepoints_relev=2)

#store
Cd163_CI_Bsplines_boot_list[[i]] <- T_CI_boot_Cd163_Bsplines
Cd163_CI_Bsplines_quantile_list[[i]] <- T_CI_quantiles_Cd163_Bsplines

}
  save(Cd163_CI_Bsplines_boot_list,Cd163_CI_Bsplines_quantile_list,file="./case_study/CI_Cd163_bsplines.RData")

}
##################################
####Analysis Fam83a - Bsplines####
##################################
#fix number of jump points identified for the different cases
n_changepoints_Fam83a <- c(2,4,4,4)
if(file.exists("./case_study/CI_Fam83a_bsplines.RData")){
  load("./case_study/CI_Fam83a_bsplines.RData")
}else{
  #to store
  Fam83a_CI_Bsplines_boot_list <- list()
  Fam83a_CI_Bsplines_quantile_list <- list()
  for(i in 1:4){
    #set preliminaries for case
    set.seed(4+i)
    seeds_ci_example<-sample(1:100000000,B1*B3,replace=F)
    res <- comparison_B_splines_Fam83a[[i]]
    Bbasis <- bSpline(timevector,degree=res$degree,df=res$df,intercept = F)
    Bbasis_deriv <- dbs(grid,degree=res$degree,df=res$df, intercept = F)
    sd_Fam83a<-sqrt(RSS(res$fit)/res$fit$df.residual)
    
    #third bootstrap
    T_CI_boot_Fam83a_Bsplines<-t_CI_boot(Bb=Bbasis,Bb_deriv = Bbasis_deriv,B3=B3,B_out=B1,B_in=B2,tvector=timevector,mod=res$fit,sd=sd_Fam83a,seeds=seeds_ci_example,lambda=lambda_45weeks)
    
    #calculate quantiles
    T_CI_quantiles_Fam83a_Bsplines<-t_CI_quantile(T_CI_boot_Fam83a_Bsplines,n_changepoints_relev=n_changepoints_Fam83a[i])
    
    #store
    Fam83a_CI_Bsplines_boot_list[[i]] <- T_CI_boot_Fam83a_Bsplines
    Fam83a_CI_Bsplines_quantile_list[[i]] <- T_CI_quantiles_Fam83a_Bsplines
    
  }
  save(Fam83a_CI_Bsplines_boot_list,Fam83a_CI_Bsplines_quantile_list,file="./case_study/CI_Fam83a_bsplines.RData")
  
}
####################################
####Analysis Dbp (WD) - Bsplines####
####################################
#fix number of jump points identified for the different cases
n_changepoints_Dbp <- c(4,4,4,4)
if(file.exists("./case_study/CI_Dbp_bsplines.RData")){
  load("./case_study/CI_Dbp_bsplines.RData")
}else{
  #to store
  Dbp_CI_Bsplines_boot_list <- list()
  Dbp_CI_Bsplines_quantile_list <- list()
  for(i in 1:4){
    #set preliminaries for case
    set.seed(6+i)
    seeds_ci_example<-sample(1:100000000,B1*B3,replace=F)
    res <- comparison_B_splines_Dbp[[i]]
    Bbasis <- bSpline(timevector,degree=res$degree,df=res$df,intercept = F)
    Bbasis_deriv <- dbs(grid,degree=res$degree,df=res$df, intercept = F)
    sd_Dbp<-sqrt(RSS(res$fit)/res$fit$df.residual)
    
    #third bootstrap
    T_CI_boot_Dbp_Bsplines<-t_CI_boot(Bb=Bbasis,Bb_deriv = Bbasis_deriv,B3=B3,B_out=B1,B_in=B2,tvector=timevector,mod=res$fit,sd=sd_Dbp,seeds=seeds_ci_example,lambda=lambda_45weeks)
    
    
    #calculate quantiles
    T_CI_quantiles_Dbp_Bsplines<-t_CI_quantile(T_CI_boot_Dbp_Bsplines,n_changepoints_relev=n_changepoints_Dbp[i])
    
    #store
    Dbp_CI_Bsplines_boot_list[[i]] <- T_CI_boot_Dbp_Bsplines
    Dbp_CI_Bsplines_quantile_list[[i]] <- T_CI_quantiles_Dbp_Bsplines
    
  }
  save(Dbp_CI_Bsplines_boot_list,Dbp_CI_Bsplines_quantile_list,file="./case_study/CI_Dbp_bsplines.RData")
  
}



#################################
####Analysis Tm7sf2- Bsplines####
#################################
#Since no alert was identified, there are no time points of interest
#n_changepoints_Tm7sf2 <- c(0,0,0,0)
#if(file.exists("./case_study/CI_Tm7sf2_bsplines.RData")){
#  load("./case_study/CI_Tm7sf2_bsplines.RData")
#}else{
#  Tm7sf2_CI_Bsplines_boot_list <- list()
#  Tm7sf2_CI_Bsplines_quantile_list <- list()
#for(i in 1:4){
#set.seed(3+i)
#seeds_ci_example<-sample(1:100000000,B1*B3,replace=F)
#res <- comparison_B_splines_Tm7sf2[[i]]
#Bbasis <- bSpline(timevector,degree=res$degree,df=res$df,intercept = F)
#Bbasis_deriv <- dbs(grid,degree=res$degree,df=res$df, intercept = F)
#sd_Tm7sf2<-sqrt(RSS(res$fit)/res$fit$df.residual)

#third bootstrap
#T_CI_boot_Tm7sf2_Bsplines<-t_CI_boot(Bb=Bbasis,Bb_deriv = Bbasis_deriv,B3=B3,B_out=B1,B_in=B2,tvector=timevector,mod=res$fit,sd=sd_Tm7sf2,seeds=seeds_ci_example,lambda=lambda_45weeks)

#calculate quantiles
#T_CI_quantiles_Tm7sf2_Bsplines<-t_CI_quantile(T_CI_boot_Tm7sf2_Bsplines,n_changepoints_relev=n_changepoints_Tm7sf2[i])

#Tm7sf2_CI_Bsplines_boot_list[[i]] <- T_CI_boot_Tm7sf2_Bsplines
#Tm7sf2_CI_Bsplines_quantile_list[[i]] <- T_CI_quantiles_Tm7sf2_Bsplines

#}
 # save(Tm7sf2_CI_Bsplines_boot_list,Tm7sf2_CI_Bsplines_quantile_list,file="./case_study/CI_Tm7sf2_bsplines.RData")
  
#}



####Save Working directory####
save.image(file="./case_study/case_study_bsplines_ci_WDM.RData")
