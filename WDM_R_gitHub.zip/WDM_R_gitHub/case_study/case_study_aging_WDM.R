load("./case_study/case_study_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)


#############################
#### Analysis of WD data ####
#############################
timevector_WD<-subset(example_Dbp$time,example_Dbp$diet=="WD")
example.WD_Dbp<-subset(example_Dbp,example_Dbp$diet=="WD")$count

#sigmoid
mod_example.WD_Dbp_sigmoid <- suppressMessages(fitMod(dose=timevector, resp=example.WD_Dbp, model="sigEmax"))
AIC(mod_example.WD_Dbp_sigmoid)
#143.7832

#beta
mod_example.WD_Dbp_beta <- suppressMessages(fitMod(dose=timevector, resp=example.WD_Dbp, model="betaMod"))
AIC(mod_example.WD_Dbp_beta)
#148.4274

#exp
mod_example.WD_Dbp_exp <- suppressMessages(fitMod(dose=timevector, resp=example.WD_Dbp, model="exponential"))
AIC(mod_example.WD_Dbp_exp)
#141.8876

#quad
mod_example.WD_Dbp_quad <- suppressMessages(fitMod(dose=timevector, resp=example.WD_Dbp, model="quadratic"))
AIC(mod_example.WD_Dbp_quad)
#146.9918

#Since the AIC is smaller for the sigEmax model, we will continue with it
#Extract variables
sd_example.WD_Dbp <- sqrt(mod_example.WD_Dbp_exp$RSS/mod_example.WD_Dbp_exp$df)
theta_example.WD_Dbp <- unname(coef(mod_example.WD_Dbp_exp))

#Model function
Dbp.WD_modfunction<-function(t){
  count<-modelfunction_exp(t,theta_example.WD_Dbp)
  return(count)
}


#First derivative and absolute value of first derivative
Dbp.WD_modderiv<-function(t){
  count<-modelderiv_exp(t,theta_example.WD_Dbp)
  return(count)
}

Dbp.WD_modderiv_abs<-function(t){
  count<-modelderiv_exp(t,theta_example.WD_Dbp)
  return(abs(count))
}


#Perform analysis
set.seed(23)
#draw seeds for inner bootstrap
seeds_example.WD_Dbp<-sample(1:100000000,B1,replace=F)

outerboot_example.WD_Dbp<-bootstrap(theta=theta_example.WD_Dbp,sd=sd_example.WD_Dbp,B_out=B1,tvector=timevector,model_name = "exponential")
crit.val.boot_example.WD_Dbp<-crit.val.boot(theta = theta_example.WD_Dbp,B_out=B1,B_in=B2,outerboot_example.WD_Dbp,model_name = "exponential",tvector=timevector,seeds=seeds_example.WD_Dbp)
c_example.WD_Dbp<-crit.val(crit.val.boot =crit.val.boot_example.WD_Dbp)
conf_example.WD_Dbp<-conf.bands(theta = theta_example.WD_Dbp,c=c_example.WD_Dbp,outerboot=outerboot_example.WD_Dbp,model_name = "exponential")
decision_example.WD_Dbp<-Test.decision(conf= conf_example.WD_Dbp,lambda=lambda_45weeks)

decision_example.WD_Dbp$result_sign
#1

decision_example.WD_Dbp$result_relev
#1

relev_example.WD_Dbp<-t_points_change(decision_example.WD_Dbp$timeframe_relev)
#beginning       end 
#35.4      45.0  

#relevant
(model_exp(relev_example.WD_Dbp[2],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3])-model_exp(relev_example.WD_Dbp[1],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3]))
#-2.274757
(model_exp(relev_example.WD_Dbp[2],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3])-model_exp(relev_example.WD_Dbp[1],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3]))/(relev_example.WD_Dbp[2]-relev_example.WD_Dbp[1])
#-0.2369538 
(relev_example.WD_Dbp[2]-relev_example.WD_Dbp[1])
#9.6


#Decision for half the study time
decision_example.WD_Dbp_27_5w<-Test.decision(conf= conf_example.WD_Dbp,lambda=lambda_27_5_weeks)

#check for beginning and end
relev_example.WD_Dbp_27_5w<-t_points_change(decision_example.WD_Dbp_27_5w$timeframe_relev)
#beginning       end 
#36             45 

#############################
#### Analysis of SD data ####
#############################
timevector_SD<-subset(example_Dbp$time,example_Dbp$diet=="SD")
example.SD_Dbp<-subset(example_Dbp,example_Dbp$diet=="SD")$count

mod_example.SD_Dbp_sigmoid <- suppressMessages(fitMod(dose=timevector_SD, resp=example.SD_Dbp, model="sigEmax"))
AIC(mod_example.SD_Dbp_sigmoid)
#81.63901

#beta
mod_example.SD_Dbp_beta <- suppressMessages(fitMod(dose=timevector_SD, resp=example.SD_Dbp, model="betaMod"))
AIC(mod_example.SD_Dbp_beta)
#88.70041

#exp
mod_example.SD_Dbp_exp <- suppressMessages(fitMod(dose=timevector_SD, resp=example.SD_Dbp, model="exponential"))
AIC(mod_example.SD_Dbp_exp)
#79.3514

#quad
mod_example.SD_Dbp_quad <- suppressMessages(fitMod(dose=timevector_SD, resp=example.SD_Dbp, model="quadratic"))
AIC(mod_example.SD_Dbp_quad)
#90.89101

#Since the AIC is smaller for the exponential model, we will continue with it
#Extract variables
sd_example.SD_Dbp <- sqrt(mod_example.SD_Dbp_exp$RSS/mod_example.SD_Dbp_exp$df)
theta_example.SD_Dbp <- unname(coef(mod_example.SD_Dbp_exp))

#Model function
Dbp.SD_modfunction<-function(t){
  count<-modelfunction_exp(t,theta_example.SD_Dbp)
  return(count)
}

#First derivative and absolute value of first derivative
Dbp.SD_modderiv<-function(t){
  count<-modelderiv_exp(t,theta_example.SD_Dbp)
  return(count)
}

Dbp.SD_modderiv_abs<-function(t){
  count<-modelderiv_exp(t,theta_example.SD_Dbp)
  return(abs(count))
}



#Perform analysis
set.seed(24)
#draw seeds for inner bootstrap
seeds_example.SD_Dbp<-sample(1:100000000,B1,replace=F)

outerboot_example.SD_Dbp<-bootstrap(theta=theta_example.SD_Dbp,sd=sd_example.SD_Dbp,B_out=B1,tvector=timevector_SD,model_name = "exponential")
crit.val.boot_example.SD_Dbp<-crit.val.boot(theta = theta_example.SD_Dbp,B_out=B1,B_in=B2,outerboot_example.SD_Dbp,model_name = "exponential",tvector=timevector_SD,seeds=seeds_example.SD_Dbp)
c_example.SD_Dbp<-crit.val(crit.val.boot =crit.val.boot_example.SD_Dbp)
conf_example.SD_Dbp<-conf.bands(theta = theta_example.SD_Dbp,c=c_example.SD_Dbp,outerboot=outerboot_example.SD_Dbp,model_name = "exponential")
decision_example.SD_Dbp<-Test.decision(conf= conf_example.SD_Dbp,lambda=lambda_45weeks)
decision_example.SD_Dbp$result_sign
#1

decision_example.SD_Dbp$result_relev
#1

relev_example.SD_Dbp<-t_points_change(decision_example.SD_Dbp$timeframe_relev)
#beginning       end 
# 33.7      45.0 

#relevant
(model_exp(relev_example.SD_Dbp[2],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3])-model_exp(relev_example.SD_Dbp[1],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3]))
#-3.069856 
(model_exp(relev_example.SD_Dbp[2],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3])-model_exp(relev_example.SD_Dbp[1],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3]))/(relev_example.SD_Dbp[2]-relev_example.SD_Dbp[1])
#-0.2716687 
(relev_example.SD_Dbp[2]-relev_example.SD_Dbp[1])
#11.3 


########################################################
####Confidence intervals for time frames of interest####
########################################################
#Number of first level bootstrap runs
B3<-500
if(file.exists("./case_study/Aging_CI.RData")){
  load("./case_study/Aging_CI.RData")
} else{
####WD case####
set.seed(300)
seeds_ci_Dbp.WD<-sample(1:100000000,B1*B3,replace=F)

#third bootstrap
T_CI_boot_Dbp.WD<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_example.WD_Dbp,sd=sd_example.WD_Dbp,model_name="exponential",seeds=seeds_ci_Dbp.WD,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Dbp.WD<-t_CI_quantile(T_CI_boot_Dbp.WD,n_changepoints_sign=2,n_changepoints_relev=2)

####SD case####
set.seed(301)
seeds_ci_Dbp.SD<-sample(1:100000000,B1*B3,replace=F)

#third bootstrap
T_CI_boot_Dbp.SD<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_example.SD_Dbp,sd=sd_example.SD_Dbp,model_name="exponential",seeds=seeds_ci_Dbp.SD,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Dbp.SD<-t_CI_quantile(T_CI_boot_Dbp.SD,n_changepoints_sign=2,n_changepoints_relev=2)

####Differnce####

T_CI_diff<-t_CI_quantile_diff(decision_boot1=T_CI_boot_Dbp.SD,decision_boot2 =T_CI_boot_Dbp.WD,n_changepoints_relev = 2)
save(seeds_ci_Dbp.WD,T_CI_boot_Dbp.WD,T_CI_quantiles_Dbp.WD,seeds_ci_Dbp.SD,T_CI_boot_Dbp.SD,T_CI_quantiles_Dbp.SD,T_CI_diff
,file="./case_study/Aging_CI.RData")
}

####Save Working directory####
save.image(file="./case_study/case_study_aging_WDM.RData")
