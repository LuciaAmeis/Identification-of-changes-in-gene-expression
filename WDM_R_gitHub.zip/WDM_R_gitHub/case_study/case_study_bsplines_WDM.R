load("./base/base_add_bsplines_WDM.RData")
load("./data_preparation/data_preparation_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)
######################
####Some variables####
######################
alpha <- 0.05 #significance level of the test
B1 <- 500 # "outer" bootstrap for critical value (=quantile)
B2 <- 25 # "inner" bootstrap for standard error
# here we construct a grid 


epsilon <- 0.1
grid <- seq(0.1,45,epsilon) #45 because we regard 48 weeks starting at week 3
#and we will transform age to time on study
#Please change if another data set is regarded

#Some specific parameters used for the analysis later
timepoints <- unique(example.WD_Cd163$time) #different time points
timevector<-example.WD_Cd163$time #vector of time points
scal<-max(timevector)*1.2

lambda_45weeks<-lambda.fct(tdiff=45,lambda_absolute = log2(1.5)) #45 weeks on study

lambda_3weeks<-lambda.fct(tdiff=3,lambda_absolute = log2(1.5)) #3 weeks 
lambda_9weeks<-lambda.fct(tdiff=9,lambda_absolute = log2(1.5)) #9 weeks  
lambda_15weeks<-lambda.fct(tdiff=15,lambda_absolute = log2(1.5)) #15 weeks  
lambda_21weeks<-lambda.fct(tdiff=21,lambda_absolute = log2(1.5)) #21 weeks 
lambda_27weeks<-lambda.fct(tdiff=27,lambda_absolute = log2(1.5)) #27.5 weeks  
lambda_33weeks<-lambda.fct(tdiff=33,lambda_absolute = log2(1.5)) #33 weeks  
lambda_39weeks<-lambda.fct(tdiff=39,lambda_absolute = log2(1.5)) #39 weeks  

lambda_27_5_weeks<-lambda.fct(tdiff=27.5,lambda_absolute = log2(1.5)) #33 weeks 

######################
####Analysis Cd163####
######################
data_example.d <- example.WD_Cd163$count
data.frame_example.d <- data.frame(time=timevector,
                                   count=data_example.d)

#Analysis for different combinations of knots and degree of basis function
comparison_B_splines_Cd163 <- list()
for(i in 2:3){
  for(j in 2:3){
    #Define Basis for the rest of the analysis for this gene
    Bbasis <- bSpline(data.frame_example.d$time,degree=i,df=i+j)
    Bbasis_deriv <- dbs(grid,degree=i,df=i+j)
    
    #fit lm model
    model_fit <- lm(data.frame_example.d$count ~ Bbasis)
    sd_fit<-sqrt(RSS(model_fit)/model_fit$df.residual)
    
    #summary(model)
    
    
    #coef <- coef(model)
    
    #proceed with application of the method
    set.seed(13+i+j)
    seeds_example<-sample(1:100000000,500,replace=F)
    boot_fit<-bootstrap(mod=model_fit,sd=sd_fit,B_out=500,tvector=timevector,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    critval_boot_fit<-crit.val.boot(mod=model_fit,B_out=500,B_in=25,tvector=timevector,seeds=seeds_example,outerboot=boot_fit,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    c_fit <- crit.val(critval_boot_fit)
    conf_fit <- conf.bands(model_fit,c_fit,outerboot = boot_fit,Bb_deriv=Bbasis_deriv)
    
    #store
    res <- list("degree"=i,"df"=i+j,"knot"=knots(Bbasis),"fit"=model_fit,"c"=c_fit,"conf"=conf_fit)
    comparison_B_splines_Cd163[[length(comparison_B_splines_Cd163)+1]] <- res
    
  }

}


#######################
####Analysis Fam83a####
#######################
data_example.i <- example.WD_Fam83a$count
data.frame_example.i <- data.frame(time=timevector,
                                   count=data_example.i)
#Analysis for different combinations of knots and degree of basis function
comparison_B_splines_Fam83a <- list()
for(i in 2:3){
  for(j in 2:3){
    #Define Basis for the rest of the analysis for this gene
    Bbasis <- bSpline(data.frame_example.i$time,degree=i,df=i+j)
    Bbasis_deriv <- dbs(grid,degree=i,df=i+j)
    
    #model fit with lm
    model_fit <- lm(data.frame_example.i$count ~ Bbasis)
    #summary(model)
    sd_fit<-sqrt(RSS(model_fit)/model_fit$df.residual)
    
    
    #coef <- coef(model)
    
    #apply method
    set.seed(53+i+j)
    seeds_example<-sample(1:100000000,500,replace=F)
    boot_fit<-bootstrap(mod=model_fit,sd=sd_fit,B_out=500,tvector=timevector,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    critval_boot_fit<-crit.val.boot(mod=model_fit,B_out=500,B_in=25,tvector=timevector,seeds=seeds_example,outerboot=boot_fit,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    c_fit <- crit.val(critval_boot_fit)
    conf_fit <- conf.bands(model_fit,c_fit,outerboot = boot_fit,Bb_deriv=Bbasis_deriv)
    
    #store
    res <- list("degree"=i,df=i+j,"knot"=knots(Bbasis),"fit"=model_fit,"c"=c_fit,"conf"=conf_fit)
    comparison_B_splines_Fam83a[[length(comparison_B_splines_Fam83a)+1]] <- res
    
  }}





#########################
####Analysis Dbp (WD)####
#########################
data_example.Dbp<-subset(example_Dbp,diet=="WD")$count
data.frame_example.Dbp <- data.frame(time=timevector,
                                     count=data_example.Dbp)

#Analysis for different combinations of knots and degree of basis function
comparison_B_splines_Dbp <- list()
for(i in 2:3){
  for (j in 2:3) {
    #Define Basis for the rest of the analysis for this gene
    Bbasis <- bSpline(data.frame_example.Dbp$time,degree=i,df=j+i)
    Bbasis_deriv <- dbs(grid,degree=i, df=j+i)
    
    #modle fit with lm
    model_fit <- lm(data.frame_example.Dbp$count ~ Bbasis)
    #summary(model)
    sd_fit<-sqrt(RSS(model_fit)/model_fit$df.residual)
    
    
    #coef <- coef(model)
    
    #apply method 
    set.seed(33+i+j)
    seeds_example<-sample(1:100000000,500,replace=F)
    boot_fit<-bootstrap(mod=model_fit,sd=sd_fit,B_out=500,tvector=timevector,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    critval_boot_fit<-crit.val.boot(mod=model_fit,B_out=500,B_in=25,tvector=timevector,seeds=seeds_example,outerboot=boot_fit,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    c_fit <- crit.val(critval_boot_fit)
    conf_fit <- conf.bands(model_fit,c_fit,outerboot = boot_fit,Bb_deriv=Bbasis_deriv)
    
    #store
    res <- list("degree"=i,df=i+j,"knot"=knots(Bbasis),"fit"=model_fit,"c"=c_fit,"conf"=conf_fit)
    comparison_B_splines_Dbp[[length(comparison_B_splines_Dbp)+1]] <- res
    
}
}


#######################
####Analysis Tm7sf2####
#######################
data_example.Tm7sf2<-subset(example_Tm7sf2,example_Tm7sf2$diet=="WD")$count
data.frame_example.Tm7sf2 <- data.frame(time=timevector,
                                        count=data_example.Tm7sf2)

#Analysis for different combinations of knots and degree of basis function
comparison_B_splines_Tm7sf2 <- list()
for(i in 2:3){
  for(j in 2:3){
    #Define Basis for the rest of the analysis for this gene
    Bbasis <- bSpline(data.frame_example.Tm7sf2$time,degree=i,df=i+j)
    Bbasis_deriv <- dbs(grid,degree=i,df=i+j)
    
    #model fit with lm
    model_fit <- lm(data.frame_example.Tm7sf2$count ~ Bbasis)
    #summary(model)
    sd_fit<-sqrt(RSS(model_fit)/model_fit$df.residual)
    
    
   # coef_fit <- coef(model)
    
    #apply method
    set.seed(43+i+j)
    seeds_example<-sample(1:100000000,500,replace=F)
    boot_fit<-bootstrap(mod=model_fit,sd=sd_fit,B_out=500,tvector=timevector,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    critval_boot_fit<-crit.val.boot(mod=model_fit,B_out=500,B_in=25,tvector=timevector,seeds=seeds_example,outerboot=boot_fit,Bb=Bbasis,Bb_deriv=Bbasis_deriv)
    c_fit <- crit.val(critval_boot_fit)
    conf_fit <- conf.bands(model_fit,c_fit,outerboot = boot_fit,Bb_deriv=Bbasis_deriv)
    
    #store
    res <- list("degree"=i,df=i+j,"knot"=knots(Bbasis),"fit"=model_fit,"c"=c_fit,"conf"=conf_fit)
    comparison_B_splines_Tm7sf2[[length(comparison_B_splines_Tm7sf2)+1]] <- res
    
  }
}




####Save Working directory####
save.image(file="./case_study/case_study_bsplines_WDM.RData")
