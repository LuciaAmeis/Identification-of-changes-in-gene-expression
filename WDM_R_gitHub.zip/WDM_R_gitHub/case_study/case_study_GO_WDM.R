#Load previous RData
load("./base/base_WDM.RData")
load("./data_preparation/data_preparation_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)
######################
####Some variables####
######################
epsilon <- 0.1
grid <- seq(0.1,45,epsilon) #45 because we regard 48 weeks starting at week 3
#and we will transform age to time on study
#Please change if another data set is regarded

#Some specific parameters used for the analysis later
#See data preparation
timepoints <- c(0,  3,  9, 15, 21, 27, 33, 39, 45) #different time points
timevector<-c(0,  0,  0,  0,  0,  
              3,  3,  3,  3,  3,  
              9,  9,  9,  9,  9,
              15, 15, 15, 15, 15, 
              21, 21, 21, 21, 21, 
              27, 27, 27, 27, 27, 
              33, 33, 33, 33, 33, 
              39, 39, 39, 39,
              45, 45, 45, 45, 45, 45, 45, 45)#vector of time points
scal<-54

lambda_45weeks<-lambda.fct(tdiff=45,lambda_absolute = log2(1.5)) #45 weeks on study

alpha <- 0.05 #significance level of the test
B1 <- 500 # "outer" bootstrap for critical value (=quantile)
B2 <- 25 # "inner" bootstrap for standard error

#######################################################
####GO Preparation (as adopted from Dr. Julia Duda)####
#######################################################
deseqres_to_pretty_table <- function(res, log2fc_thres = log2(1.5), padj_thres = 0.05){
  res_pretty <- as.data.frame(res) %>%
    rownames_to_column("gene_ensembl") %>%
    left_join(., as.data.frame(rowData(gse)[, c("gene_id", "gene_name")]),
              by = c("gene_ensembl" = "gene_id")) %>%
    dplyr::select(gene_ensembl, gene_name, everything()) %>%
    mutate(regulation = "not_signif") %>%
    mutate(regulation = case_when((padj < padj_thres & log2FoldChange > log2fc_thres) ~ "up",
                                  (padj < padj_thres & log2FoldChange < - log2fc_thres) ~ "down",
                                  TRUE ~ "not_signif"))
  return(res_pretty)
}


topGO_analysis <- function(interesting, all_genes, methods = "elim", topNodes = c(1000, "all")){
  
  
  
  # create topGo object
  go_data <- topGOdataObj(interesting.genes = interesting,
                          gene.names = all_genes)
  
  # apply method to topGo Object
  res <- vector(mode = "list", length = 2)
  names(res) <- c("go_res", "gen_table")
  res$go_res <- runTest(go_data, algorithm = methods, statistic = "fisher")
  
  # res$weight.log <- runTest(GOdata, algorithm = "weight", statistic = "fisher", sigRatio = "log")
  # res$parentchild.intersect <- runTest(GOdata, algorithm = "parentchild", statistic = "fisher", joinFun = "intersect")
  
  topNodes <- topNodes[1]
  if(topNodes == "all") topNodes <- length(res$go_res@score)
  res$gen_table <- GenTable(go_data,
                            go_pval = res$go_res,
                            orderBy = "go_pval", topNodes = as.numeric(topNodes))
  
  
  res$gen_table$go_pval <- as.numeric(res$gen_table$go_pval)
  if(any(is.na(res$gen_table$go_pval))){
    res$gen_table$go_pval[is.na(res$gen_table$go_pval)] <- 1e-30
  }
  
  ## adjust the p-values
  res$gen_table$go_pval_adj <- p.adjust(res$gen_table$go_pval, method = "fdr")
  
  return(res)
  
}

# hilsfunktion
topGOdataObj <- function(interesting.genes, gene.names = gene_id_all, node.size = 5) {
  
  gene_list <- factor(as.integer(gene.names %in% interesting.genes))
  names(gene_list) <- gene.names
  
  GOdata <- new("topGOdata",
                ontology = "BP",
                allGenes = gene_list,
                nodeSize = node.size,
                annot = annFUN.org,
                mapping ="org.Mm.eg.db",
                ID = "ensembl")
}


######################
####Pre-selection#####
######################
#Shrink
resultsNames(dds)
res_diet_weeks_WD_48_vs_SD_3 <- lfcShrink(dds, coef = "diet_weeks_WD_48_vs_SD_3")

#give results a nice form
dds_table_WD_48_vs_SD_3<-deseqres_to_pretty_table(res_diet_weeks_WD_48_vs_SD_3,log2fc_thres = log2(1.5),padj_thres = 0.05)
View(dds_table_WD_48_vs_SD_3)

#we regard the top 0.1% genes with change comparing the good diet at the beginning
#vs the WD diet at the end of study
dds_table_WD_48_vs_SD_3_subset<-subset(dds_table_WD_48_vs_SD_3,dds_table_WD_48_vs_SD_3$padj<0.05    )



##################
####Estimation####
##################
gene_name<-vector("logical",nrow(dds_table_WD_48_vs_SD_3_subset))
data.frames_list<-list()
Count_list<-list()
for(i in 1:nrow(dds_table_WD_48_vs_SD_3_subset)){
  gene<-dds_table_WD_48_vs_SD_3_subset$gene_name[i]
  gene_name[i]<-gene
  #Gene examples
  #extract example
  normalized_gene<-vsd[which(rowData(vsd)$gene_name==gene),]
  
  #create data set with gene specific count data
  counts.gen<-as.numeric(assay(normalized_gene,1))
  time<-as.numeric(colData(gse)$weeks) #we use the original weeks since they were 
  #were changed to 1-9 in the vsd object
  time_beginningofstudy<-time-3
  mouse<-as.factor(colData(vsd)$mouse)
  diet<-as.factor(colData(vsd)$diet)
  
  
  example_gene<-data.frame(
    "count"= counts.gen,
    "time"=time_beginningofstudy,
    "mouse"=mouse,
    "diet"=diet
  )
  
  data.frames_list[[i]]<-example_gene
  
  #restrict to WD case
  example.WD_gene<-subset(example_gene,example_gene$diet=="WD")
  
 Count_list[[i]]<-example.WD_gene$count
}

test_counts<-numeric(length(Count_list))
for(i in 1:length(Count_list)){
  test_counts[i]<-length(Count_list[[i]])
}

which(test_counts!=47)
Count_list<-Count_list[-which(test_counts!=47)]
dds_table_WD_48_vs_SD_3_subset<-dds_table_WD_48_vs_SD_3_subset[-which(test_counts!=47),]


dds_table_WD_48_vs_SD_3_subset<-dds_table_WD_48_vs_SD_3_subset[-9342,]
Count_list<-Count_list[-9342]

length(Count_list)
#9881

#save.image(file="./case_study/GO_intermediate.RData")
#load("./case_study/GO_intermediate.RData")

####All Genes sigEmax####

if(file.exists("./case_study/Gene_results.RData")){
  load("./case_study/Gene_results.RData")
} else{
Gene_results<-list()
for(i in 1:length(Count_list)){
  data<-Count_list[[i]]
  
  set.seed(111+i)
  seeds_example<-sample(1:100000000,B1,replace=F)
  
  Gene_results[[i]]<-Full.Analysis(dataset=data,tvector=timevector,model_name="sigEmax",B_out=B1,B_in = B2,lambda=lambda_45weeks,seeds = seeds_example)
}
save(Gene_results,file="./case_study/Gene_results.RData")
}

Gene_results_df<-data.frame(grid,Gene_results[[1]]$conf)
names_df<-paste0(rep("y",times=(length(Gene_results))), "_", 1:length(Gene_results))
for(i in 2:length(Gene_results)){
  Gene_results_df<-cbind(Gene_results_df,Gene_results[[i]]$conf)
}

colnames(Gene_results_df)<-c("x",names_df)


Gene_results_melted<-melt(Gene_results_df,id="x")


t_frame_dds_subset<-matrix(data=NA,nrow=length(Gene_results),ncol=2)
results_genes<-as.numeric(length(Gene_results))
for(i in 1:length(Gene_results)){
  decision<-Gene_results[[i]]$decision[[1]]
  results_genes[i]<-decision$result_relev
}


for(i in 1:length(Gene_results)){
  decision<-Gene_results[[i]]$decision[[1]]
  if(results_genes[i]==1){
    t_frame_dds_subset[i,1]<-min(decision$timeframe_relev)
    t_frame_dds_subset[i,2]<-max(decision$timeframe_relev)
  } else{
    t_frame_dds_subset[i,1]<-NA
    t_frame_dds_subset[i,2]<-NA
  }
}

t_frame_dds_subset_oi<-t_frame_dds_subset[which(t_frame_dds_subset[,1]>10&t_frame_dds_subset[,2]<25),]
length(which(t_frame_dds_subset[,1]>10&t_frame_dds_subset[,2]<25))
#569

genes_of_interest<-dds_table_WD_48_vs_SD_3_subset[which(t_frame_dds_subset[,1]>10&t_frame_dds_subset[,2]<25),]

set.seed(100)
GO_Analysis<-topGO_analysis(genes_of_interest$gene_ensembl, dds_table_WD_48_vs_SD_3_subset$gene_ensembl, methods = "elim", topNodes ="all")
write_xlsx(list(GO_Analysis$gen_table), path = "./plots_tables/GO_WDM.xlsx")
View(GO_Analysis$gen_table)
GO_Analysis$gen_table[1:20,]
write_xlsx(list(GO_Analysis$gen_table[1:20,]), path = "./plots_tables/GO_WDM_1to20.xlsx")


####Save Working directory####
save.image(file="./case_study/case_study_GO_WDM.RData")

