#############
####Start####
#############
#Library
library(tximeta)
library(DESeq2)
library(ashr) # For shrinkage of "only due to noise" large log2FCs
library(tidyr)
library(tibble)
library(DT) # for nice tables
library(drc)
library(matrixStats)
library(DoseFinding)
library(parallel)
library(foreach)
library(doParallel)
library(dplyr)
library(doSNOW)
library(reshape)
library(ggplot2)
library(topGO) # for gene set enrichment / GO analysis
library(patchwork)
library(writexl)


#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)

#Set Workingdirectory (Please change before running)
setwd("Please set")



###################
####Preparation####
###################
#Here all functions needed for the analysis and simulation are defined. Please
#always run first.
source("./base/base_WDM.R")


#Here we prepare the data set for analysis and basis of the simulation study
#The genes Cd163 and Dpb are extracted from the data set
source("./data_preparation/data_preparation_WDM.R")

#Simulation scenarios
source("./simulation/simulation_scenarios_WDM_all.R")

#Simulation intermediate results
#WARNING since the simulation runs take a lot of time, we recommend
#to run each scenario on a server
source("./simulation/simulation_intermediate_WDM_alt.R")

###############
####Results####
###############
#Simulation results
source("./simulation/simulation_results")

#Case study example and Cd163
source("./case_study/case_study_WDM.R")

#CIs for the case study 
#WARNING: This might take a few hours
source("./case_study/case_study_ci_WDM.R")

#Case study aging
#WARNING: This might take a few hours
source("./case_study/case_study_aging_WDM.R")

#Case study GO analysis
#WARNING since the pre-selection take a lot of time, we recommend
#to run each scenario on a server 
source("./case_study/case_study_GO_WDM.R")

#Plot generation
#Please run last
source("./plot_generation/plot_generation_WDM.R")
