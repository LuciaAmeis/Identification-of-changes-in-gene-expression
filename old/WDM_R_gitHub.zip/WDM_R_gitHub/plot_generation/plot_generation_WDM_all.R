load("./case_study/case_study_WDM.RData")
load("./case_study/case_study_aging_WDM.RData")
load("./case_study/case_study_GO_WDM.RData")
load("./simulation/simulation_scenarios_WDM_all.RData")
load("./simulation/simulation_intermediate_WDM_all.RData")
load("./simulation/simulation_results_WDM_all.RData")
############################
####Figures in Section 2####
############################

#Figure 1 A to explain the time points of interest
which.max(conf_example.d-lambda_45weeks)
#175

Toi_p<-ggplot(data=data.frame(x=grid,y=Cd163_modderiv_abs(grid),z=conf_example.d),mapping = aes(x = x)) +
  geom_line(aes(x=x,y=y,color="black"),linetype="solid") +
  geom_line(aes(x=x,y=z,color="royalblue"),linetype="solid") +
  scale_color_manual(values = c("black","royalblue"),labels=c("Model Derivative","Confidence Band")) +
  ylim(-0.2,0.3) +
  xlim(12,22) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=min(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  geom_vline(xintercept=max(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  geom_vline(xintercept=grid[175],linetype="dotted",col="goldenrod3") +
  annotate(geom = "line", x = c(grid[175], grid[175]), y = c(lambda_45weeks, conf_example.d[175]), fill = "goldenrod3",
           color = "goldenrod3", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(min(decision_example.d$timeframe_relev), max(decision_example.d$timeframe_relev)), y = c(-0.15,-0.15),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=-0.15+0.02, x=18, label=expression(tilde(S)), size = 3.5,col="darkorange") +
  annotate("text",y=lambda_45weeks+0.01, x=12.5, label=expression(lambda), size = 4,col="orangered2",fontface="plain") +
  annotate("text",y=-0.1, x=min(decision_example.d$timeframe_relev)-0.005, label=expression(t["start"]), size = 4,col="orangered2",fontface="plain") +
  annotate("text",y=-0.1, x=max(decision_example.d$timeframe_relev)-0.005, label=expression(t["end"]), size = 4,col="orangered2",fontface="plain") +
  annotate("text",y=-0.05, x=grid[175]-0.005, label=expression(paste(t["max"])), size = 4,col="goldenrod3",fontface="plain") +
  annotate("text",y=lambda_45weeks+0.02, x=grid[175]+1, label=expression(L^alpha~(t~","~ hat(theta))~-~lambda), size = 4,col="goldenrod3",fontface="plain") +
  theme(axis.text=element_blank(), axis.ticks.x=element_blank(),axis.title=element_text(size=9),legend.text=element_text(size=10),legend.title=element_blank(),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

Toi_p
ggsave("./plots_tables/015_Timepoints_of_interest.pdf",width=15,height=10,unit="cm")

#Figure 1 B explaining tildeT
#Example sigmoid Emax
#model function
p_sig_mod<-ggplot(data=data.frame(x=grid,y=Cd163_modfunction(grid)),mapping = aes(x = x,y=y)) +
  ylim(6.5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("4pLL") +
  geom_vline(xintercept=min(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  geom_vline(xintercept=max(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  annotate(geom = "line", x = c(min(decision_example.d$timeframe_relev), max(decision_example.d$timeframe_relev)), y = c(6.5, 6.5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=6.5+0.2, x=17.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_blank(), axis.ticks.x=element_blank(),axis.title=element_text(size=9),legend.text=element_text(size=8),plot.title = element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

p_sig_mod
ggsave("./plots_tables/Tildet_sigmoid_mod.pdf",width=10,height=10,unit="cm")

#first derivative
p_sig_deriv<-ggplot(data=data.frame(x=grid,y=Cd163_modderiv_abs(grid),z=conf_example.d),mapping = aes(x = x)) +
  geom_line(aes(x=x,y=y,color="black"),linetype="solid") +
  geom_line(aes(x=x,y=z,color="royalblue"),linetype="solid") +
  scale_color_manual(values = c("black","royalblue"),labels=c("Model Derivative","Confidence Band")," ") +
  ylim(-0.1,0.3) +
  xlim(0,45) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  ggtitle("4pLL") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=min(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  geom_vline(xintercept=max(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  annotate(geom = "line", x = c(min(decision_example.d$timeframe_relev), max(decision_example.d$timeframe_relev)), y = c(-0.05, -0.05),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=lambda_45weeks+0.02, x=40, label=expression(lambda), size = 3.5,col="orangered2") +
  annotate("text",y=-0.03, x=17.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_blank(), axis.ticks.x=element_blank(),axis.title=element_text(size=9),legend.text=element_text(size=10),plot.title = element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

p_sig_deriv
ggsave("./plots_tables/Tildet_sigmoid_deriv.pdf",width=15,height=10,unit="cm")



#Example beta
#model function
p_beta_mod<-ggplot(data=data.frame(x=grid,y=Fam83a_modfunction(grid)),mapping = aes(x = x,y=y)) +
  ylim(6.5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Beta") +
  geom_vline(xintercept=0.3,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=24.9,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=42.7,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=45,linetype="dashed",col="orangered2") +
  annotate(geom = "line", x = c(0.3, 24.9), y = c(6.5, 6.5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(42.7, 45), y = c(6.5, 6.5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=6.5+0.2, x=3, label=expression(S[1]), size = 3,col="darkorange") +
  annotate("text",y=6.5+0.2, x=43.8, label=expression(S[2]), size = 3,col="darkorange") +
  theme(axis.text=element_blank(), axis.ticks.x=element_blank(),axis.title=element_text(size=9),legend.text=element_text(size=8),plot.title = element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

p_beta_mod
ggsave("./plots_tables/Tildet_beta_mod.pdf",width=10,height=10,unit="cm")

which.max(Fam83a_modfunction(grid))
#379

#one possible confidcence band
p_beta_deriv1<-ggplot(data=data.frame(x=grid,y=Fam83a_modderiv_abs(grid),z=c(conf_example.i[1:379],seq(-0.0257536639,lambda_45weeks,by=0.000546))),mapping = aes(x = x)) +
  geom_line(aes(x=x,y=y,color="black"),linetype="solid") +
  geom_line(aes(x=x,y=z,color="royalblue"),linetype="solid") +
  scale_color_manual(values = c("black","royalblue"),labels=c("Model Derivative","Confidence Band")) +
  ylim(-0.05,0.2) +
  xlab("Time (Weeks)") +
  ggtitle("Beta") +
  ylab("Change in gene count") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.3,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=24.9,linetype="dashed",col="orangered2") +
  annotate(geom = "line", x = c(0.3, 24.9), y = c(-0.05, -0.05),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=lambda_45weeks+0.005, x=5, label=expression(lambda), size = 3.5,col="orangered2") +
  annotate("text",y=-0.05+0.005, x=12, label=expression(S[1]), size = 3.3,col="darkorange") +
  theme(axis.text=element_blank(), axis.ticks.x=element_blank(),axis.title=element_text(size=9),legend.text=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

p_beta_deriv1
ggsave("./plots_tables/Tildet_beta_deriv1.pdf",width=10,height=10,unit="cm")

#other possible confidence band
p_beta_deriv2<-ggplot(data=data.frame(x=grid,y=Fam83a_modderiv_abs(grid),z=c(conf_example.i[1:379],seq(-0.0257536639,0.033,by=0.000828))),mapping = aes(x = x)) +
  geom_line(aes(x=x,y=y,color="black"),linetype="solid") +
  geom_line(aes(x=x,y=z,color="royalblue"),linetype="solid") +
  scale_color_manual(values = c("black","royalblue"),labels=c("Model Derivative","Confidence Band")) +
  ylim(-0.05,0.2) +
  xlab("Time (Weeks)") +
  ggtitle("Beta") +
  ylab("Change in  gene count") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.3,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=24.9,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=42.7,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=45,linetype="dashed",col="orangered2") +
  annotate(geom = "line", x = c(0.3, 24.9), y = c(-0.05, -0.05),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(42.7, 45), y = c(-0.05, -0.05),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=lambda_45weeks+0.01, x=5, label=expression(lambda), size = 3.5,col="orangered2") +
  annotate("text",y=-0.05+0.01, x=12, label=expression(S[1]), size = 3.3,col="darkorange") +
  annotate("text",y=-0.05+0.01, x=43.5, label=expression(S[2]), size = 3.3,col="darkorange") +
  theme(axis.text=element_blank(), axis.ticks.x=element_blank(),plot.title=element_text(size=10),legend.position = "none",
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

p_beta_deriv2
ggsave("./plots_tables/Tildet_beta_deriv2.pdf",width=10,height=10,unit="cm")

#both in one
p_beta_deriv<-ggplot(data=data.frame(x=grid,y=Fam83a_modderiv_abs(grid),z1=c(conf_example.i[1:379],seq(-0.0257536639,lambda_45weeks,by=0.000546)),z2=c(conf_example.i[1:379],seq(-0.0257536639,0.033,by=0.000828))),mapping = aes(x = x)) +
  geom_line(aes(x=x,y=y,color="black"),linetype="solid") +
  geom_line(aes(x=x,y=z1,color="royalblue"),linetype="solid") +
  geom_line(aes(x=x,y=z2,color="cadetblue3"),linetype="dashed") +
  scale_color_manual(values = c("black","royalblue","cadetblue3"),labels=c("Model Derivative","Confidence Band","Confidence Band")," ") +
  ylim(-0.05,0.2) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  ggtitle("Beta") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.3,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=24.9,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=42.7,linetype="dashed",col="orangered2") +
  geom_vline(xintercept=45,linetype="dashed",col="orangered2") +
  annotate(geom = "line", x = c(0.3, 24.9), y = c(-0.05, -0.05),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(42.7, 45), y = c(-0.05, -0.05),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=lambda_45weeks+0.01, x=5, label=expression(lambda), size = 3.5,col="orangered2") +
  annotate("text",y=-0.05+0.01, x=12, label=expression(S[1]), size = 3,col="darkorange") +
  annotate("text",y=-0.05+0.01, x=43.8, label=expression(S[2]), size = 3,col="darkorange") +
  theme(axis.text=element_blank(), axis.ticks.x=element_blank(),axis.title=element_text(size=9),legend.text=element_text(size=10),plot.title = element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 
p_beta_deriv
ggsave("./plots_tables/Tildet_beta_deriv.pdf",width=15,height=10,unit="cm")

#Combine to figure 1
patchsig<-p_sig_mod+p_sig_deriv
patchbeta<- p_beta_mod+p_beta_deriv 

patch1<-patchsig/patchbeta
patch1[[c(1)]]<-patch1[[c(1)]]+ plot_layout(tag_level = 'new')
patch1[[c(2)]]<-patch1[[c(2)]]+ plot_layout(tag_level = 'new')
patch1+plot_annotation(tag_levels = c('A', '1'))
ggsave("./plots_tables/016_Tildet_all.pdf",width=200,height=150,unit="mm")

Toi_p/
  patch1+plot_annotation(tag_levels = c('A', '1'))
ggsave("./plots_tables/028_exfig_all.pdf",width=23,height=23,unit="cm")

################################################
####Figures in Section 3: Scenarios Figure 2####
################################################
####No relevance####
model_sigmoid_norelev_p<-ggplot(data.frame(x=grid,y=model_sigmoid_norelev(grid)),aes(x=x,y=y))+
  ylim(5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Scenario 1") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

model_sigmoid_norelev_p
ggsave("./plots_tables/Norelev_model.pdf",width=5,height=5,unit="cm")

modelderiv_sigmoid_norelev_p<-ggplot(data.frame(x=grid,y=abs(modelderiv_sigmoid_norelev(grid))),aes(x=x,y=y))+
  ylim(-0.02,0.3) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  #  ggtitle("No relevance") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

modelderiv_sigmoid_norelev_p
ggsave("./plots_tables/Norelev_deriv.pdf",width=5,height=5,unit="cm")

patch_norelev<-model_sigmoid_norelev_p+modelderiv_sigmoid_norelev_p
ggsave("./plots_tables/008_Norelev.pdf",width=20,height=10,unit="cm")

####Smalljump####
model_sigmoid_smalljump_p<-ggplot(data.frame(x=grid,y=model_sigmoid_smalljump(grid)),aes(x=x,y=y))+
  ylim(5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Scenario 2") +
  geom_vline(xintercept=11.7,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=24.5,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(11.7,24.5), y = c(5,5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=5+0.2, x=17.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

model_sigmoid_smalljump_p
ggsave("./plots_tables/Sigmoid_sj_model.pdf",width=5,height=5,unit="cm")

modelderiv_sigmoid_smalljump_p<-ggplot(data.frame(x=grid,y=abs(modelderiv_sigmoid_smalljump(grid))),aes(x=x,y=y))+
  ylim(-0.02,0.3) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  # ggtitle("Sigmoidal - Small Jump") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=24.5,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(11.7,24.5), y = c(-0.02,-0.02),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=-0.01, x=17.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

modelderiv_sigmoid_smalljump_p
ggsave("./plots_tables/Sigmoid_sj_deriv.pdf",width=5,height=5,unit="cm")

patch_smalljump<-model_sigmoid_smalljump_p+modelderiv_sigmoid_smalljump_p
ggsave("./plots_tables/009_Sigmoid_sj.pdf",width=20,height=10,unit="cm")

####No Dip####
model_nodip_p<-ggplot(data.frame(x=grid,y=model_nodip(grid)),aes(x=x,y=y))+
  ylim(5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Scenario 6") +
  geom_vline(xintercept=0.1,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=28.9,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(0.1,28.9), y = c(5,5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=5+0.2, x=10.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

model_nodip_p
ggsave("./plots_tables/Beta_nodip_model.pdf",width=5,height=5,unit="cm")

modelderiv_nodip_p<-ggplot(data.frame(x=grid,y=abs(modelderiv_nodip(grid))),aes(x=x,y=y))+
  ylim(-0.02,0.3) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  #  ggtitle("Beta -  No Dip") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=28.9,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(0.1,28.9), y = c(-0.02,-0.02),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=-0.01, x=10.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

modelderiv_nodip_p
ggsave("./plots_tables/Beta_nodip_deriv.pdf",width=5,height=5,unit="cm")


patch_nodip<-model_nodip_p+modelderiv_nodip_p
ggsave("./plots_tables/012_Beta_nodip.pdf",width=20,height=10,unit="cm")

####Dip####
model_dip_p<-ggplot(data.frame(x=grid,y=model_beta_dip(grid)),aes(x=x,y=y))+
  ylim(5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Scenario 4") +
  geom_vline(xintercept=0.1,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=33.6,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=41.2,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=45.0,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(0.01,33.6), y = c(5,5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(41.2,45), y = c(5,5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=5+0.2, x=10.5, label=expression(S[1]), size = 3,col="darkorange") +
  annotate("text",y=5+0.2, x=43, label=expression(S[2]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

model_dip_p
ggsave("./plots_tables/Beta_dip_model.pdf",width=5,height=5,unit="cm")

modelderiv_dip_p<-ggplot(data.frame(x=grid,y=abs(modelderiv_beta_dip(grid))),aes(x=x,y=y))+
  ylim(-0.02,0.3) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  #  ggtitle("Beta -   Dip") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=33.6,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=41.2,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=45.0,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(0.1,33.6), y = c(-0.02,-0.02),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(41.2,45), y = c(-0.02,-0.02),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=-0.01, x=10.5, label=expression(S[1]), size = 3,col="darkorange") +
  annotate("text",y=-0.01, x=43, label=expression(S[2]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

modelderiv_dip_p
ggsave("./plots_tables/Beta_dip_deriv.pdf",width=5,height=5,unit="cm")


patch_dip<-model_dip_p+modelderiv_dip_p
ggsave("./plots_tables/013_Beta_dip.pdf",width=20,height=10,unit="cm")

####Real Sigmoid wider####
model_sigmoid_wider_p<-ggplot(data.frame(x=grid,y=model_sigmoid_wider(grid)),aes(x=x,y=y))+
  ylim(5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Scenario 3") +
  geom_vline(xintercept=5.9,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=36.3,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(5.9,36.3), y = c(5,5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=5+0.2, x=17.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

model_sigmoid_wider_p
ggsave("./plots_tables/Sigmoid_wider_model.pdf",width=5,height=5,unit="cm")

modelderiv_sigmoid_wider_p<-ggplot(data.frame(x=grid,y=abs(modelderiv_sigmoid_wider(grid))),aes(x=x,y=y))+
  ylim(-0.02,0.3) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  #  ggtitle("Sigmoidal -  wideristic") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=36.3,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(5.9,36.3), y = c(-0.02,-0.02),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=-0.01, x=17.5, label=expression(S[1]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

modelderiv_sigmoid_wider_p
ggsave("./plots_tables/Sigmoid_wider_deriv.pdf",width=5,height=5,unit="cm")

patch_wider<-model_sigmoid_wider_p+modelderiv_sigmoid_wider_p
ggsave("./plots_tables/026_Sigmoid_wider.pdf",width=20,height=10,unit="cm")

####Dip different slope####
model_dip_ds_p<-ggplot(data.frame(x=grid,y=model_beta_dip_ds(grid)),aes(x=x,y=y))+
  ylim(5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Scenario 5") +
  geom_vline(xintercept=5.7,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=38.1,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=39.4,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=45.0,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(5.7,38.1), y = c(5,5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(39.4,45), y = c(5,5),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=5+0.2, x=10.5, label=expression(S[1]), size = 3,col="darkorange") +
  annotate("text",y=5+0.2, x=42.5, label=expression(S[2]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

model_dip_ds_p
ggsave("./plots_tables/Beta_dip_ds_model.pdf",width=5,height=5,unit="cm")

modelderiv_dip_ds_p<-ggplot(data.frame(x=grid,y=abs(modelderiv_beta_dip_ds(grid))),aes(x=x,y=y))+
  ylim(-0.02,0.3) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  #  ggtitle("Beta -   dip_ds") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=38.1,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=39.4,linetype="dotted",col="orangered2") +
  geom_vline(xintercept=45.0,linetype="dotted",col="orangered2") +
  annotate(geom = "line", x = c(5.7,38.1), y = c(-0.02,-0.02),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate(geom = "line", x = c(39.4,45), y = c(-0.02,-0.02),
           color = "darkorange", alpha = 1, linetype = "solid")+
  annotate("text",y=-0.01, x=10.5, label=expression(S[1]), size = 3,col="darkorange") +
  annotate("text",y=-0.01, x=42.5, label=expression(S[2]), size = 3,col="darkorange") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

modelderiv_dip_ds_p
ggsave("./plots_tables/Beta_dip_ds_deriv.pdf",width=5,height=5,unit="cm")


patch_dip_ds<-model_dip_ds_p+modelderiv_dip_ds_p
ggsave("./plots_tables/027_Beta_dip_ds.pdf",width=20,height=10,unit="cm")

####All####
patch_scen<-model_sigmoid_norelev_p+modelderiv_sigmoid_norelev_p+plot_spacer()+
  model_sigmoid_smalljump_p+modelderiv_sigmoid_smalljump_p+
  model_sigmoid_wider_p+modelderiv_sigmoid_wider_p+plot_spacer()+
  model_dip_p+modelderiv_dip_p+
  model_dip_ds_p+modelderiv_dip_ds_p+plot_spacer()+
  model_nodip_p+modelderiv_nodip_p+plot_layout(width=c(4,4,1,4,4),nrow=3)
ggsave("./plots_tables/1001_Scen_all.pdf",width=25,height=20,unit="cm")
########################################################################
####Figures in Section 3:Results, confidence band, Figure 3, D, E, F####
########################################################################
####No relev####
#small sd
Norelev_smallsd_results_cb_df<-data.frame(grid,Est_norelev.smallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_norelev.smallsd)))+1), "_", 1:(length(Est_norelev.smallsd)+1))
for(i in 2:length(Est_norelev.smallsd)){
  Norelev_smallsd_results_cb_df<-cbind(Norelev_smallsd_results_cb_df,Est_norelev.smallsd[[i]]$conf)
}
Norelev_smallsd_results_cb_df<-cbind(Norelev_smallsd_results_cb_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(Norelev_smallsd_results_cb_df)<-c("x",names_df)


Norelev_smallsd_melted_cb<-melt(Norelev_smallsd_results_cb_df,id="x")

Norelev_smallsd_p_cb<-ggplot(data=Norelev_smallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 1") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Norelev_smallsd_p_cb
ggsave("./plots_tables/3101_Norelev_smallsd_cb.pdf",width=25,height=25,unit="cm")

#msmallsd
Norelev_msmallsd_results_cb_df<-data.frame(grid,Est_norelev.msmallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_norelev.msmallsd)))+1), "_", 1:(length(Est_norelev.msmallsd)+1))
for(i in 2:length(Est_norelev.msmallsd)){
  Norelev_msmallsd_results_cb_df<-cbind(Norelev_msmallsd_results_cb_df,Est_norelev.msmallsd[[i]]$conf)
}
Norelev_msmallsd_results_cb_df<-cbind(Norelev_msmallsd_results_cb_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(Norelev_msmallsd_results_cb_df)<-c("x",names_df)


Norelev_msmallsd_melted_cb<-melt(Norelev_msmallsd_results_cb_df,id="x")

Norelev_msmallsd_p_cb<-ggplot(data=Norelev_msmallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 1") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Norelev_msmallsd_p_cb
ggsave("./plots_tables/3101_Norelev_msmallsd_cb.pdf",width=5,height=5,unit="cm")


#medium sd
norelev_mediumsd_results_cb_df<-data.frame(grid,Est_norelev.mediumsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_norelev.mediumsd)))+1), "_", 1:(length(Est_norelev.mediumsd)+1))
for(i in 2:length(Est_norelev.mediumsd)){
  norelev_mediumsd_results_cb_df<-cbind(norelev_mediumsd_results_cb_df,Est_norelev.mediumsd[[i]]$conf)
}
norelev_mediumsd_results_cb_df<-cbind(norelev_mediumsd_results_cb_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(norelev_mediumsd_results_cb_df)<-c("x",names_df)


norelev_mediumsd_melted_cb<-melt(norelev_mediumsd_results_cb_df,id="x")

Norelev_mediumsd_p_cb<-ggplot(data=norelev_mediumsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 1") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Norelev_mediumsd_p_cb
ggsave("./plots_tables/3102_Norelev_mediumsd_cb.pdf",width=5,height=5,unit="cm")


#mlarge sd
norelev_mlargesd_results_cb_df<-data.frame(grid,Est_norelev.mlargesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_norelev.mlargesd)))+1), "_", 1:(length(Est_norelev.mlargesd)+1))
for(i in 2:length(Est_norelev.mlargesd)){
  norelev_mlargesd_results_cb_df<-cbind(norelev_mlargesd_results_cb_df,Est_norelev.mlargesd[[i]]$conf)
}
norelev_mlargesd_results_cb_df<-cbind(norelev_mlargesd_results_cb_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(norelev_mlargesd_results_cb_df)<-c("x",names_df)


norelev_mlargesd_melted_cb<-melt(norelev_mlargesd_results_cb_df,id="x")

Norelev_mlargesd_p_cb<-ggplot(data=norelev_mlargesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 1") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Norelev_mlargesd_p_cb
ggsave("./plots_tables/3103_Norelev_mlargesd_cb.pdf",width=5,height=5,unit="cm")



#large sd
norelev_largesd_results_cb_df<-data.frame(grid,Est_norelev.largesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_norelev.largesd)))+1), "_", 1:(length(Est_norelev.largesd)+1))
for(i in 2:length(Est_norelev.largesd)){
  norelev_largesd_results_cb_df<-cbind(norelev_largesd_results_cb_df,Est_norelev.largesd[[i]]$conf)
}
norelev_largesd_results_cb_df<-cbind(norelev_largesd_results_cb_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(norelev_largesd_results_cb_df)<-c("x",names_df)


norelev_largesd_melted_cb<-melt(norelev_largesd_results_cb_df,id="x")

Norelev_largesd_p_cb<-ggplot(data=norelev_largesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 1") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Norelev_largesd_p_cb
ggsave("./plots_tables/3103_Norelev_largesd_cb.pdf",width=5,height=5,unit="cm")

####Smalljump####
#smallsd
Smalljump_smallsd_results_cb_df<-data.frame(grid,Est_smalljump.smallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_smalljump.smallsd)))+1), "_", 1:(length(Est_smalljump.smallsd)+1))
for(i in 2:length(Est_smalljump.smallsd)){
  Smalljump_smallsd_results_cb_df<-cbind(Smalljump_smallsd_results_cb_df,Est_smalljump.smallsd[[i]]$conf)
}
Smalljump_smallsd_results_cb_df<-cbind(Smalljump_smallsd_results_cb_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_smallsd_results_cb_df)<-c("x",names_df)


Smalljump_smallsd_melted_cb<-melt(Smalljump_smallsd_results_cb_df,id="x")

Smalljump_smallsd_p_cb<-ggplot(data=Smalljump_smallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 2") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_smallsd_p_cb
ggsave("./plots_tables/3104_Smalljump_smallsd_cb.pdf",width=5,height=5,unit="cm")


#msmallsd
Smalljump_msmallsd_results_cb_df<-data.frame(grid,Est_smalljump.msmallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_smalljump.msmallsd)))+1), "_", 1:(length(Est_smalljump.msmallsd)+1))
for(i in 2:length(Est_smalljump.msmallsd)){
  Smalljump_msmallsd_results_cb_df<-cbind(Smalljump_msmallsd_results_cb_df,Est_smalljump.msmallsd[[i]]$conf)
}
Smalljump_msmallsd_results_cb_df<-cbind(Smalljump_msmallsd_results_cb_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_msmallsd_results_cb_df)<-c("x",names_df)


Smalljump_msmallsd_melted_cb<-melt(Smalljump_msmallsd_results_cb_df,id="x")

Smalljump_msmallsd_p_cb<-ggplot(data=Smalljump_msmallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 2") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_msmallsd_p_cb
ggsave("./plots_tables/3104_Smalljump_msmallsd_cb.pdf",width=5,height=5,unit="cm")


#medium sd
Smalljump_mediumsd_results_cb_df<-data.frame(grid,Est_smalljump.mediumsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_smalljump.mediumsd)))+1), "_", 1:(length(Est_smalljump.mediumsd)+1))
for(i in 2:length(Est_smalljump.mediumsd)){
  Smalljump_mediumsd_results_cb_df<-cbind(Smalljump_mediumsd_results_cb_df,Est_smalljump.mediumsd[[i]]$conf)
}
Smalljump_mediumsd_results_cb_df<-cbind(Smalljump_mediumsd_results_cb_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_mediumsd_results_cb_df)<-c("x",names_df)


Smalljump_mediumsd_melted_cb<-melt(Smalljump_mediumsd_results_cb_df,id="x")

Smalljump_mediumsd_p_cb<-ggplot(data=Smalljump_mediumsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 2") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_mediumsd_p_cb
ggsave("./plots_tables/3105_Smalljump_mediumsd_cb.pdf",width=5,height=5,unit="cm")


#mlarge sd
Smalljump_mlargesd_results_cb_df<-data.frame(grid,Est_smalljump.mlargesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_smalljump.mlargesd)))+1), "_", 1:(length(Est_smalljump.mlargesd)+1))
for(i in 2:length(Est_smalljump.mlargesd)){
  Smalljump_mlargesd_results_cb_df<-cbind(Smalljump_mlargesd_results_cb_df,Est_smalljump.mlargesd[[i]]$conf)
}
Smalljump_mlargesd_results_cb_df<-cbind(Smalljump_mlargesd_results_cb_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_mlargesd_results_cb_df)<-c("x",names_df)


Smalljump_mlargesd_melted_cb<-melt(Smalljump_mlargesd_results_cb_df,id="x")

Smalljump_mlargesd_p_cb<-ggplot(data=Smalljump_mlargesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 2") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Smalljump_mlargesd_p_cb
ggsave("./plots_tables/3106_Smalljump_mlargesd_cb.pdf",width=5,height=5,unit="cm")


#large sd
Smalljump_largesd_results_cb_df<-data.frame(grid,Est_smalljump.largesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_smalljump.largesd)))+1), "_", 1:(length(Est_smalljump.largesd)+1))
for(i in 2:length(Est_smalljump.largesd)){
  Smalljump_largesd_results_cb_df<-cbind(Smalljump_largesd_results_cb_df,Est_smalljump.largesd[[i]]$conf)
}
Smalljump_largesd_results_cb_df<-cbind(Smalljump_largesd_results_cb_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_largesd_results_cb_df)<-c("x",names_df)


Smalljump_largesd_melted_cb<-melt(Smalljump_largesd_results_cb_df,id="x")

Smalljump_largesd_p_cb<-ggplot(data=Smalljump_largesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 2") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Smalljump_largesd_p_cb
ggsave("./plots_tables/3106_Smalljump_largesd_cb.pdf",width=5,height=5,unit="cm")

####Wider####
#smallsd
wider_smallsd_results_cb_df<-data.frame(grid,Est_wider.smallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_wider.smallsd)))+1), "_", 1:(length(Est_wider.smallsd)+1))
for(i in 2:length(Est_wider.smallsd)){
  wider_smallsd_results_cb_df<-cbind(wider_smallsd_results_cb_df,Est_wider.smallsd[[i]]$conf)
}
wider_smallsd_results_cb_df<-cbind(wider_smallsd_results_cb_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_smallsd_results_cb_df)<-c("x",names_df)


wider_smallsd_melted_cb<-melt(wider_smallsd_results_cb_df,id="x")

Wider_smallsd_p_cb<-ggplot(data=wider_smallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 3") +
  annotate("text",y=lambda_45weeks+0.035, x=42.5, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Wider_smallsd_p_cb
ggsave("./plots_tables/3107_Wider_smallsd_cb.pdf",width=5,height=5,unit="cm")


#msmallsd
wider_msmallsd_results_cb_df<-data.frame(grid,Est_wider.msmallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_wider.msmallsd)))+1), "_", 1:(length(Est_wider.msmallsd)+1))
for(i in 2:length(Est_wider.msmallsd)){
  wider_msmallsd_results_cb_df<-cbind(wider_msmallsd_results_cb_df,Est_wider.msmallsd[[i]]$conf)
}
wider_msmallsd_results_cb_df<-cbind(wider_msmallsd_results_cb_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_msmallsd_results_cb_df)<-c("x",names_df)


wider_msmallsd_melted_cb<-melt(wider_msmallsd_results_cb_df,id="x")

Wider_msmallsd_p_cb<-ggplot(data=wider_msmallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 3") +
  annotate("text",y=lambda_45weeks+0.035, x=42.5, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Wider_msmallsd_p_cb
ggsave("./plots_tables/3107_Wider_msmallsd_cb.pdf",width=5,height=5,unit="cm")


#medium sd
wider_mediumsd_results_cb_df<-data.frame(grid,Est_wider.mediumsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_wider.mediumsd)))+1), "_", 1:(length(Est_wider.mediumsd)+1))
for(i in 2:length(Est_wider.mediumsd)){
  wider_mediumsd_results_cb_df<-cbind(wider_mediumsd_results_cb_df,Est_wider.mediumsd[[i]]$conf)
}
wider_mediumsd_results_cb_df<-cbind(wider_mediumsd_results_cb_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_mediumsd_results_cb_df)<-c("x",names_df)


wider_mediumsd_melted_cb<-melt(wider_mediumsd_results_cb_df,id="x")

Wider_mediumsd_p_cb<-ggplot(data=wider_mediumsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 3") +
  annotate("text",y=lambda_45weeks+0.035, x=42.5, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Wider_mediumsd_p_cb
ggsave("./plots_tables/3108_Wider_mediumsd_cb.pdf",width=5,height=5,unit="cm")


#mlarge sd
wider_mlargesd_results_cb_df<-data.frame(grid,Est_wider.mlargesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_wider.mlargesd)))+1), "_", 1:(length(Est_wider.mlargesd)+1))
for(i in 2:length(Est_wider.mlargesd)){
  wider_mlargesd_results_cb_df<-cbind(wider_mlargesd_results_cb_df,Est_wider.mlargesd[[i]]$conf)
}
wider_mlargesd_results_cb_df<-cbind(wider_mlargesd_results_cb_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_mlargesd_results_cb_df)<-c("x",names_df)


wider_mlargesd_melted_cb<-melt(wider_mlargesd_results_cb_df,id="x")

Wider_mlargesd_p_cb<-ggplot(data=wider_mlargesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 3") +
  annotate("text",y=lambda_45weeks+0.035, x=42.5, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Wider_mediumsd_p_cb
ggsave("./plots_tables/3109_Wider_mediumsd_cb.pdf",width=5,height=5,unit="cm")


#large sd
wider_largesd_results_cb_df<-data.frame(grid,Est_wider.largesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_wider.largesd)))+1), "_", 1:(length(Est_wider.largesd)+1))
for(i in 2:length(Est_wider.largesd)){
  wider_largesd_results_cb_df<-cbind(wider_largesd_results_cb_df,Est_wider.largesd[[i]]$conf)
}
wider_largesd_results_cb_df<-cbind(wider_largesd_results_cb_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_largesd_results_cb_df)<-c("x",names_df)


wider_largesd_melted_cb<-melt(wider_largesd_results_cb_df,id="x")

Wider_largesd_p_cb<-ggplot(data=wider_largesd_melted_cb,mapping = aes(x=x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 3") +
  annotate("text",y=lambda_45weeks+0.035, x=42.5, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Wider_largesd_p_cb
ggsave("./plots_tables/3109_Wider_largesd_cb.pdf",width=5,height=5,unit="cm")

####nodip####
#smallsd
nodip_smallsd_results_cb_df<-data.frame(grid,Est_nodip.smallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_nodip.smallsd)))+1), "_", 1:(length(Est_nodip.smallsd)+1))
for(i in 2:length(Est_nodip.smallsd)){
  nodip_smallsd_results_cb_df<-cbind(nodip_smallsd_results_cb_df,Est_nodip.smallsd[[i]]$conf)
}
nodip_smallsd_results_cb_df<-cbind(nodip_smallsd_results_cb_df,abs(modelderiv_nodip(grid)))

colnames(nodip_smallsd_results_cb_df)<-c("x",names_df)


nodip_smallsd_melted_cb<-melt(nodip_smallsd_results_cb_df,id="x")

Nodip_smallsd_p_cb<-ggplot(data=nodip_smallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 6") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Nodip_smallsd_p_cb
ggsave("./plots_tables/3110_Nodip_smallsd_cb.pdf",width=5,height=5,unit="cm")

#msmallsd
nodip_msmallsd_results_cb_df<-data.frame(grid,Est_nodip.msmallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_nodip.msmallsd)))+1), "_", 1:(length(Est_nodip.msmallsd)+1))
for(i in 2:length(Est_nodip.msmallsd)){
  nodip_msmallsd_results_cb_df<-cbind(nodip_msmallsd_results_cb_df,Est_nodip.msmallsd[[i]]$conf)
}
nodip_msmallsd_results_cb_df<-cbind(nodip_msmallsd_results_cb_df,abs(modelderiv_nodip(grid)))

colnames(nodip_msmallsd_results_cb_df)<-c("x",names_df)


nodip_msmallsd_melted_cb<-melt(nodip_msmallsd_results_cb_df,id="x")

Nodip_msmallsd_p_cb<-ggplot(data=nodip_msmallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 6") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Nodip_msmallsd_p_cb
ggsave("./plots_tables/3110_Nodip_msmallsd_cb.pdf",width=5,height=5,unit="cm")



#medium sd
nodip_mediumsd_results_cb_df<-data.frame(grid,Est_nodip.mediumsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_nodip.mediumsd)))+1), "_", 1:(length(Est_nodip.mediumsd)+1))
for(i in 2:length(Est_nodip.mediumsd)){
  nodip_mediumsd_results_cb_df<-cbind(nodip_mediumsd_results_cb_df,Est_nodip.mediumsd[[i]]$conf)
}
nodip_mediumsd_results_cb_df<-cbind(nodip_mediumsd_results_cb_df,abs(modelderiv_nodip(grid)))

colnames(nodip_mediumsd_results_cb_df)<-c("x",names_df)


nodip_mediumsd_melted_cb<-melt(nodip_mediumsd_results_cb_df,id="x")

Nodip_mediumsd_p_cb<-ggplot(data=nodip_mediumsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 6") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Nodip_mediumsd_p_cb
ggsave("./plots_tables/3111_Nodip_mediumsd_cb.pdf",width=5,height=5,unit="cm")


#mlarge sd
nodip_mlargesd_results_cb_df<-data.frame(grid,Est_nodip.mlargesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_nodip.mlargesd)))+1), "_", 1:(length(Est_nodip.mlargesd)+1))
for(i in 2:length(Est_nodip.mlargesd)){
  nodip_mlargesd_results_cb_df<-cbind(nodip_mlargesd_results_cb_df,Est_nodip.mlargesd[[i]]$conf)
}
nodip_mlargesd_results_cb_df<-cbind(nodip_mlargesd_results_cb_df,abs(modelderiv_nodip(grid)))

colnames(nodip_mlargesd_results_cb_df)<-c("x",names_df)


nodip_mlargesd_melted_cb<-melt(nodip_mlargesd_results_cb_df,id="x")

Nodip_mlargesd_p_cb<-ggplot(data=nodip_mlargesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 6") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Nodip_mlargesd_p_cb
ggsave("./plots_tables/3112_Nodip_mlargesd_cb.pdf",width=5,height=5,unit="cm")


#large sd
nodip_largesd_results_cb_df<-data.frame(grid,Est_nodip.largesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_nodip.largesd)))+1), "_", 1:(length(Est_nodip.largesd)+1))
for(i in 2:length(Est_nodip.largesd)){
  nodip_largesd_results_cb_df<-cbind(nodip_largesd_results_cb_df,Est_nodip.largesd[[i]]$conf)
}
nodip_largesd_results_cb_df<-cbind(nodip_largesd_results_cb_df,abs(modelderiv_nodip(grid)))

colnames(nodip_largesd_results_cb_df)<-c("x",names_df)


nodip_largesd_melted_cb<-melt(nodip_largesd_results_cb_df,id="x")

Nodip_largesd_p_cb<-ggplot(data=nodip_largesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 6") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Nodip_largesd_p_cb
ggsave("./plots_tables/3112_Nodip_largesd_cb.pdf",width=5,height=5,unit="cm")

####dip####
#smallsd
dip_smallsd_results_cb_df<-data.frame(grid,Est_dip.smallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip.smallsd)))+1), "_", 1:(length(Est_dip.smallsd)+1))
for(i in 2:length(Est_dip.smallsd)){
  dip_smallsd_results_cb_df<-cbind(dip_smallsd_results_cb_df,Est_dip.smallsd[[i]]$conf)
}
dip_smallsd_results_cb_df<-cbind(dip_smallsd_results_cb_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_smallsd_results_cb_df)<-c("x",names_df)


dip_smallsd_melted_cb<-melt(dip_smallsd_results_cb_df,id="x")

Dip_smallsd_p_cb<-ggplot(data=dip_smallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 4") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_smallsd_p_cb
ggsave("./plots_tables/3113_Dip_smallsd_cb.pdf",width=5,height=5,unit="cm")


#msmallsd
dip_msmallsd_results_cb_df<-data.frame(grid,Est_dip.msmallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip.msmallsd)))+1), "_", 1:(length(Est_dip.msmallsd)+1))
for(i in 2:length(Est_dip.msmallsd)){
  dip_msmallsd_results_cb_df<-cbind(dip_msmallsd_results_cb_df,Est_dip.msmallsd[[i]]$conf)
}
dip_msmallsd_results_cb_df<-cbind(dip_msmallsd_results_cb_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_msmallsd_results_cb_df)<-c("x",names_df)


dip_msmallsd_melted_cb<-melt(dip_msmallsd_results_cb_df,id="x")

Dip_msmallsd_p_cb<-ggplot(data=dip_msmallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 4") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_msmallsd_p_cb
ggsave("./plots_tables/3113_Dip_msmallsd_cb.pdf",width=5,height=5,unit="cm")


#medium sd
dip_mediumsd_results_cb_df<-data.frame(grid,Est_dip.mediumsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip.mediumsd)))+1), "_", 1:(length(Est_dip.mediumsd)+1))
for(i in 2:length(Est_dip.mediumsd)){
  dip_mediumsd_results_cb_df<-cbind(dip_mediumsd_results_cb_df,Est_dip.mediumsd[[i]]$conf)
}
dip_mediumsd_results_cb_df<-cbind(dip_mediumsd_results_cb_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_mediumsd_results_cb_df)<-c("x",names_df)


dip_mediumsd_melted_cb<-melt(dip_mediumsd_results_cb_df,id="x")

Dip_mediumsd_p_cb<-ggplot(data=dip_mediumsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 4") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_mediumsd_p_cb
ggsave("./plots_tables/3114_Dip_mediumsd_cb.pdf",width=5,height=5,unit="cm")


#mlarge sd
dip_mlargesd_results_cb_df<-data.frame(grid,Est_dip.mlargesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip.mlargesd)))+1), "_", 1:(length(Est_dip.mlargesd)+1))
for(i in 2:length(Est_dip.mlargesd)){
  dip_mlargesd_results_cb_df<-cbind(dip_mlargesd_results_cb_df,Est_dip.mlargesd[[i]]$conf)
}
dip_mlargesd_results_cb_df<-cbind(dip_mlargesd_results_cb_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_mlargesd_results_cb_df)<-c("x",names_df)


dip_mlargesd_melted_cb<-melt(dip_mlargesd_results_cb_df,id="x")

Dip_mlargesd_p_cb<-ggplot(data=dip_mlargesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 4") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_mlargesd_p_cb
ggsave("./plots_tables/3115_Dip_mlargesd_cb.pdf",width=5,height=5,unit="cm")


#large sd
dip_largesd_results_cb_df<-data.frame(grid,Est_dip.largesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip.largesd)))+1), "_", 1:(length(Est_dip.largesd)+1))
for(i in 2:length(Est_dip.largesd)){
  dip_largesd_results_cb_df<-cbind(dip_largesd_results_cb_df,Est_dip.largesd[[i]]$conf)
}
dip_largesd_results_cb_df<-cbind(dip_largesd_results_cb_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_largesd_results_cb_df)<-c("x",names_df)


dip_largesd_melted_cb<-melt(dip_largesd_results_cb_df,id="x")

Dip_largesd_p_cb<-ggplot(data=dip_largesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 4") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_largesd_p_cb
ggsave("./plots_tables/3115_Dip_largesd_cb.pdf",width=5,height=5,unit="cm")

####dip_ds####
#smallsd
dip_ds_smallsd_results_cb_df<-data.frame(grid,Est_dip_ds.smallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip_ds.smallsd)))+1), "_", 1:(length(Est_dip_ds.smallsd)+1))
for(i in 2:length(Est_dip_ds.smallsd)){
  dip_ds_smallsd_results_cb_df<-cbind(dip_ds_smallsd_results_cb_df,Est_dip_ds.smallsd[[i]]$conf)
}
dip_ds_smallsd_results_cb_df<-cbind(dip_ds_smallsd_results_cb_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_smallsd_results_cb_df)<-c("x",names_df)


dip_ds_smallsd_melted_cb<-melt(dip_ds_smallsd_results_cb_df,id="x")

Dip_ds_smallsd_p_cb<-ggplot(data=dip_ds_smallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 5") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_smallsd_p_cb
ggsave("./plots_tables/3116_Dip_ds_smallsd_cb.pdf",width=5,height=5,unit="cm")

#msmallsd
dip_ds_msmallsd_results_cb_df<-data.frame(grid,Est_dip_ds.msmallsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip_ds.msmallsd)))+1), "_", 1:(length(Est_dip_ds.msmallsd)+1))
for(i in 2:length(Est_dip_ds.msmallsd)){
  dip_ds_msmallsd_results_cb_df<-cbind(dip_ds_msmallsd_results_cb_df,Est_dip_ds.msmallsd[[i]]$conf)
}
dip_ds_msmallsd_results_cb_df<-cbind(dip_ds_msmallsd_results_cb_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_msmallsd_results_cb_df)<-c("x",names_df)


dip_ds_msmallsd_melted_cb<-melt(dip_ds_msmallsd_results_cb_df,id="x")

Dip_ds_msmallsd_p_cb<-ggplot(data=dip_ds_msmallsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 5") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_msmallsd_p_cb
ggsave("./plots_tables/3116_Dip_ds_msmallsd_cb.pdf",width=5,height=5,unit="cm")

#medium sd
dip_ds_mediumsd_results_cb_df<-data.frame(grid,Est_dip_ds.mediumsd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip_ds.mediumsd)))+1), "_", 1:(length(Est_dip_ds.mediumsd)+1))
for(i in 2:length(Est_dip_ds.mediumsd)){
  dip_ds_mediumsd_results_cb_df<-cbind(dip_ds_mediumsd_results_cb_df,Est_dip_ds.mediumsd[[i]]$conf)
}
dip_ds_mediumsd_results_cb_df<-cbind(dip_ds_mediumsd_results_cb_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_mediumsd_results_cb_df)<-c("x",names_df)


dip_ds_mediumsd_melted_cb<-melt(dip_ds_mediumsd_results_cb_df,id="x")

Dip_ds_mediumsd_p_cb<-ggplot(data=dip_ds_mediumsd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 5") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_mediumsd_p_cb
ggsave("./plots_tables/3117_Dip_ds_mediumsd_cb.pdf",width=5,height=5,unit="cm")

#mlarge sd
dip_ds_mlargesd_results_cb_df<-data.frame(grid,Est_dip_ds.mlargesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip_ds.mlargesd)))+1), "_", 1:(length(Est_dip_ds.mlargesd)+1))
for(i in 2:length(Est_dip_ds.mlargesd)){
  dip_ds_mlargesd_results_cb_df<-cbind(dip_ds_mlargesd_results_cb_df,Est_dip_ds.mlargesd[[i]]$conf)
}
dip_ds_mlargesd_results_cb_df<-cbind(dip_ds_mlargesd_results_cb_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_mlargesd_results_cb_df)<-c("x",names_df)


dip_ds_mlargesd_melted_cb<-melt(dip_ds_mlargesd_results_cb_df,id="x")

Dip_ds_mlargesd_p_cb<-ggplot(data=dip_ds_mlargesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 5") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_ds_mlargesd_p_cb
ggsave("./plots_tables/3118_Dip_ds_mlargesd_cb.pdf",width=5,height=5,unit="cm")


#large sd
dip_ds_largesd_results_cb_df<-data.frame(grid,Est_dip_ds.largesd[[1]]$conf)
names_df<-paste0(rep("y",times=((length(Est_dip_ds.largesd)))+1), "_", 1:(length(Est_dip_ds.largesd)+1))
for(i in 2:length(Est_dip_ds.largesd)){
  dip_ds_largesd_results_cb_df<-cbind(dip_ds_largesd_results_cb_df,Est_dip_ds.largesd[[i]]$conf)
}
dip_ds_largesd_results_cb_df<-cbind(dip_ds_largesd_results_cb_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_largesd_results_cb_df)<-c("x",names_df)


dip_ds_largesd_melted_cb<-melt(dip_ds_largesd_results_cb_df,id="x")

Dip_ds_largesd_p_cb<-ggplot(data=dip_ds_largesd_melted_cb,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("royalblue",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(-0.3,0.4)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  ggtitle("Scenario 5") +
  annotate("text",y=lambda_45weeks+0.035, x=20, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_ds_largesd_p_cb
ggsave("./plots_tables/3118_Dip_ds_largesd_cb.pdf",width=5,height=5,unit="cm")

#############################################################
####Figures in Section 3:Results, model function Figure B####
#############################################################
####No relev####
#small sd
Norelev_smallsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_norelev.smallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_norelev.smallsd)))+1), "_", 1:(length(Est_norelev.smallsd)+1))
for(i in 2:length(Est_norelev.smallsd)){
  Norelev_smallsd_results_mf_df<-cbind(Norelev_smallsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_norelev.smallsd[[i]]$mod_est)))
}
Norelev_smallsd_results_mf_df<-cbind(Norelev_smallsd_results_mf_df,model_sigmoid_norelev(grid))
colnames(Norelev_smallsd_results_mf_df)<-c("x",names_df)


Norelev_smallsd_melted_mf<-melt(Norelev_smallsd_results_mf_df,id="x")

Norelev_smallsd_p_mf<-ggplot(data=Norelev_smallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4, 11) +
  ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Norelev_smallsd_p_mf
ggsave("./plots_tables/3101_Norelev_smallsd_mf.pdf",width=5,height=5,unit="cm")

#msmallsd
Norelev_msmallsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_norelev.msmallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_norelev.msmallsd)))+1), "_", 1:(length(Est_norelev.msmallsd)+1))
for(i in 2:length(Est_norelev.msmallsd)){
  Norelev_msmallsd_results_mf_df<-cbind(Norelev_msmallsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_norelev.msmallsd[[i]]$mod_est)))
}
Norelev_msmallsd_results_mf_df<-cbind(Norelev_msmallsd_results_mf_df,abs(model_sigmoid_norelev(grid)))

colnames(Norelev_msmallsd_results_mf_df)<-c("x",names_df)


Norelev_msmallsd_melted_mf<-melt(Norelev_msmallsd_results_mf_df,id="x")

Norelev_msmallsd_p_mf<-ggplot(data=Norelev_msmallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Norelev_msmallsd_p_mf
ggsave("./plots_tables/3101_Norelev_msmallsd_mf.pdf",width=5,height=5,unit="cm")


#medium sd
norelev_mediumsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_norelev.mediumsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_norelev.mediumsd)))+1), "_", 1:(length(Est_norelev.mediumsd)+1))
for(i in 2:length(Est_norelev.mediumsd)){
  norelev_mediumsd_results_mf_df<-cbind(norelev_mediumsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_norelev.mediumsd[[i]]$mod_est)))
}
norelev_mediumsd_results_mf_df<-cbind(norelev_mediumsd_results_mf_df,abs(model_sigmoid_norelev(grid)))

colnames(norelev_mediumsd_results_mf_df)<-c("x",names_df)


norelev_mediumsd_melted_mf<-melt(norelev_mediumsd_results_mf_df,id="x")

Norelev_mediumsd_p_mf<-ggplot(data=norelev_mediumsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
#  ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Norelev_mediumsd_p_mf
ggsave("./plots_tables/3102_Norelev_mediumsd_mf.pdf",width=5,height=5,unit="cm")


#mlarge sd
norelev_mlargesd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_norelev.mlargesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_norelev.mlargesd)))+1), "_", 1:(length(Est_norelev.mlargesd)+1))
for(i in 2:length(Est_norelev.mlargesd)){
  norelev_mlargesd_results_mf_df<-cbind(norelev_mlargesd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_norelev.mlargesd[[i]]$mod_est)))
}
norelev_mlargesd_results_mf_df<-cbind(norelev_mlargesd_results_mf_df,abs(model_sigmoid_norelev(grid)))

colnames(norelev_mlargesd_results_mf_df)<-c("x",names_df)


norelev_mlargesd_melted_mf<-melt(norelev_mlargesd_results_mf_df,id="x")

Norelev_mlargesd_p_mf<-ggplot(data=norelev_mlargesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Gene count") +
  #ggtitle("Scenario 1") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Norelev_mlargesd_p_mf
ggsave("./plots_tables/3103_Norelev_mlargesd_mf.pdf",width=5,height=5,unit="cm")



#large sd
norelev_largesd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_norelev.largesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_norelev.largesd)))+1), "_", 1:(length(Est_norelev.largesd)+1))
for(i in 2:length(Est_norelev.largesd)){
  norelev_largesd_results_mf_df<-cbind(norelev_largesd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_norelev.largesd[[i]]$mod_est)))
}
norelev_largesd_results_mf_df<-cbind(norelev_largesd_results_mf_df,abs(model_sigmoid_norelev(grid)))

colnames(norelev_largesd_results_mf_df)<-c("x",names_df)


norelev_largesd_melted_mf<-melt(norelev_largesd_results_mf_df,id="x")

Norelev_largesd_p_mf<-ggplot(data=norelev_largesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
#  ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Norelev_largesd_p_mf
ggsave("./plots_tables/3103_Norelev_largesd_mf.pdf",width=5,height=5,unit="cm")

####Smalljump####
#smallsd
Smalljump_smallsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_smalljump.smallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_smalljump.smallsd)))+1), "_", 1:(length(Est_smalljump.smallsd)+1))
for(i in 2:length(Est_smalljump.smallsd)){
  Smalljump_smallsd_results_mf_df<-cbind(Smalljump_smallsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_smalljump.smallsd[[i]]$mod_est)))
}
Smalljump_smallsd_results_mf_df<-cbind(Smalljump_smallsd_results_mf_df,abs(model_sigmoid_smalljump(grid)))

colnames(Smalljump_smallsd_results_mf_df)<-c("x",names_df)


Smalljump_smallsd_melted_mf<-melt(Smalljump_smallsd_results_mf_df,id="x")

Smalljump_smallsd_p_mf<-ggplot(data=Smalljump_smallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_smallsd_p_mf
ggsave("./plots_tables/3104_Smalljump_smallsd_mf.pdf",width=5,height=5,unit="cm")


#msmallsd
Smalljump_msmallsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_smalljump.msmallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_smalljump.msmallsd)))+1), "_", 1:(length(Est_smalljump.msmallsd)+1))
for(i in 2:length(Est_smalljump.msmallsd)){
  Smalljump_msmallsd_results_mf_df<-cbind(Smalljump_msmallsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_smalljump.msmallsd[[i]]$mod_est)))
}
Smalljump_msmallsd_results_mf_df<-cbind(Smalljump_msmallsd_results_mf_df,abs(model_sigmoid_smalljump(grid)))

colnames(Smalljump_msmallsd_results_mf_df)<-c("x",names_df)


Smalljump_msmallsd_melted_mf<-melt(Smalljump_msmallsd_results_mf_df,id="x")

Smalljump_msmallsd_p_mf<-ggplot(data=Smalljump_msmallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
#  ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_msmallsd_p_mf
ggsave("./plots_tables/3104_Smalljump_msmallsd_mf.pdf",width=5,height=5,unit="cm")


#medium sd
Smalljump_mediumsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_smalljump.mediumsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_smalljump.mediumsd)))+1), "_", 1:(length(Est_smalljump.mediumsd)+1))
for(i in 2:length(Est_smalljump.mediumsd)){
  Smalljump_mediumsd_results_mf_df<-cbind(Smalljump_mediumsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_smalljump.mediumsd[[i]]$mod_est)))
}
Smalljump_mediumsd_results_mf_df<-cbind(Smalljump_mediumsd_results_mf_df,abs(model_sigmoid_smalljump(grid)))

colnames(Smalljump_mediumsd_results_mf_df)<-c("x",names_df)


Smalljump_mediumsd_melted_mf<-melt(Smalljump_mediumsd_results_mf_df,id="x")

Smalljump_mediumsd_p_mf<-ggplot(data=Smalljump_mediumsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
#  ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_mediumsd_p_mf
ggsave("./plots_tables/3105_Smalljump_mediumsd_mf.pdf",width=5,height=5,unit="cm")


#mlarge sd
Smalljump_mlargesd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_smalljump.mlargesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_smalljump.mlargesd)))+1), "_", 1:(length(Est_smalljump.mlargesd)+1))
for(i in 2:length(Est_smalljump.mlargesd)){
  Smalljump_mlargesd_results_mf_df<-cbind(Smalljump_mlargesd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_smalljump.mlargesd[[i]]$mod_est)))
}
Smalljump_mlargesd_results_mf_df<-cbind(Smalljump_mlargesd_results_mf_df,abs(model_sigmoid_smalljump(grid)))

colnames(Smalljump_mlargesd_results_mf_df)<-c("x",names_df)


Smalljump_mlargesd_melted_mf<-melt(Smalljump_mlargesd_results_mf_df,id="x")

Smalljump_mlargesd_p_mf<-ggplot(data=Smalljump_mlargesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Smalljump_mlargesd_p_mf
ggsave("./plots_tables/3106_Smalljump_mlargesd_mf.pdf",width=5,height=5,unit="cm")


#large sd
Smalljump_largesd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_smalljump.largesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_smalljump.largesd)))+1), "_", 1:(length(Est_smalljump.largesd)+1))
for(i in 2:length(Est_smalljump.largesd)){
  Smalljump_largesd_results_mf_df<-cbind(Smalljump_largesd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_smalljump.largesd[[i]]$mod_est)))
}
Smalljump_largesd_results_mf_df<-cbind(Smalljump_largesd_results_mf_df,abs(model_sigmoid_smalljump(grid)))

colnames(Smalljump_largesd_results_mf_df)<-c("x",names_df)


Smalljump_largesd_melted_mf<-melt(Smalljump_largesd_results_mf_df,id="x")

Smalljump_largesd_p_mf<-ggplot(data=Smalljump_largesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Smalljump_largesd_p_mf
ggsave("./plots_tables/3106_Smalljump_largesd_mf.pdf",width=5,height=5,unit="cm")

####Wider####
#smallsd
wider_smallsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_wider.smallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_wider.smallsd)))+1), "_", 1:(length(Est_wider.smallsd)+1))
for(i in 2:length(Est_wider.smallsd)){
  wider_smallsd_results_mf_df<-cbind(wider_smallsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_wider.smallsd[[i]]$mod_est)))
}
wider_smallsd_results_mf_df<-cbind(wider_smallsd_results_mf_df,abs(model_sigmoid_wider(grid)))

colnames(wider_smallsd_results_mf_df)<-c("x",names_df)


wider_smallsd_melted_mf<-melt(wider_smallsd_results_mf_df,id="x")

Wider_smallsd_p_mf<-ggplot(data=wider_smallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Wider_smallsd_p_mf
ggsave("./plots_tables/3107_Wider_smallsd_mf.pdf",width=5,height=5,unit="cm")


#msmallsd
wider_msmallsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_wider.msmallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_wider.msmallsd)))+1), "_", 1:(length(Est_wider.msmallsd)+1))
for(i in 2:length(Est_wider.msmallsd)){
  wider_msmallsd_results_mf_df<-cbind(wider_msmallsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_wider.msmallsd[[i]]$mod_est)))
}
wider_msmallsd_results_mf_df<-cbind(wider_msmallsd_results_mf_df,abs(model_sigmoid_wider(grid)))

colnames(wider_msmallsd_results_mf_df)<-c("x",names_df)


wider_msmallsd_melted_mf<-melt(wider_msmallsd_results_mf_df,id="x")

Wider_msmallsd_p_mf<-ggplot(data=wider_msmallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
 # ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Wider_msmallsd_p_mf
ggsave("./plots_tables/3107_Wider_msmallsd_mf.pdf",width=5,height=5,unit="cm")


#medium sd
wider_mediumsd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_wider.mediumsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_wider.mediumsd)))+1), "_", 1:(length(Est_wider.mediumsd)+1))
for(i in 2:length(Est_wider.mediumsd)){
  wider_mediumsd_results_mf_df<-cbind(wider_mediumsd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_wider.mediumsd[[i]]$mod_est)))
}
wider_mediumsd_results_mf_df<-cbind(wider_mediumsd_results_mf_df,abs(model_sigmoid_wider(grid)))

colnames(wider_mediumsd_results_mf_df)<-c("x",names_df)


wider_mediumsd_melted_mf<-melt(wider_mediumsd_results_mf_df,id="x")

Wider_mediumsd_p_mf<-ggplot(data=wider_mediumsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Wider_mediumsd_p_mf
ggsave("./plots_tables/3108_Wider_mediumsd_mf.pdf",width=5,height=5,unit="cm")


#mlarge sd
wider_mlargesd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_wider.mlargesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_wider.mlargesd)))+1), "_", 1:(length(Est_wider.mlargesd)+1))
for(i in 2:length(Est_wider.mlargesd)){
  wider_mlargesd_results_mf_df<-cbind(wider_mlargesd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_wider.mlargesd[[i]]$mod_est)))
}
wider_mlargesd_results_mf_df<-cbind(wider_mlargesd_results_mf_df,abs(model_sigmoid_wider(grid)))

colnames(wider_mlargesd_results_mf_df)<-c("x",names_df)


wider_mlargesd_melted_mf<-melt(wider_mlargesd_results_mf_df,id="x")

Wider_mlargesd_p_mf<-ggplot(data=wider_mlargesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Wider_mediumsd_p_mf
ggsave("./plots_tables/3109_Wider_mediumsd_mf.pdf",width=5,height=5,unit="cm")


#large sd
wider_largesd_results_mf_df<-data.frame(grid,modelfunction_sigmoid(grid,coef(Est_wider.largesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_wider.largesd)))+1), "_", 1:(length(Est_wider.largesd)+1))
for(i in 2:length(Est_wider.largesd)){
  wider_largesd_results_mf_df<-cbind(wider_largesd_results_mf_df,modelfunction_sigmoid(grid,coef(Est_wider.largesd[[i]]$mod_est)))
}
wider_largesd_results_mf_df<-cbind(wider_largesd_results_mf_df,abs(model_sigmoid_wider(grid)))

colnames(wider_largesd_results_mf_df)<-c("x",names_df)


wider_largesd_melted_mf<-melt(wider_largesd_results_mf_df,id="x")

Wider_largesd_p_mf<-ggplot(data=wider_largesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
 # ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Wider_largesd_p_mf
ggsave("./plots_tables/3109_Wider_largesd_mf.pdf",width=5,height=5,unit="cm")

####nodip####
#smallsd
nodip_smallsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_nodip.smallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_nodip.smallsd)))+1), "_", 1:(length(Est_nodip.smallsd)+1))
for(i in 2:length(Est_nodip.smallsd)){
  nodip_smallsd_results_mf_df<-cbind(nodip_smallsd_results_mf_df,modelfunction_beta(grid,coef(Est_nodip.smallsd[[i]]$mod_est)))
}
nodip_smallsd_results_mf_df<-cbind(nodip_smallsd_results_mf_df,abs(model_nodip(grid)))

colnames(nodip_smallsd_results_mf_df)<-c("x",names_df)


nodip_smallsd_melted_mf<-melt(nodip_smallsd_results_mf_df,id="x")

Nodip_smallsd_p_mf<-ggplot(data=nodip_smallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Nodip_smallsd_p_mf
ggsave("./plots_tables/3110_Nodip_smallsd_mf.pdf",width=5,height=5,unit="cm")

#msmallsd
nodip_msmallsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_nodip.msmallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_nodip.msmallsd)))+1), "_", 1:(length(Est_nodip.msmallsd)+1))
for(i in 2:length(Est_nodip.msmallsd)){
  nodip_msmallsd_results_mf_df<-cbind(nodip_msmallsd_results_mf_df,modelfunction_beta(grid,coef(Est_nodip.msmallsd[[i]]$mod_est)))
}
nodip_msmallsd_results_mf_df<-cbind(nodip_msmallsd_results_mf_df,abs(model_nodip(grid)))

colnames(nodip_msmallsd_results_mf_df)<-c("x",names_df)


nodip_msmallsd_melted_mf<-melt(nodip_msmallsd_results_mf_df,id="x")

Nodip_msmallsd_p_mf<-ggplot(data=nodip_msmallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Nodip_msmallsd_p_mf
ggsave("./plots_tables/3110_Nodip_msmallsd_mf.pdf",width=5,height=5,unit="cm")



#medium sd
nodip_mediumsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_nodip.mediumsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_nodip.mediumsd)))+1), "_", 1:(length(Est_nodip.mediumsd)+1))
for(i in 2:length(Est_nodip.mediumsd)){
  nodip_mediumsd_results_mf_df<-cbind(nodip_mediumsd_results_mf_df,modelfunction_beta(grid,coef(Est_nodip.mediumsd[[i]]$mod_est)))
}
nodip_mediumsd_results_mf_df<-cbind(nodip_mediumsd_results_mf_df,abs(model_nodip(grid)))

colnames(nodip_mediumsd_results_mf_df)<-c("x",names_df)


nodip_mediumsd_melted_mf<-melt(nodip_mediumsd_results_mf_df,id="x")

Nodip_mediumsd_p_mf<-ggplot(data=nodip_mediumsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Nodip_mediumsd_p_mf
ggsave("./plots_tables/3111_Nodip_mediumsd_mf.pdf",width=5,height=5,unit="cm")


#mlarge sd
nodip_mlargesd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_nodip.mlargesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_nodip.mlargesd)))+1), "_", 1:(length(Est_nodip.mlargesd)+1))
for(i in 2:length(Est_nodip.mlargesd)){
  nodip_mlargesd_results_mf_df<-cbind(nodip_mlargesd_results_mf_df,modelfunction_beta(grid,coef(Est_nodip.mlargesd[[i]]$mod_est)))
}
nodip_mlargesd_results_mf_df<-cbind(nodip_mlargesd_results_mf_df,abs(model_nodip(grid)))

colnames(nodip_mlargesd_results_mf_df)<-c("x",names_df)


nodip_mlargesd_melted_mf<-melt(nodip_mlargesd_results_mf_df,id="x")

Nodip_mlargesd_p_mf<-ggplot(data=nodip_mlargesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Nodip_mlargesd_p_mf
ggsave("./plots_tables/3112_Nodip_mlargesd_mf.pdf",width=5,height=5,unit="cm")


#large sd
nodip_largesd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_nodip.largesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_nodip.largesd)))+1), "_", 1:(length(Est_nodip.largesd)+1))
for(i in 2:length(Est_nodip.largesd)){
  nodip_largesd_results_mf_df<-cbind(nodip_largesd_results_mf_df,modelfunction_beta(grid,coef(Est_nodip.largesd[[i]]$mod_est)))
}
nodip_largesd_results_mf_df<-cbind(nodip_largesd_results_mf_df,abs(model_nodip(grid)))

colnames(nodip_largesd_results_mf_df)<-c("x",names_df)


nodip_largesd_melted_mf<-melt(nodip_largesd_results_mf_df,id="x")

Nodip_largesd_p_mf<-ggplot(data=nodip_largesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
#  ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Nodip_largesd_p_mf
ggsave("./plots_tables/3112_Nodip_largesd_mf.pdf",width=5,height=5,unit="cm")

####dip####
#smallsd
dip_smallsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip.smallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip.smallsd)))+1), "_", 1:(length(Est_dip.smallsd)+1))
for(i in 2:length(Est_dip.smallsd)){
  dip_smallsd_results_mf_df<-cbind(dip_smallsd_results_mf_df,modelfunction_beta(grid,coef(Est_dip.smallsd[[i]]$mod_est)))
}
dip_smallsd_results_mf_df<-cbind(dip_smallsd_results_mf_df,abs(model_beta_dip(grid)))

colnames(dip_smallsd_results_mf_df)<-c("x",names_df)


dip_smallsd_melted_mf<-melt(dip_smallsd_results_mf_df,id="x")

Dip_smallsd_p_mf<-ggplot(data=dip_smallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_smallsd_p_mf
ggsave("./plots_tables/3113_Dip_smallsd_mf.pdf",width=5,height=5,unit="cm")


#msmallsd
dip_msmallsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip.msmallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip.msmallsd)))+1), "_", 1:(length(Est_dip.msmallsd)+1))
for(i in 2:length(Est_dip.msmallsd)){
  dip_msmallsd_results_mf_df<-cbind(dip_msmallsd_results_mf_df,modelfunction_beta(grid,coef(Est_dip.msmallsd[[i]]$mod_est)))
}
dip_msmallsd_results_mf_df<-cbind(dip_msmallsd_results_mf_df,abs(model_beta_dip(grid)))

colnames(dip_msmallsd_results_mf_df)<-c("x",names_df)


dip_msmallsd_melted_mf<-melt(dip_msmallsd_results_mf_df,id="x")

Dip_msmallsd_p_mf<-ggplot(data=dip_msmallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
#  ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_msmallsd_p_mf
ggsave("./plots_tables/3113_Dip_msmallsd_mf.pdf",width=5,height=5,unit="cm")


#medium sd
dip_mediumsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip.mediumsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip.mediumsd)))+1), "_", 1:(length(Est_dip.mediumsd)+1))
for(i in 2:length(Est_dip.mediumsd)){
  dip_mediumsd_results_mf_df<-cbind(dip_mediumsd_results_mf_df,modelfunction_beta(grid,coef(Est_dip.mediumsd[[i]]$mod_est)))
}
dip_mediumsd_results_mf_df<-cbind(dip_mediumsd_results_mf_df,abs(model_beta_dip(grid)))

colnames(dip_mediumsd_results_mf_df)<-c("x",names_df)


dip_mediumsd_melted_mf<-melt(dip_mediumsd_results_mf_df,id="x")

Dip_mediumsd_p_mf<-ggplot(data=dip_mediumsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
#  ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_mediumsd_p_mf
ggsave("./plots_tables/3114_Dip_mediumsd_mf.pdf",width=5,height=5,unit="cm")


#mlarge sd
dip_mlargesd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip.mlargesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip.mlargesd)))+1), "_", 1:(length(Est_dip.mlargesd)+1))
for(i in 2:length(Est_dip.mlargesd)){
  dip_mlargesd_results_mf_df<-cbind(dip_mlargesd_results_mf_df,modelfunction_beta(grid,coef(Est_dip.mlargesd[[i]]$mod_est)))
}
dip_mlargesd_results_mf_df<-cbind(dip_mlargesd_results_mf_df,abs(model_beta_dip(grid)))

colnames(dip_mlargesd_results_mf_df)<-c("x",names_df)


dip_mlargesd_melted_mf<-melt(dip_mlargesd_results_mf_df,id="x")

Dip_mlargesd_p_mf<-ggplot(data=dip_mlargesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_mlargesd_p_mf
ggsave("./plots_tables/3115_Dip_mlargesd_mf.pdf",width=5,height=5,unit="cm")


#large sd
dip_largesd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip.largesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip.largesd)))+1), "_", 1:(length(Est_dip.largesd)+1))
for(i in 2:length(Est_dip.largesd)){
  dip_largesd_results_mf_df<-cbind(dip_largesd_results_mf_df,modelfunction_beta(grid,coef(Est_dip.largesd[[i]]$mod_est)))
}
dip_largesd_results_mf_df<-cbind(dip_largesd_results_mf_df,abs(model_beta_dip(grid)))

colnames(dip_largesd_results_mf_df)<-c("x",names_df)


dip_largesd_melted_mf<-melt(dip_largesd_results_mf_df,id="x")

Dip_largesd_p_mf<-ggplot(data=dip_largesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_largesd_p_mf
ggsave("./plots_tables/3115_Dip_largesd_mf.pdf",width=5,height=5,unit="cm")

####dip_ds####
#smallsd
dip_ds_smallsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip_ds.smallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.smallsd)))+1), "_", 1:(length(Est_dip_ds.smallsd)+1))
for(i in 2:length(Est_dip_ds.smallsd)){
  dip_ds_smallsd_results_mf_df<-cbind(dip_ds_smallsd_results_mf_df,modelfunction_beta(grid,coef(Est_dip_ds.smallsd[[i]]$mod_est)))
}
dip_ds_smallsd_results_mf_df<-cbind(dip_ds_smallsd_results_mf_df,abs(model_beta_dip_ds(grid)))

colnames(dip_ds_smallsd_results_mf_df)<-c("x",names_df)


dip_ds_smallsd_melted_mf<-melt(dip_ds_smallsd_results_mf_df,id="x")

Dip_ds_smallsd_p_mf<-ggplot(data=dip_ds_smallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  ggtitle("Scenario 5") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_smallsd_p_mf
ggsave("./plots_tables/3116_Dip_ds_smallsd_mf.pdf",width=5,height=5,unit="cm")

#msmallsd
dip_ds_msmallsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip_ds.msmallsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.msmallsd)))+1), "_", 1:(length(Est_dip_ds.msmallsd)+1))
for(i in 2:length(Est_dip_ds.msmallsd)){
  dip_ds_msmallsd_results_mf_df<-cbind(dip_ds_msmallsd_results_mf_df,modelfunction_beta(grid,coef(Est_dip_ds.msmallsd[[i]]$mod_est)))
}
dip_ds_msmallsd_results_mf_df<-cbind(dip_ds_msmallsd_results_mf_df,abs(model_beta_dip_ds(grid)))

colnames(dip_ds_msmallsd_results_mf_df)<-c("x",names_df)


dip_ds_msmallsd_melted_mf<-melt(dip_ds_msmallsd_results_mf_df,id="x")

Dip_ds_msmallsd_p_mf<-ggplot(data=dip_ds_msmallsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_msmallsd_p_mf
ggsave("./plots_tables/3116_Dip_ds_msmallsd_mf.pdf",width=5,height=5,unit="cm")

#medium sd
dip_ds_mediumsd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip_ds.mediumsd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.mediumsd)))+1), "_", 1:(length(Est_dip_ds.mediumsd)+1))
for(i in 2:length(Est_dip_ds.mediumsd)){
  dip_ds_mediumsd_results_mf_df<-cbind(dip_ds_mediumsd_results_mf_df,modelfunction_beta(grid,coef(Est_dip_ds.mediumsd[[i]]$mod_est)))
}
dip_ds_mediumsd_results_mf_df<-cbind(dip_ds_mediumsd_results_mf_df,abs(model_beta_dip_ds(grid)))

colnames(dip_ds_mediumsd_results_mf_df)<-c("x",names_df)


dip_ds_mediumsd_melted_mf<-melt(dip_ds_mediumsd_results_mf_df,id="x")

Dip_ds_mediumsd_p_mf<-ggplot(data=dip_ds_mediumsd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_mediumsd_p_mf
ggsave("./plots_tables/3117_Dip_ds_mediumsd_mf.pdf",width=5,height=5,unit="cm")

#mlarge sd
dip_ds_mlargesd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip_ds.mlargesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.mlargesd)))+1), "_", 1:(length(Est_dip_ds.mlargesd)+1))
for(i in 2:length(Est_dip_ds.mlargesd)){
  dip_ds_mlargesd_results_mf_df<-cbind(dip_ds_mlargesd_results_mf_df,modelfunction_beta(grid,coef(Est_dip_ds.mlargesd[[i]]$mod_est)))
}
dip_ds_mlargesd_results_mf_df<-cbind(dip_ds_mlargesd_results_mf_df,abs(model_beta_dip_ds(grid)))

colnames(dip_ds_mlargesd_results_mf_df)<-c("x",names_df)


dip_ds_mlargesd_melted_mf<-melt(dip_ds_mlargesd_results_mf_df,id="x")

Dip_ds_mlargesd_p_mf<-ggplot(data=dip_ds_mlargesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_ds_mlargesd_p_mf
ggsave("./plots_tables/3118_Dip_ds_mlargesd_mf.pdf",width=5,height=5,unit="cm")


#large sd
dip_ds_largesd_results_mf_df<-data.frame(grid,modelfunction_beta(grid,coef(Est_dip_ds.largesd[[1]]$mod_est)))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.largesd)))+1), "_", 1:(length(Est_dip_ds.largesd)+1))
for(i in 2:length(Est_dip_ds.largesd)){
  dip_ds_largesd_results_mf_df<-cbind(dip_ds_largesd_results_mf_df,modelfunction_beta(grid,coef(Est_dip_ds.largesd[[i]]$mod_est)))
}
dip_ds_largesd_results_mf_df<-cbind(dip_ds_largesd_results_mf_df,abs(model_beta_dip_ds(grid)))

colnames(dip_ds_largesd_results_mf_df)<-c("x",names_df)


dip_ds_largesd_melted_mf<-melt(dip_ds_largesd_results_mf_df,id="x")

Dip_ds_largesd_p_mf<-ggplot(data=dip_ds_largesd_melted_mf,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(4,11)+
  #ggtitle("Scenario 5") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.015, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_ds_largesd_p_mf
ggsave("./plots_tables/3118_Dip_ds_largesd_mf.pdf",width=5,height=5,unit="cm")

####All####
patch_mf<-Norelev_smallsd_p_mf+Norelev_msmallsd_p_mf+Norelev_mediumsd_p_mf+Norelev_mlargesd_p_mf+Norelev_largesd_p_mf+
Smalljump_smallsd_p_mf+Smalljump_msmallsd_p_mf+Smalljump_mediumsd_p_mf+Smalljump_mlargesd_p_mf+Smalljump_largesd_p_mf+ 
  Wider_smallsd_p_mf+Wider_msmallsd_p_mf+Wider_mediumsd_p_mf+Wider_mlargesd_p_mf+Wider_largesd_p_mf+
  Dip_smallsd_p_mf+Dip_msmallsd_p_mf+Dip_mediumsd_p_mf+Dip_mlargesd_p_mf+Dip_largesd_p_mf+
  Dip_ds_smallsd_p_mf+Dip_ds_msmallsd_p_mf+Dip_ds_mediumsd_p_mf+Dip_ds_mlargesd_p_mf+Dip_ds_largesd_p_mf+ 
  Nodip_smallsd_p_mf+Nodip_msmallsd_p_mf+Nodip_mediumsd_p_mf+Nodip_mlargesd_p_mf+Nodip_largesd_p_mf + 
  plot_layout(width=c(1,1,1,1,1),nrow=6)
patch_mf
ggsave("./plots_tables/1001_MF_all.pdf",width=50,height=55,unit="cm")
ggsave("./plots_tables/1001_MF_all.tiff",width=50,height=55,unit="cm",dpi=600, compression = "lzw")

################################################################
####Figures in Section 3:Results, first derivatives Figure C####
################################################################
####No relev####
#small sd
Norelev_smallsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_norelev.smallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_norelev.smallsd)))+1), "_", 1:(length(Est_norelev.smallsd)+1))
for(i in 2:length(Est_norelev.smallsd)){
  Norelev_smallsd_results_ff_df<-cbind(Norelev_smallsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_norelev.smallsd[[i]]$mod_est))))
}
Norelev_smallsd_results_ff_df<-cbind(Norelev_smallsd_results_ff_df,abs(modelderiv_sigmoid_norelev(grid)))
colnames(Norelev_smallsd_results_ff_df)<-c("x",names_df)


Norelev_smallsd_melted_ff<-melt(Norelev_smallsd_results_ff_df,id="x")

Norelev_smallsd_p_ff<-ggplot(data=Norelev_smallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5) +
  ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Norelev_smallsd_p_ff
ggsave("./plots_tables/3101_Norelev_smallsd_ff.pdf",width=5,height=5,unit="cm")

#msmallsd
Norelev_msmallsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_norelev.msmallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_norelev.msmallsd)))+1), "_", 1:(length(Est_norelev.msmallsd)+1))
for(i in 2:length(Est_norelev.msmallsd)){
  Norelev_msmallsd_results_ff_df<-cbind(Norelev_msmallsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_norelev.msmallsd[[i]]$mod_est))))
}
Norelev_msmallsd_results_ff_df<-cbind(Norelev_msmallsd_results_ff_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(Norelev_msmallsd_results_ff_df)<-c("x",names_df)


Norelev_msmallsd_melted_ff<-melt(Norelev_msmallsd_results_ff_df,id="x")

Norelev_msmallsd_p_ff<-ggplot(data=Norelev_msmallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Norelev_msmallsd_p_ff
ggsave("./plots_tables/3101_Norelev_msmallsd_ff.pdf",width=5,height=5,unit="cm")


#medium sd
norelev_mediumsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_norelev.mediumsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_norelev.mediumsd)))+1), "_", 1:(length(Est_norelev.mediumsd)+1))
for(i in 2:length(Est_norelev.mediumsd)){
  norelev_mediumsd_results_ff_df<-cbind(norelev_mediumsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_norelev.mediumsd[[i]]$mod_est))))
}
norelev_mediumsd_results_ff_df<-cbind(norelev_mediumsd_results_ff_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(norelev_mediumsd_results_ff_df)<-c("x",names_df)


norelev_mediumsd_melted_ff<-melt(norelev_mediumsd_results_ff_df,id="x")

Norelev_mediumsd_p_ff<-ggplot(data=norelev_mediumsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #  ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Norelev_mediumsd_p_ff
ggsave("./plots_tables/3102_Norelev_mediumsd_ff.pdf",width=5,height=5,unit="cm")


#mlarge sd
norelev_mlargesd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_norelev.mlargesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_norelev.mlargesd)))+1), "_", 1:(length(Est_norelev.mlargesd)+1))
for(i in 2:length(Est_norelev.mlargesd)){
  norelev_mlargesd_results_ff_df<-cbind(norelev_mlargesd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_norelev.mlargesd[[i]]$mod_est))))
}
norelev_mlargesd_results_ff_df<-cbind(norelev_mlargesd_results_ff_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(norelev_mlargesd_results_ff_df)<-c("x",names_df)


norelev_mlargesd_melted_ff<-melt(norelev_mlargesd_results_ff_df,id="x")

Norelev_mlargesd_p_ff<-ggplot(data=norelev_mlargesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  #ggtitle("Scenario 1") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Norelev_mlargesd_p_ff
ggsave("./plots_tables/3103_Norelev_mlargesd_ff.pdf",width=5,height=5,unit="cm")



#large sd
norelev_largesd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_norelev.largesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_norelev.largesd)))+1), "_", 1:(length(Est_norelev.largesd)+1))
for(i in 2:length(Est_norelev.largesd)){
  norelev_largesd_results_ff_df<-cbind(norelev_largesd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_norelev.largesd[[i]]$mod_est))))
}
norelev_largesd_results_ff_df<-cbind(norelev_largesd_results_ff_df,abs(modelderiv_sigmoid_norelev(grid)))

colnames(norelev_largesd_results_ff_df)<-c("x",names_df)


norelev_largesd_melted_ff<-melt(norelev_largesd_results_ff_df,id="x")

Norelev_largesd_p_ff<-ggplot(data=norelev_largesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #  ggtitle("Scenario 1") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Norelev_largesd_p_ff
ggsave("./plots_tables/3103_Norelev_largesd_ff.pdf",width=5,height=5,unit="cm")

####Smalljump####
#smallsd
Smalljump_smallsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.smallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_smalljump.smallsd)))+1), "_", 1:(length(Est_smalljump.smallsd)+1))
for(i in 2:length(Est_smalljump.smallsd)){
  Smalljump_smallsd_results_ff_df<-cbind(Smalljump_smallsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.smallsd[[i]]$mod_est))))
}
Smalljump_smallsd_results_ff_df<-cbind(Smalljump_smallsd_results_ff_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_smallsd_results_ff_df)<-c("x",names_df)


Smalljump_smallsd_melted_ff<-melt(Smalljump_smallsd_results_ff_df,id="x")

Smalljump_smallsd_p_ff<-ggplot(data=Smalljump_smallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_smallsd_p_ff
ggsave("./plots_tables/3104_Smalljump_smallsd_ff.pdf",width=5,height=5,unit="cm")


#msmallsd
Smalljump_msmallsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.msmallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_smalljump.msmallsd)))+1), "_", 1:(length(Est_smalljump.msmallsd)+1))
for(i in 2:length(Est_smalljump.msmallsd)){
  Smalljump_msmallsd_results_ff_df<-cbind(Smalljump_msmallsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.msmallsd[[i]]$mod_est))))
}
Smalljump_msmallsd_results_ff_df<-cbind(Smalljump_msmallsd_results_ff_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_msmallsd_results_ff_df)<-c("x",names_df)


Smalljump_msmallsd_melted_ff<-melt(Smalljump_msmallsd_results_ff_df,id="x")

Smalljump_msmallsd_p_ff<-ggplot(data=Smalljump_msmallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #  ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_msmallsd_p_ff
ggsave("./plots_tables/3104_Smalljump_msmallsd_ff.pdf",width=5,height=5,unit="cm")


#medium sd
Smalljump_mediumsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.mediumsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_smalljump.mediumsd)))+1), "_", 1:(length(Est_smalljump.mediumsd)+1))
for(i in 2:length(Est_smalljump.mediumsd)){
  Smalljump_mediumsd_results_ff_df<-cbind(Smalljump_mediumsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.mediumsd[[i]]$mod_est))))
}
Smalljump_mediumsd_results_ff_df<-cbind(Smalljump_mediumsd_results_ff_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_mediumsd_results_ff_df)<-c("x",names_df)


Smalljump_mediumsd_melted_ff<-melt(Smalljump_mediumsd_results_ff_df,id="x")

Smalljump_mediumsd_p_ff<-ggplot(data=Smalljump_mediumsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #  ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Smalljump_mediumsd_p_ff
ggsave("./plots_tables/3105_Smalljump_mediumsd_ff.pdf",width=5,height=5,unit="cm")


#mlarge sd
Smalljump_mlargesd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.mlargesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_smalljump.mlargesd)))+1), "_", 1:(length(Est_smalljump.mlargesd)+1))
for(i in 2:length(Est_smalljump.mlargesd)){
  Smalljump_mlargesd_results_ff_df<-cbind(Smalljump_mlargesd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.mlargesd[[i]]$mod_est))))
}
Smalljump_mlargesd_results_ff_df<-cbind(Smalljump_mlargesd_results_ff_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_mlargesd_results_ff_df)<-c("x",names_df)


Smalljump_mlargesd_melted_ff<-melt(Smalljump_mlargesd_results_ff_df,id="x")

Smalljump_mlargesd_p_ff<-ggplot(data=Smalljump_mlargesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Smalljump_mlargesd_p_ff
ggsave("./plots_tables/3106_Smalljump_mlargesd_ff.pdf",width=5,height=5,unit="cm")


#large sd
Smalljump_largesd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.largesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_smalljump.largesd)))+1), "_", 1:(length(Est_smalljump.largesd)+1))
for(i in 2:length(Est_smalljump.largesd)){
  Smalljump_largesd_results_ff_df<-cbind(Smalljump_largesd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_smalljump.largesd[[i]]$mod_est))))
}
Smalljump_largesd_results_ff_df<-cbind(Smalljump_largesd_results_ff_df,abs(modelderiv_sigmoid_smalljump(grid)))

colnames(Smalljump_largesd_results_ff_df)<-c("x",names_df)


Smalljump_largesd_melted_ff<-melt(Smalljump_largesd_results_ff_df,id="x")

Smalljump_largesd_p_ff<-ggplot(data=Smalljump_largesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 2") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=24.5,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")

Smalljump_largesd_p_ff
ggsave("./plots_tables/3106_Smalljump_largesd_ff.pdf",width=5,height=5,unit="cm")

####Wider####
#smallsd
wider_smallsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_wider.smallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_wider.smallsd)))+1), "_", 1:(length(Est_wider.smallsd)+1))
for(i in 2:length(Est_wider.smallsd)){
  wider_smallsd_results_ff_df<-cbind(wider_smallsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_wider.smallsd[[i]]$mod_est))))
}
wider_smallsd_results_ff_df<-cbind(wider_smallsd_results_ff_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_smallsd_results_ff_df)<-c("x",names_df)


wider_smallsd_melted_ff<-melt(wider_smallsd_results_ff_df,id="x")

Wider_smallsd_p_ff<-ggplot(data=wider_smallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Wider_smallsd_p_ff
ggsave("./plots_tables/3107_Wider_smallsd_ff.pdf",width=5,height=5,unit="cm")


#msmallsd
wider_msmallsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_wider.msmallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_wider.msmallsd)))+1), "_", 1:(length(Est_wider.msmallsd)+1))
for(i in 2:length(Est_wider.msmallsd)){
  wider_msmallsd_results_ff_df<-cbind(wider_msmallsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_wider.msmallsd[[i]]$mod_est))))
}
wider_msmallsd_results_ff_df<-cbind(wider_msmallsd_results_ff_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_msmallsd_results_ff_df)<-c("x",names_df)


wider_msmallsd_melted_ff<-melt(wider_msmallsd_results_ff_df,id="x")

Wider_msmallsd_p_ff<-ggplot(data=wider_msmallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  # ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Wider_msmallsd_p_ff
ggsave("./plots_tables/3107_Wider_msmallsd_ff.pdf",width=5,height=5,unit="cm")


#medium sd
wider_mediumsd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_wider.mediumsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_wider.mediumsd)))+1), "_", 1:(length(Est_wider.mediumsd)+1))
for(i in 2:length(Est_wider.mediumsd)){
  wider_mediumsd_results_ff_df<-cbind(wider_mediumsd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_wider.mediumsd[[i]]$mod_est))))
}
wider_mediumsd_results_ff_df<-cbind(wider_mediumsd_results_ff_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_mediumsd_results_ff_df)<-c("x",names_df)


wider_mediumsd_melted_ff<-melt(wider_mediumsd_results_ff_df,id="x")

Wider_mediumsd_p_ff<-ggplot(data=wider_mediumsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Wider_mediumsd_p_ff
ggsave("./plots_tables/3108_Wider_mediumsd_ff.pdf",width=5,height=5,unit="cm")


#mlarge sd
wider_mlargesd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_wider.mlargesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_wider.mlargesd)))+1), "_", 1:(length(Est_wider.mlargesd)+1))
for(i in 2:length(Est_wider.mlargesd)){
  wider_mlargesd_results_ff_df<-cbind(wider_mlargesd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_wider.mlargesd[[i]]$mod_est))))
}
wider_mlargesd_results_ff_df<-cbind(wider_mlargesd_results_ff_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_mlargesd_results_ff_df)<-c("x",names_df)


wider_mlargesd_melted_ff<-melt(wider_mlargesd_results_ff_df,id="x")

Wider_mlargesd_p_ff<-ggplot(data=wider_mlargesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Wider_mediumsd_p_ff
ggsave("./plots_tables/3109_Wider_mediumsd_ff.pdf",width=5,height=5,unit="cm")


#large sd
wider_largesd_results_ff_df<-data.frame(grid,abs(modelderiv_sigmoid(grid,coef(Est_wider.largesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_wider.largesd)))+1), "_", 1:(length(Est_wider.largesd)+1))
for(i in 2:length(Est_wider.largesd)){
  wider_largesd_results_ff_df<-cbind(wider_largesd_results_ff_df,abs(modelderiv_sigmoid(grid,coef(Est_wider.largesd[[i]]$mod_est))))
}
wider_largesd_results_ff_df<-cbind(wider_largesd_results_ff_df,abs(modelderiv_sigmoid_wider(grid)))

colnames(wider_largesd_results_ff_df)<-c("x",names_df)


wider_largesd_melted_ff<-melt(wider_largesd_results_ff_df,id="x")

Wider_largesd_p_ff<-ggplot(data=wider_largesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  # ggtitle("Scenario 3") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=36.3,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Wider_largesd_p_ff
ggsave("./plots_tables/3109_Wider_largesd_ff.pdf",width=5,height=5,unit="cm")

####nodip####
#smallsd
nodip_smallsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_nodip.smallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_nodip.smallsd)))+1), "_", 1:(length(Est_nodip.smallsd)+1))
for(i in 2:length(Est_nodip.smallsd)){
  nodip_smallsd_results_ff_df<-cbind(nodip_smallsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_nodip.smallsd[[i]]$mod_est))))
}
nodip_smallsd_results_ff_df<-cbind(nodip_smallsd_results_ff_df,abs(modelderiv_nodip(grid)))

colnames(nodip_smallsd_results_ff_df)<-c("x",names_df)


nodip_smallsd_melted_ff<-melt(nodip_smallsd_results_ff_df,id="x")

Nodip_smallsd_p_ff<-ggplot(data=nodip_smallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Nodip_smallsd_p_ff
ggsave("./plots_tables/3110_Nodip_smallsd_ff.pdf",width=5,height=5,unit="cm")

#msmallsd
nodip_msmallsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_nodip.msmallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_nodip.msmallsd)))+1), "_", 1:(length(Est_nodip.msmallsd)+1))
for(i in 2:length(Est_nodip.msmallsd)){
  nodip_msmallsd_results_ff_df<-cbind(nodip_msmallsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_nodip.msmallsd[[i]]$mod_est))))
}
nodip_msmallsd_results_ff_df<-cbind(nodip_msmallsd_results_ff_df,abs(modelderiv_nodip(grid)))

colnames(nodip_msmallsd_results_ff_df)<-c("x",names_df)


nodip_msmallsd_melted_ff<-melt(nodip_msmallsd_results_ff_df,id="x")

Nodip_msmallsd_p_ff<-ggplot(data=nodip_msmallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

Nodip_msmallsd_p_ff
ggsave("./plots_tables/3110_Nodip_msmallsd_ff.pdf",width=5,height=5,unit="cm")



#medium sd
nodip_mediumsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_nodip.mediumsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_nodip.mediumsd)))+1), "_", 1:(length(Est_nodip.mediumsd)+1))
for(i in 2:length(Est_nodip.mediumsd)){
  nodip_mediumsd_results_ff_df<-cbind(nodip_mediumsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_nodip.mediumsd[[i]]$mod_est))))
}
nodip_mediumsd_results_ff_df<-cbind(nodip_mediumsd_results_ff_df,abs(modelderiv_nodip(grid)))

colnames(nodip_mediumsd_results_ff_df)<-c("x",names_df)


nodip_mediumsd_melted_ff<-melt(nodip_mediumsd_results_ff_df,id="x")

Nodip_mediumsd_p_ff<-ggplot(data=nodip_mediumsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Nodip_mediumsd_p_ff
ggsave("./plots_tables/3111_Nodip_mediumsd_ff.pdf",width=5,height=5,unit="cm")


#mlarge sd
nodip_mlargesd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_nodip.mlargesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_nodip.mlargesd)))+1), "_", 1:(length(Est_nodip.mlargesd)+1))
for(i in 2:length(Est_nodip.mlargesd)){
  nodip_mlargesd_results_ff_df<-cbind(nodip_mlargesd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_nodip.mlargesd[[i]]$mod_est))))
}
nodip_mlargesd_results_ff_df<-cbind(nodip_mlargesd_results_ff_df,abs(modelderiv_nodip(grid)))

colnames(nodip_mlargesd_results_ff_df)<-c("x",names_df)


nodip_mlargesd_melted_ff<-melt(nodip_mlargesd_results_ff_df,id="x")

Nodip_mlargesd_p_ff<-ggplot(data=nodip_mlargesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Nodip_mlargesd_p_ff
ggsave("./plots_tables/3112_Nodip_mlargesd_ff.pdf",width=5,height=5,unit="cm")


#large sd
nodip_largesd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_nodip.largesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_nodip.largesd)))+1), "_", 1:(length(Est_nodip.largesd)+1))
for(i in 2:length(Est_nodip.largesd)){
  nodip_largesd_results_ff_df<-cbind(nodip_largesd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_nodip.largesd[[i]]$mod_est))))
}
nodip_largesd_results_ff_df<-cbind(nodip_largesd_results_ff_df,abs(modelderiv_nodip(grid)))

colnames(nodip_largesd_results_ff_df)<-c("x",names_df)


nodip_largesd_melted_ff<-melt(nodip_largesd_results_ff_df,id="x")

Nodip_largesd_p_ff<-ggplot(data=nodip_largesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #  ggtitle("Scenario 6") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=28.9,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Nodip_largesd_p_ff
ggsave("./plots_tables/3112_Nodip_largesd_ff.pdf",width=5,height=5,unit="cm")

####dip####
#smallsd
dip_smallsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip.smallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip.smallsd)))+1), "_", 1:(length(Est_dip.smallsd)+1))
for(i in 2:length(Est_dip.smallsd)){
  dip_smallsd_results_ff_df<-cbind(dip_smallsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip.smallsd[[i]]$mod_est))))
}
dip_smallsd_results_ff_df<-cbind(dip_smallsd_results_ff_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_smallsd_results_ff_df)<-c("x",names_df)


dip_smallsd_melted_ff<-melt(dip_smallsd_results_ff_df,id="x")

Dip_smallsd_p_ff<-ggplot(data=dip_smallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_smallsd_p_ff
ggsave("./plots_tables/3113_Dip_smallsd_ff.pdf",width=5,height=5,unit="cm")


#msmallsd
dip_msmallsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip.msmallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip.msmallsd)))+1), "_", 1:(length(Est_dip.msmallsd)+1))
for(i in 2:length(Est_dip.msmallsd)){
  dip_msmallsd_results_ff_df<-cbind(dip_msmallsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip.msmallsd[[i]]$mod_est))))
}
dip_msmallsd_results_ff_df<-cbind(dip_msmallsd_results_ff_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_msmallsd_results_ff_df)<-c("x",names_df)


dip_msmallsd_melted_ff<-melt(dip_msmallsd_results_ff_df,id="x")

Dip_msmallsd_p_ff<-ggplot(data=dip_msmallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #  ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_msmallsd_p_ff
ggsave("./plots_tables/3113_Dip_msmallsd_ff.pdf",width=5,height=5,unit="cm")


#medium sd
dip_mediumsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip.mediumsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip.mediumsd)))+1), "_", 1:(length(Est_dip.mediumsd)+1))
for(i in 2:length(Est_dip.mediumsd)){
  dip_mediumsd_results_ff_df<-cbind(dip_mediumsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip.mediumsd[[i]]$mod_est))))
}
dip_mediumsd_results_ff_df<-cbind(dip_mediumsd_results_ff_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_mediumsd_results_ff_df)<-c("x",names_df)


dip_mediumsd_melted_ff<-melt(dip_mediumsd_results_ff_df,id="x")

Dip_mediumsd_p_ff<-ggplot(data=dip_mediumsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #  ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_mediumsd_p_ff
ggsave("./plots_tables/3114_Dip_mediumsd_ff.pdf",width=5,height=5,unit="cm")


#mlarge sd
dip_mlargesd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip.mlargesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip.mlargesd)))+1), "_", 1:(length(Est_dip.mlargesd)+1))
for(i in 2:length(Est_dip.mlargesd)){
  dip_mlargesd_results_ff_df<-cbind(dip_mlargesd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip.mlargesd[[i]]$mod_est))))
}
dip_mlargesd_results_ff_df<-cbind(dip_mlargesd_results_ff_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_mlargesd_results_ff_df)<-c("x",names_df)


dip_mlargesd_melted_ff<-melt(dip_mlargesd_results_ff_df,id="x")

Dip_mlargesd_p_ff<-ggplot(data=dip_mlargesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_mlargesd_p_ff
ggsave("./plots_tables/3115_Dip_mlargesd_ff.pdf",width=5,height=5,unit="cm")


#large sd
dip_largesd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip.largesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip.largesd)))+1), "_", 1:(length(Est_dip.largesd)+1))
for(i in 2:length(Est_dip.largesd)){
  dip_largesd_results_ff_df<-cbind(dip_largesd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip.largesd[[i]]$mod_est))))
}
dip_largesd_results_ff_df<-cbind(dip_largesd_results_ff_df,abs(modelderiv_beta_dip(grid)))

colnames(dip_largesd_results_ff_df)<-c("x",names_df)


dip_largesd_melted_ff<-melt(dip_largesd_results_ff_df,id="x")

Dip_largesd_p_ff<-ggplot(data=dip_largesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 4") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_largesd_p_ff
ggsave("./plots_tables/3115_Dip_largesd_ff.pdf",width=5,height=5,unit="cm")

####dip_ds####
#smallsd
dip_ds_smallsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip_ds.smallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.smallsd)))+1), "_", 1:(length(Est_dip_ds.smallsd)+1))
for(i in 2:length(Est_dip_ds.smallsd)){
  dip_ds_smallsd_results_ff_df<-cbind(dip_ds_smallsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip_ds.smallsd[[i]]$mod_est))))
}
dip_ds_smallsd_results_ff_df<-cbind(dip_ds_smallsd_results_ff_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_smallsd_results_ff_df)<-c("x",names_df)


dip_ds_smallsd_melted_ff<-melt(dip_ds_smallsd_results_ff_df,id="x")

Dip_ds_smallsd_p_ff<-ggplot(data=dip_ds_smallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  ggtitle("Scenario 5") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_smallsd_p_ff
ggsave("./plots_tables/3116_Dip_ds_smallsd_ff.pdf",width=5,height=5,unit="cm")

#msmallsd
dip_ds_msmallsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip_ds.msmallsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.msmallsd)))+1), "_", 1:(length(Est_dip_ds.msmallsd)+1))
for(i in 2:length(Est_dip_ds.msmallsd)){
  dip_ds_msmallsd_results_ff_df<-cbind(dip_ds_msmallsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip_ds.msmallsd[[i]]$mod_est))))
}
dip_ds_msmallsd_results_ff_df<-cbind(dip_ds_msmallsd_results_ff_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_msmallsd_results_ff_df)<-c("x",names_df)


dip_ds_msmallsd_melted_ff<-melt(dip_ds_msmallsd_results_ff_df,id="x")

Dip_ds_msmallsd_p_ff<-ggplot(data=dip_ds_msmallsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_msmallsd_p_ff
ggsave("./plots_tables/3116_Dip_ds_msmallsd_ff.pdf",width=5,height=5,unit="cm")

#medium sd
dip_ds_mediumsd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip_ds.mediumsd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.mediumsd)))+1), "_", 1:(length(Est_dip_ds.mediumsd)+1))
for(i in 2:length(Est_dip_ds.mediumsd)){
  dip_ds_mediumsd_results_ff_df<-cbind(dip_ds_mediumsd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip_ds.mediumsd[[i]]$mod_est))))
}
dip_ds_mediumsd_results_ff_df<-cbind(dip_ds_mediumsd_results_ff_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_mediumsd_results_ff_df)<-c("x",names_df)


dip_ds_mediumsd_melted_ff<-melt(dip_ds_mediumsd_results_ff_df,id="x")

Dip_ds_mediumsd_p_ff<-ggplot(data=dip_ds_mediumsd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dip_ds_mediumsd_p_ff
ggsave("./plots_tables/3117_Dip_ds_mediumsd_ff.pdf",width=5,height=5,unit="cm")

#mlarge sd
dip_ds_mlargesd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip_ds.mlargesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.mlargesd)))+1), "_", 1:(length(Est_dip_ds.mlargesd)+1))
for(i in 2:length(Est_dip_ds.mlargesd)){
  dip_ds_mlargesd_results_ff_df<-cbind(dip_ds_mlargesd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip_ds.mlargesd[[i]]$mod_est))))
}
dip_ds_mlargesd_results_ff_df<-cbind(dip_ds_mlargesd_results_ff_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_mlargesd_results_ff_df)<-c("x",names_df)


dip_ds_mlargesd_melted_ff<-melt(dip_ds_mlargesd_results_ff_df,id="x")

Dip_ds_mlargesd_p_ff<-ggplot(data=dip_ds_mlargesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_ds_mlargesd_p_ff
ggsave("./plots_tables/3118_Dip_ds_mlargesd_ff.pdf",width=5,height=5,unit="cm")


#large sd
dip_ds_largesd_results_ff_df<-data.frame(grid,abs(modelderiv_beta(grid,coef(Est_dip_ds.largesd[[1]]$mod_est))))
names_df<-paste0(rep("y",times=((length(Est_dip_ds.largesd)))+1), "_", 1:(length(Est_dip_ds.largesd)+1))
for(i in 2:length(Est_dip_ds.largesd)){
  dip_ds_largesd_results_ff_df<-cbind(dip_ds_largesd_results_ff_df,abs(modelderiv_beta(grid,coef(Est_dip_ds.largesd[[i]]$mod_est))))
}
dip_ds_largesd_results_ff_df<-cbind(dip_ds_largesd_results_ff_df,abs(modelderiv_beta_dip_ds(grid)))

colnames(dip_ds_largesd_results_ff_df)<-c("x",names_df)


dip_ds_largesd_melted_ff<-melt(dip_ds_largesd_results_ff_df,id="x")

Dip_ds_largesd_p_ff<-ggplot(data=dip_ds_largesd_melted_ff,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=c(rep("grey",1000),"black")) +
  scale_alpha_manual(values=c(rep(0.25,1000),1)) +
  scale_linewidth_manual(values=c(rep(0.75,1000),1)) +
  ylim(0,0.5)+
  #ggtitle("Scenario 5") +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=45,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.005, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none")
Dip_ds_largesd_p_ff
ggsave("./plots_tables/3118_Dip_ds_largesd_ff.pdf",width=5,height=5,unit="cm")

####All####
patch_ff<-Norelev_smallsd_p_ff+Norelev_msmallsd_p_ff+Norelev_mediumsd_p_ff+Norelev_mlargesd_p_ff+Norelev_largesd_p_ff+
  Smalljump_smallsd_p_ff+Smalljump_msmallsd_p_ff+Smalljump_mediumsd_p_ff+Smalljump_mlargesd_p_ff+Smalljump_largesd_p_ff+ 
  Wider_smallsd_p_ff+Wider_msmallsd_p_ff+Wider_mediumsd_p_ff+Wider_mlargesd_p_ff+Wider_largesd_p_ff+
  Dip_smallsd_p_ff+Dip_msmallsd_p_ff+Dip_mediumsd_p_ff+Dip_mlargesd_p_ff+Dip_largesd_p_ff+
  Dip_ds_smallsd_p_ff+Dip_ds_msmallsd_p_ff+Dip_ds_mediumsd_p_ff+Dip_ds_mlargesd_p_ff+Dip_ds_largesd_p_ff+ 
  Nodip_smallsd_p_ff+Nodip_msmallsd_p_ff+Nodip_mediumsd_p_ff+Nodip_mlargesd_p_ff+Nodip_largesd_p_ff + 
  plot_layout(width=c(1,1,1,1,1),nrow=6)
patch_ff
ggsave("./plots_tables/1001_ff_all.pdf",width=50,height=55,unit="cm")
ggsave("./plots_tables/1001_ff_all.tiff",width=50,height=55,unit="cm",dpi=600, compression = "lzw")

##########################################################################
####Figures in Section 3:Results, estimated time frame Figure 3, D,E,F####
##########################################################################
####norelev####
#smallsd
norelev_smallsd_p_tf<-ggplot(data.frame(x=c(-1),y=c(-1)),mapping = aes(x = x,y = y))+
  geom_point(shape=20,size=0.01,col="darkorange")+
  xlab("Run") +
  ylab("Time (Weeks)") +
  ylim(0,45) +
  xlim(0,1000) +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
norelev_smallsd_p_tf
ggsave("./plots_tables/3104_norelev_smallsd_tf.pdf",width=5,height=5,unit="cm")

#The same results were observed for all other cases, therefore we will just use this plot again
####Smalljump####
#smallsd
tf_smalljump.smallsd<-Time_frames_smalljump.smallsd
tf_smalljump.smallsd[is.na(tf_smalljump.smallsd)==T]<-0

smalljump_smallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_smalljump.smallsd),y1=tf_smalljump.smallsd[,1],y2=tf_smalljump.smallsd[,2],y3=tf_smalljump.smallsd[,3],y4=tf_smalljump.smallsd[,4],y5=tf_smalljump.smallsd[,5],y6=tf_smalljump.smallsd[,6],y7=tf_smalljump.smallsd[,7],y8=tf_smalljump.smallsd[,8],y9=tf_smalljump.smallsd[,9],y10=tf_smalljump.smallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=24.5,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
smalljump_smallsd_p_tf
ggsave("./plots_tables/3107_smalljump_smallsd_tf.pdf",width=20,height=5,unit="cm")

#smallsd
tf_smalljump.msmallsd<-Time_frames_smalljump.msmallsd
tf_smalljump.msmallsd[is.na(tf_smalljump.msmallsd)==T]<-0

smalljump_msmallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_smalljump.msmallsd),y1=tf_smalljump.msmallsd[,1],y2=tf_smalljump.msmallsd[,2],y3=tf_smalljump.msmallsd[,3],y4=tf_smalljump.msmallsd[,4],y5=tf_smalljump.msmallsd[,5],y6=tf_smalljump.msmallsd[,6],y7=tf_smalljump.msmallsd[,7],y8=tf_smalljump.msmallsd[,8],y9=tf_smalljump.msmallsd[,9],y10=tf_smalljump.msmallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=24.5,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
smalljump_msmallsd_p_tf
ggsave("./plots_tables/3107_smalljump_msmallsd_tf.pdf",width=20,height=5,unit="cm")

#mediumsd
tf_smalljump.mediumsd<-Time_frames_smalljump.mediumsd
tf_smalljump.mediumsd[is.na(tf_smalljump.mediumsd)==T]<-0

smalljump_mediumsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_smalljump.mediumsd),y1=tf_smalljump.mediumsd[,1],y2=tf_smalljump.mediumsd[,2],y3=tf_smalljump.mediumsd[,3],y4=tf_smalljump.mediumsd[,4],y5=tf_smalljump.mediumsd[,5],y6=tf_smalljump.mediumsd[,6],y7=tf_smalljump.mediumsd[,7],y8=tf_smalljump.mediumsd[,8],y9=tf_smalljump.mediumsd[,9],y10=tf_smalljump.mediumsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=24.5,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
smalljump_mediumsd_p_tf
ggsave("./plots_tables/3107_smalljump_mediumsd_tf.pdf",width=20,height=5,unit="cm")


#mlargesd
tf_smalljump.mlargesd<-Time_frames_smalljump.mlargesd
tf_smalljump.mlargesd[is.na(tf_smalljump.mlargesd)==T]<-0

smalljump_mlargesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_smalljump.mlargesd),y1=tf_smalljump.mlargesd[,1],y2=tf_smalljump.mlargesd[,2],y3=tf_smalljump.mlargesd[,3],y4=tf_smalljump.mlargesd[,4],y5=tf_smalljump.mlargesd[,5],y6=tf_smalljump.mlargesd[,6],y7=tf_smalljump.mlargesd[,7],y8=tf_smalljump.mlargesd[,8],y9=tf_smalljump.mlargesd[,9],y10=tf_smalljump.mlargesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=24.5,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
smalljump_mlargesd_p_tf
ggsave("./plots_tables/3107_smalljump_mlargesd_tf.pdf",width=20,height=5,unit="cm")


#largesd
tf_smalljump.largesd<-Time_frames_smalljump.largesd
tf_smalljump.largesd[is.na(tf_smalljump.largesd)==T]<-0

smalljump_largesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_smalljump.largesd),y1=tf_smalljump.largesd[,1],y2=tf_smalljump.largesd[,2],y3=tf_smalljump.largesd[,3],y4=tf_smalljump.largesd[,4],y5=tf_smalljump.largesd[,5],y6=tf_smalljump.largesd[,6],y7=tf_smalljump.largesd[,7],y8=tf_smalljump.largesd[,8],y9=tf_smalljump.largesd[,9],y10=tf_smalljump.largesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=11.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=24.5,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
smalljump_largesd_p_tf
ggsave("./plots_tables/3107_smalljump_largesd_tf.pdf",width=20,height=5,unit="cm")

####wider####
#smallsd
tf_wider.smallsd<-Time_frames_wider.smallsd
tf_wider.smallsd[is.na(tf_wider.smallsd)==T]<-0

wider_smallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_wider.smallsd),y1=tf_wider.smallsd[,1],y2=tf_wider.smallsd[,2],y3=tf_wider.smallsd[,3],y4=tf_wider.smallsd[,4],y5=tf_wider.smallsd[,5],y6=tf_wider.smallsd[,6],y7=tf_wider.smallsd[,7],y8=tf_wider.smallsd[,8],y9=tf_wider.smallsd[,9],y10=tf_wider.smallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=36.3,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                          colour = "white",
                                          size = 0.5, linetype = "solid"),
          panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                          colour = "white"), 
          panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                          colour = "white"),legend.position = "none") 
wider_smallsd_p_tf
ggsave("./plots_tables/3107_wider_smallsd_tf.pdf",width=20,height=5,unit="cm")

#msmallsd
tf_wider.msmallsd<-Time_frames_wider.msmallsd
tf_wider.msmallsd[is.na(tf_wider.msmallsd)==T]<-0

wider_msmallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_wider.msmallsd),y1=tf_wider.msmallsd[,1],y2=tf_wider.msmallsd[,2],y3=tf_wider.msmallsd[,3],y4=tf_wider.msmallsd[,4],y5=tf_wider.msmallsd[,5],y6=tf_wider.msmallsd[,6],y7=tf_wider.msmallsd[,7],y8=tf_wider.msmallsd[,8],y9=tf_wider.msmallsd[,9],y10=tf_wider.msmallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=36.3,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
wider_msmallsd_p_tf
ggsave("./plots_tables/3107_wider_msmallsd_tf.pdf",width=5,height=5,unit="cm")

#mediumsd
tf_wider.mediumsd<-Time_frames_wider.mediumsd
tf_wider.mediumsd[is.na(tf_wider.mediumsd)==T]<-0

wider_mediumsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_wider.mediumsd),y1=tf_wider.mediumsd[,1],y2=tf_wider.mediumsd[,2],y3=tf_wider.mediumsd[,3],y4=tf_wider.mediumsd[,4],y5=tf_wider.mediumsd[,5],y6=tf_wider.mediumsd[,6],y7=tf_wider.mediumsd[,7],y8=tf_wider.mediumsd[,8],y9=tf_wider.mediumsd[,9],y10=tf_wider.mediumsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=36.3,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
wider_mediumsd_p_tf
ggsave("./plots_tables/3107_wider_mediumsd_tf.pdf",width=20,height=5,unit="cm")


#mlargesd
tf_wider.mlargesd<-Time_frames_wider.mlargesd
tf_wider.mlargesd[is.na(tf_wider.mlargesd)==T]<-0

wider_mlargesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_wider.mlargesd),y1=tf_wider.mlargesd[,1],y2=tf_wider.mlargesd[,2],y3=tf_wider.mlargesd[,3],y4=tf_wider.mlargesd[,4],y5=tf_wider.mlargesd[,5],y6=tf_wider.mlargesd[,6],y7=tf_wider.mlargesd[,7],y8=tf_wider.mlargesd[,8],y9=tf_wider.mlargesd[,9],y10=tf_wider.mlargesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=36.3,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
wider_mlargesd_p_tf
ggsave("./plots_tables/3107_wider_mlargesd_tf.pdf",width=20,height=5,unit="cm")


#largesd
tf_wider.largesd<-Time_frames_wider.largesd
tf_wider.largesd[is.na(tf_wider.largesd)==T]<-0

wider_largesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_wider.largesd),y1=tf_wider.largesd[,1],y2=tf_wider.largesd[,2],y3=tf_wider.largesd[,3],y4=tf_wider.largesd[,4],y5=tf_wider.largesd[,5],y6=tf_wider.largesd[,6],y7=tf_wider.largesd[,7],y8=tf_wider.largesd[,8],y9=tf_wider.largesd[,9],y10=tf_wider.largesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.9,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=36.3,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
wider_largesd_p_tf
ggsave("./plots_tables/3107_wider_largesd_tf.pdf",width=20,height=5,unit="cm")

####nodip####
#smallsd
tf_nodip.smallsd<-Time_frames_nodip.smallsd
tf_nodip.smallsd[is.na(tf_nodip.smallsd)==T]<-0

nodip_smallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_nodip.smallsd),y1=tf_nodip.smallsd[,1],y2=tf_nodip.smallsd[,2],y3=tf_nodip.smallsd[,3],y4=tf_nodip.smallsd[,4],y5=tf_nodip.smallsd[,5],y6=tf_nodip.smallsd[,6],y7=tf_nodip.smallsd[,7],y8=tf_nodip.smallsd[,8],y9=tf_nodip.smallsd[,9],y10=tf_nodip.smallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=28.9,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
nodip_smallsd_p_tf
ggsave("./plots_tables/3107_nodip_smallsd_tf.pdf",width=20,height=5,unit="cm")


#msmallsd
tf_nodip.msmallsd<-Time_frames_nodip.msmallsd
tf_nodip.msmallsd[is.na(tf_nodip.msmallsd)==T]<-0

nodip_msmallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_nodip.msmallsd),y1=tf_nodip.msmallsd[,1],y2=tf_nodip.msmallsd[,2],y3=tf_nodip.msmallsd[,3],y4=tf_nodip.msmallsd[,4],y5=tf_nodip.msmallsd[,5],y6=tf_nodip.msmallsd[,6],y7=tf_nodip.msmallsd[,7],y8=tf_nodip.msmallsd[,8],y9=tf_nodip.msmallsd[,9],y10=tf_nodip.msmallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=28.9,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
nodip_msmallsd_p_tf
ggsave("./plots_tables/3107_nodip_msmallsd_tf.pdf",width=20,height=5,unit="cm")

#mediumsd
tf_nodip.mediumsd<-Time_frames_nodip.mediumsd
tf_nodip.mediumsd[is.na(tf_nodip.mediumsd)==T]<-0

nodip_mediumsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_nodip.mediumsd),y1=tf_nodip.mediumsd[,1],y2=tf_nodip.mediumsd[,2],y3=tf_nodip.mediumsd[,3],y4=tf_nodip.mediumsd[,4],y5=tf_nodip.mediumsd[,5],y6=tf_nodip.mediumsd[,6],y7=tf_nodip.mediumsd[,7],y8=tf_nodip.mediumsd[,8],y9=tf_nodip.mediumsd[,9],y10=tf_nodip.mediumsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=28.9,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
nodip_mediumsd_p_tf
ggsave("./plots_tables/3107_nodip_mediumsd_tf.pdf",width=20,height=5,unit="cm")


#mlargesd
tf_nodip.mlargesd<-Time_frames_nodip.mlargesd
tf_nodip.mlargesd[is.na(tf_nodip.mlargesd)==T]<-0

nodip_mlargesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_nodip.mlargesd),y1=tf_nodip.mlargesd[,1],y2=tf_nodip.mlargesd[,2],y3=tf_nodip.mlargesd[,3],y4=tf_nodip.mlargesd[,4],y5=tf_nodip.mlargesd[,5],y6=tf_nodip.mlargesd[,6],y7=tf_nodip.mlargesd[,7],y8=tf_nodip.mlargesd[,8],y9=tf_nodip.mlargesd[,9],y10=tf_nodip.mlargesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=28.9,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
nodip_mlargesd_p_tf
ggsave("./plots_tables/3107_nodip_mlargesd_tf.pdf",width=20,height=5,unit="cm")


#largesd
tf_nodip.largesd<-Time_frames_nodip.largesd
tf_nodip.largesd[is.na(tf_nodip.largesd)==T]<-0

nodip_largesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_nodip.largesd),y1=tf_nodip.largesd[,1],y2=tf_nodip.largesd[,2],y3=tf_nodip.largesd[,3],y4=tf_nodip.largesd[,4],y5=tf_nodip.largesd[,5],y6=tf_nodip.largesd[,6],y7=tf_nodip.largesd[,7],y8=tf_nodip.largesd[,8],y9=tf_nodip.largesd[,9],y10=tf_nodip.largesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=28.9,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
nodip_largesd_p_tf
ggsave("./plots_tables/3107_nodip_largesd_tf.pdf",width=20,height=5,unit="cm")

####dip####
#smallsd
tf_dip.smallsd<-Time_frames_dip.smallsd
tf_dip.smallsd[is.na(tf_dip.smallsd)==T]<-0

dip_smallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip.smallsd),y1=tf_dip.smallsd[,1],y2=tf_dip.smallsd[,2],y3=tf_dip.smallsd[,3],y4=tf_dip.smallsd[,4],y5=tf_dip.smallsd[,5],y6=tf_dip.smallsd[,6],y7=tf_dip.smallsd[,7],y8=tf_dip.smallsd[,8],y9=tf_dip.smallsd[,9],y10=tf_dip.smallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_smallsd_p_tf
ggsave("./plots_tables/3107_dip_smallsd_tf.pdf",width=20,height=5,unit="cm")


#msmallsd
tf_dip.msmallsd<-Time_frames_dip.msmallsd
tf_dip.msmallsd[is.na(tf_dip.msmallsd)==T]<-0

dip_msmallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip.msmallsd),y1=tf_dip.msmallsd[,1],y2=tf_dip.msmallsd[,2],y3=tf_dip.msmallsd[,3],y4=tf_dip.msmallsd[,4],y5=tf_dip.msmallsd[,5],y6=tf_dip.msmallsd[,6],y7=tf_dip.msmallsd[,7],y8=tf_dip.msmallsd[,8],y9=tf_dip.msmallsd[,9],y10=tf_dip.msmallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_msmallsd_p_tf
ggsave("./plots_tables/3107_dip_msmallsd_tf.pdf",width=20,height=5,unit="cm")

#mediumsd
tf_dip.mediumsd<-Time_frames_dip.mediumsd
tf_dip.mediumsd[is.na(tf_dip.mediumsd)==T]<-0

dip_mediumsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip.mediumsd),y1=tf_dip.mediumsd[,1],y2=tf_dip.mediumsd[,2],y3=tf_dip.mediumsd[,3],y4=tf_dip.mediumsd[,4],y5=tf_dip.mediumsd[,5],y6=tf_dip.mediumsd[,6],y7=tf_dip.mediumsd[,7],y8=tf_dip.mediumsd[,8],y9=tf_dip.mediumsd[,9],y10=tf_dip.mediumsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_mediumsd_p_tf
ggsave("./plots_tables/3107_dip_mediumsd_tf.pdf",width=20,height=5,unit="cm")

#mlargesd
tf_dip.mlargesd<-Time_frames_dip.mlargesd
tf_dip.mlargesd[is.na(tf_dip.mlargesd)==T]<-0

dip_mlargesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip.mlargesd),y1=tf_dip.mlargesd[,1],y2=tf_dip.mlargesd[,2],y3=tf_dip.mlargesd[,3],y4=tf_dip.mlargesd[,4],y5=tf_dip.mlargesd[,5],y6=tf_dip.mlargesd[,6],y7=tf_dip.mlargesd[,7],y8=tf_dip.mlargesd[,8],y9=tf_dip.mlargesd[,9],y10=tf_dip.mlargesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_mlargesd_p_tf
ggsave("./plots_tables/3107_dip_mlargesd_tf.pdf",width=20,height=5,unit="cm")

#largesd
tf_dip.largesd<-Time_frames_dip.largesd
tf_dip.largesd[is.na(tf_dip.largesd)==T]<-0

dip_largesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip.largesd),y1=tf_dip.largesd[,1],y2=tf_dip.largesd[,2],y3=tf_dip.largesd[,3],y4=tf_dip.largesd[,4],y5=tf_dip.largesd[,5],y6=tf_dip.largesd[,6],y7=tf_dip.largesd[,7],y8=tf_dip.largesd[,8],y9=tf_dip.largesd[,9],y10=tf_dip.largesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=0.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=33.6,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=41.2,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_largesd_p_tf
ggsave("./plots_tables/3107_dip_largesd_tf.pdf",width=20,height=5,unit="cm")

####dip_ds####
#smallsd
tf_dip_ds.smallsd<-Time_frames_dip_ds.smallsd
tf_dip_ds.smallsd[is.na(tf_dip_ds.smallsd)==T]<-0

dip_ds_smallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip_ds.smallsd),y1=tf_dip_ds.smallsd[,1],y2=tf_dip_ds.smallsd[,2],y3=tf_dip_ds.smallsd[,3],y4=tf_dip_ds.smallsd[,4],y5=tf_dip_ds.smallsd[,5],y6=tf_dip_ds.smallsd[,6],y7=tf_dip_ds.smallsd[,7],y8=tf_dip_ds.smallsd[,8],y9=tf_dip_ds.smallsd[,9],y10=tf_dip_ds.smallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_ds_smallsd_p_tf
ggsave("./plots_tables/3107_dip_ds_smallsd_tf.pdf",width=20,height=5,unit="cm")

#msmallsd
tf_dip_ds.msmallsd<-Time_frames_dip_ds.msmallsd
tf_dip_ds.msmallsd[is.na(tf_dip_ds.msmallsd)==T]<-0

dip_ds_msmallsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip_ds.msmallsd),y1=tf_dip_ds.msmallsd[,1],y2=tf_dip_ds.msmallsd[,2],y3=tf_dip_ds.msmallsd[,3],y4=tf_dip_ds.msmallsd[,4],y5=tf_dip_ds.msmallsd[,5],y6=tf_dip_ds.msmallsd[,6],y7=tf_dip_ds.msmallsd[,7],y8=tf_dip_ds.msmallsd[,8],y9=tf_dip_ds.msmallsd[,9],y10=tf_dip_ds.msmallsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_ds_msmallsd_p_tf
ggsave("./plots_tables/3107_dip_ds_msmallsd_tf.pdf",width=20,height=5,unit="cm")

#mediumsd
tf_dip_ds.mediumsd<-Time_frames_dip_ds.mediumsd
tf_dip_ds.mediumsd[is.na(tf_dip_ds.mediumsd)==T]<-0

dip_ds_mediumsd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip_ds.mediumsd),y1=tf_dip_ds.mediumsd[,1],y2=tf_dip_ds.mediumsd[,2],y3=tf_dip_ds.mediumsd[,3],y4=tf_dip_ds.mediumsd[,4],y5=tf_dip_ds.mediumsd[,5],y6=tf_dip_ds.mediumsd[,6],y7=tf_dip_ds.mediumsd[,7],y8=tf_dip_ds.mediumsd[,8],y9=tf_dip_ds.mediumsd[,9],y10=tf_dip_ds.mediumsd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_ds_mediumsd_p_tf
ggsave("./plots_tables/3107_dip_ds_mediumsd_tf.pdf",width=20,height=5,unit="cm")

#mlargesd
tf_dip_ds.mlargesd<-Time_frames_dip_ds.mlargesd
tf_dip_ds.mlargesd[is.na(tf_dip_ds.mlargesd)==T]<-0

dip_ds_mlargesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip_ds.mlargesd),y1=tf_dip_ds.mlargesd[,1],y2=tf_dip_ds.mlargesd[,2],y3=tf_dip_ds.mlargesd[,3],y4=tf_dip_ds.mlargesd[,4],y5=tf_dip_ds.mlargesd[,5],y6=tf_dip_ds.mlargesd[,6],y7=tf_dip_ds.mlargesd[,7],y8=tf_dip_ds.mlargesd[,8],y9=tf_dip_ds.mlargesd[,9],y10=tf_dip_ds.mlargesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_ds_mlargesd_p_tf
ggsave("./plots_tables/3107_dip_ds_mlargesd_tf.pdf",width=20,height=5,unit="cm")


#largesd
tf_dip_ds.largesd<-Time_frames_dip_ds.largesd
tf_dip_ds.largesd[is.na(tf_dip_ds.largesd)==T]<-0

dip_ds_largesd_p_tf<-ggplot(data.frame(x=1:nrow(Time_frames_dip_ds.largesd),y1=tf_dip_ds.largesd[,1],y2=tf_dip_ds.largesd[,2],y3=tf_dip_ds.largesd[,3],y4=tf_dip_ds.largesd[,4],y5=tf_dip_ds.largesd[,5],y6=tf_dip_ds.largesd[,6],y7=tf_dip_ds.largesd[,7],y8=tf_dip_ds.largesd[,8],y9=tf_dip_ds.largesd[,9],y10=tf_dip_ds.largesd[,10]), aes(x=x)) +
  geom_bar(stat="identity",aes(x=x,y=y10),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y9),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y8),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y7),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y6),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y5),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y4),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y3),color="white",fill="white")+
  geom_bar(stat="identity",aes(x=x,y=y2),color="darkorange",fill="darkorange")+
  geom_bar(stat="identity",aes(x=x,y=y1),color="white",fill="white")+
  geom_hline(yintercept=5.7,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=38.1,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=39.4,col="orangered2",linetype="dotdash") +
  geom_hline(yintercept=45,col="orangered2",linetype="dotdash") +
  ylim(0,45) +
  xlab("Run") +
  ylab("Time (Weeks)") +
  theme(axis.text=element_text(size=12),axis.title=element_text(size=13),plot.title=element_text(size=14),
        panel.background = element_rect(fill = "white",
                                        colour = "white",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
dip_ds_largesd_p_tf
ggsave("./plots_tables/3107_dip_ds_largesd_tf.pdf",width=20,height=5,unit="cm")

########################################################
###Figures in Section 3: Results, all plots combined####
########################################################
####Small sd####
Norelev_smallsd_p<-Norelev_smallsd_p_mf+Norelev_smallsd_p_cb+norelev_smallsd_p_tf
Smalljump_smallsd_p<-Smalljump_smallsd_p_mf+Smalljump_smallsd_p_cb+smalljump_smallsd_p_tf
Wider_smallsd_p<-Wider_smallsd_p_mf+Wider_smallsd_p_cb+wider_smallsd_p_tf
Dip_smallsd_p<-Dip_smallsd_p_mf+Dip_smallsd_p_cb+dip_smallsd_p_tf
Dip_ds_smallsd_p<-Dip_ds_smallsd_p_mf+Dip_ds_smallsd_p_cb+dip_ds_smallsd_p_tf
Nodip_smallsd_p<-Nodip_smallsd_p_mf+Nodip_smallsd_p_cb+nodip_smallsd_p_tf


patch_smallsd<-Norelev_smallsd_p/Smalljump_smallsd_p/Wider_smallsd_p/Dip_smallsd_p/Dip_ds_smallsd_p/Nodip_smallsd_p
ggsave("./plots_tables/3000_Results_smallsd.png",width=15,height=25,unit="cm")
ggsave("./plots_tables/3000_Results_smallsd.tiff",width=15,height=25,unit="cm",dpi=600, compression = "lzw")


####mSmall sd####
Norelev_msmallsd_p<-Norelev_msmallsd_p_mf+Norelev_msmallsd_p_cb+norelev_smallsd_p_tf
Smalljump_msmallsd_p<-Smalljump_msmallsd_p_mf+Smalljump_msmallsd_p_cb+smalljump_msmallsd_p_tf
Wider_msmallsd_p<-Wider_msmallsd_p_mf+Wider_msmallsd_p_cb+wider_msmallsd_p_tf
Dip_msmallsd_p<-Dip_msmallsd_p_mf+Dip_msmallsd_p_cb+dip_msmallsd_p_tf
Dip_ds_msmallsd_p<-Dip_ds_msmallsd_p_mf+Dip_ds_msmallsd_p_cb+dip_ds_msmallsd_p_tf
Nodip_msmallsd_p<-Nodip_msmallsd_p_mf+Nodip_msmallsd_p_cb+nodip_msmallsd_p_tf


patch_msmallsd<-Norelev_msmallsd_p/Smalljump_msmallsd_p/Wider_msmallsd_p/Dip_msmallsd_p/Dip_ds_msmallsd_p/Nodip_msmallsd_p
ggsave("./plots_tables/3001_Results_msmallsd.png",width=15,height=25,unit="cm")
ggsave("./plots_tables/3001_Results_msmallsd.tiff",width=15,height=25,unit="cm",dpi=600, compression = "lzw")

####medium sd####
Norelev_mediumsd_p<-Norelev_mediumsd_p_mf+Norelev_mediumsd_p_cb+norelev_smallsd_p_tf
Smalljump_mediumsd_p<-Smalljump_mediumsd_p_mf+Smalljump_mediumsd_p_cb+smalljump_mediumsd_p_tf
Wider_mediumsd_p<-Wider_mediumsd_p_mf+Wider_mediumsd_p_cb+wider_mediumsd_p_tf
Dip_mediumsd_p<-Dip_mediumsd_p_mf+Dip_mediumsd_p_cb+dip_mediumsd_p_tf
Dip_ds_mediumsd_p<-Dip_ds_mediumsd_p_mf+Dip_ds_mediumsd_p_cb+dip_ds_mediumsd_p_tf
Nodip_mediumsd_p<-Nodip_mediumsd_p_mf+Nodip_mediumsd_p_cb+nodip_mediumsd_p_tf


patch_mediumsd<-Norelev_mediumsd_p/Smalljump_mediumsd_p/Wider_mediumsd_p/Dip_mediumsd_p/Dip_ds_mediumsd_p/Nodip_mediumsd_p
ggsave("./plots_tables/3002_Results_mediumsd.png",width=15,height=25,unit="cm")
ggsave("./plots_tables/3002_Results_mediumsd.tiff",width=15,height=25,unit="cm",dpi=600, compression = "lzw")

####mlarge sd####
Norelev_mlargesd_p<-Norelev_mlargesd_p_mf+Norelev_mlargesd_p_cb+norelev_smallsd_p_tf
Smalljump_mlargesd_p<-Smalljump_mlargesd_p_mf+Smalljump_mlargesd_p_cb+smalljump_mlargesd_p_tf
Wider_mlargesd_p<-Wider_mlargesd_p_mf+Wider_mlargesd_p_cb+wider_mlargesd_p_tf
Dip_mlargesd_p<-Dip_mlargesd_p_mf+Dip_mlargesd_p_cb+dip_mlargesd_p_tf
Dip_ds_mlargesd_p<-Dip_ds_mlargesd_p_mf+Dip_ds_mlargesd_p_cb+dip_ds_mlargesd_p_tf
Nodip_mlargesd_p<-Nodip_mlargesd_p_mf+Nodip_mlargesd_p_cb+nodip_mlargesd_p_tf


patch_mlargesd<-Norelev_mlargesd_p/Smalljump_mlargesd_p/Wider_mlargesd_p/Dip_mlargesd_p/Dip_ds_mlargesd_p/Nodip_mlargesd_p
ggsave("./plots_tables/3003_Results_mlargesd.png",width=15,height=25,unit="cm")
ggsave("./plots_tables/3003_Results_mlargesd.tiff",width=15,height=25,unit="cm",dpi=600, compression = "lzw")


####Large sd####
Norelev_largesd_p<-Norelev_largesd_p_mf+Norelev_largesd_p_cb+norelev_smallsd_p_tf
Smalljump_largesd_p<-Smalljump_largesd_p_mf+Smalljump_largesd_p_cb+smalljump_largesd_p_tf
Wider_largesd_p<-Wider_largesd_p_mf+Wider_largesd_p_cb+wider_largesd_p_tf
Dip_largesd_p<-Dip_largesd_p_mf+Dip_largesd_p_cb+dip_largesd_p_tf
Dip_ds_largesd_p<-Dip_ds_largesd_p_mf+Dip_ds_largesd_p_cb+dip_ds_largesd_p_tf
Nodip_largesd_p<-Nodip_largesd_p_mf+Nodip_largesd_p_cb+nodip_largesd_p_tf


patch_largesd<-Norelev_largesd_p/Smalljump_largesd_p/Wider_largesd_p/Dip_largesd_p/Dip_ds_largesd_p/Nodip_largesd_p
ggsave("./plots_tables/3004_Results_largesd.png",width=15,height=25,unit="cm")
ggsave("./plots_tables/3004_Results_largesd.tiff",width=15,height=25,unit="cm",dpi=600, compression = "lzw")

####################################################################################
###Figures in Section 3: Results, confidecne band and time frame Figure 3, D,E,F####
####################################################################################
####Small sd####
patch_smallsd_cbtf<-Norelev_smallsd_p_cb+norelev_smallsd_p_tf+plot_spacer()+
  Smalljump_smallsd_p_cb+smalljump_smallsd_p_tf+
  Wider_smallsd_p_cb+wider_smallsd_p_tf+plot_spacer()+
  Dip_smallsd_p_cb+dip_smallsd_p_tf+
  Dip_ds_smallsd_p_cb+dip_ds_smallsd_p_tf+plot_spacer()+
  Nodip_smallsd_p_cb+nodip_smallsd_p_tf+plot_layout(width=c(4,4,1,4,4),nrow=3)
ggsave("./plots_tables/3000_Results_smallsd_cbtf.tiff",width=35,height=20,unit="cm",dpi=600, compression = "lzw")
ggsave("./plots_tables/3000_Results_smallsd_cbtf.png",width=35,height=20,unit="cm")


####mSmall sd####
patch_msmallsd_cbtf<-Norelev_msmallsd_p_cb+norelev_smallsd_p_tf+plot_spacer()+
  Smalljump_msmallsd_p_cb+smalljump_msmallsd_p_tf+
  Wider_msmallsd_p_cb+wider_msmallsd_p_tf+plot_spacer()+
  Dip_msmallsd_p_cb+dip_msmallsd_p_tf+
  Dip_ds_msmallsd_p_cb+dip_ds_msmallsd_p_tf+plot_spacer()+
  Nodip_msmallsd_p_cb+nodip_msmallsd_p_tf+plot_layout(width=c(4,4,1,4,4),nrow=3)
ggsave("./plots_tables/3000_Results_msmallsd_cbtf.tiff",width=35,height=20,unit="cm",dpi=600, compression = "lzw")
ggsave("./plots_tables/3000_Results_msmallsd_cbtf.png",width=35,height=20,unit="cm")

####medium sd####
patch_mediumsd_cbtf<-Norelev_mediumsd_p_cb+norelev_smallsd_p_tf+plot_spacer()+
  Smalljump_mediumsd_p_cb+smalljump_mediumsd_p_tf+
  Wider_mediumsd_p_cb+wider_mediumsd_p_tf+plot_spacer()+
  Dip_mediumsd_p_cb+dip_mediumsd_p_tf+
  Dip_ds_mediumsd_p_cb+dip_ds_mediumsd_p_tf+plot_spacer()+
  Nodip_mediumsd_p_cb+nodip_mediumsd_p_tf+plot_layout(width=c(4,4,1,4,4),nrow=3)
ggsave("./plots_tables/3000_Results_mediumsd_cbtf.tiff",width=35,height=20,unit="cm",dpi=600, compression = "lzw")
ggsave("./plots_tables/3000_Results_mediumsd_cbtf.png",width=35,height=20,unit="cm")

####mlarge sd####
patch_mlargesd_cbtf<-Norelev_mlargesd_p_cb+norelev_smallsd_p_tf+plot_spacer()+
  Smalljump_mlargesd_p_cb+smalljump_mlargesd_p_tf+
  Wider_mlargesd_p_cb+wider_mlargesd_p_tf+plot_spacer()+
  Dip_mlargesd_p_cb+dip_mlargesd_p_tf+
  Dip_ds_mlargesd_p_cb+dip_ds_mlargesd_p_tf+plot_spacer()+
  Nodip_mlargesd_p_cb+nodip_mlargesd_p_tf+plot_layout(width=c(4,4,1,4,4),nrow=3)
ggsave("./plots_tables/3000_Results_mlargesd_cbtf.tiff",width=35,height=20,unit="cm",dpi=600, compression = "lzw")
ggsave("./plots_tables/3000_Results_mlargesd_cbtf.png",width=35,height=20,unit="cm")


####Large sd####
patch_largesd_cbtf<-Norelev_largesd_p_cb+norelev_smallsd_p_tf+plot_spacer()+
  Smalljump_largesd_p_cb+smalljump_largesd_p_tf+
  Wider_largesd_p_cb+wider_largesd_p_tf+plot_spacer()+
  Dip_largesd_p_cb+dip_largesd_p_tf+
  Dip_ds_largesd_p_cb+dip_ds_largesd_p_tf+plot_spacer()+
  Nodip_largesd_p_cb+nodip_largesd_p_tf+plot_layout(width=c(4,4,1,4,4),nrow=3)
ggsave("./plots_tables/3000_Results_largesd_cbtf.tiff",width=35,height=20,unit="cm",dpi=600, compression = "lzw")
ggsave("./plots_tables/3000_Results_largesd_cbtf.png",width=35,height=20,unit="cm")
####Multiple####
patch_ctbf_m1<-wrap_elements(patch_msmallsd_cbtf+plot_annotation(title = "A"))
patch_ctbf_m2<-wrap_elements(patch_mlargesd_cbtf+plot_annotation(title = "B"))

patch_ctbf_m<-patch_ctbf_m1/patch_ctbf_m2
ggsave("./plots_tables/3000_Results_m_cbtf.tiff",width=35,height=40,unit="cm",dpi=600, compression = "lzw")
ggsave("./plots_tables/3000_Results_m_cbtf.png",width=35,height=40,unit="cm")
ggsave("./plots_tables/3000_Results_m_cbtf.pdf",width=35,height=40,unit="cm")

############################
####Figures in Section 4####
############################
####Single genes####
#Cd163
#plot
Cd163_count<-ggplot(data=data.frame(x=grid,y=Cd163_modfunction(grid)),mapping = aes(x = x,y=y)) +
  ylim(6.5, 10) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Cd163") +
  geom_vline(xintercept=min(decision_example.d$timeframe_sign),linetype="dashed") +
  geom_vline(xintercept=max(decision_example.d$timeframe_sign),linetype="dashed") +
  #geom_vline(xintercept=min(decision_example.d_9w$timeframe_relev),linetype="dotdash",col="gold",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_9w$timeframe_relev),linetype="dotdash",col="gold",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_15w$timeframe_relev),linetype="dotdash",col="gold1",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_15w$timeframe_relev),linetype="dotdash",col="gold1",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_21w$timeframe_relev),linetype="dotdash",col="gold2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_21w$timeframe_relev),linetype="dotdash",col="gold2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_27w$timeframe_relev),linetype="dotdash",col="gold3",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_27w$timeframe_relev),linetype="dotdash",col="gold3",linewidth=0.5, alpha=0.4) +
  geom_vline(xintercept=min(decision_example.d_27_5w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  geom_vline(xintercept=max(decision_example.d_27_5w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_33w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_33w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_39w$timeframe_relev),linetype="dotdash",col="goldenrod3",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_39w$timeframe_relev),linetype="dotdash",col="goldenrod3",linewidth=0.5, alpha=0.4) +
  geom_vline(xintercept=min(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  geom_vline(xintercept=max(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 
Cd163_count
ggsave("./plots_tables/001_Cd163_gene_counts.pdf",width=5,height=5,unit="cm")

#Plot
ggplot(data=data.frame(x=grid,y=Cd163_modderiv_abs(grid)),aes(x = x,y=y)) +
  geom_line(linetype="solid") +
  ylim(-0.1,0.3) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  ggtitle("Cd163") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 


ggsave("./plots_tables/002_Cd163_deriv.pdf",width=5,height=5,unit="cm")

#Plot
Cd163_cb<-ggplot(data=data.frame(x=grid,y=Cd163_modderiv_abs(grid),z=conf_example.d),mapping = aes(x = x)) +
  geom_line(aes(x=x,y=y,color="black"),linetype="solid") +
  geom_line(aes(x=x,y=z,color="royalblue"),linetype="solid") +
  scale_color_manual(values = c("black","royalblue"),labels=c("Model Derivative","Confidence Band")) +
  ylim(-0.1,0.3) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  #ggtitle("Cd163") +
  geom_hline(yintercept=0) +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  #geom_hline(yintercept=lambda_39weeks,col="goldenrod4",linetype="dotted",linewidth=0.5, alpha=0.4) +
  #geom_hline(yintercept=lambda_33weeks,col="goldenrod3",linetype="dotted",linewidth=0.5, alpha=0.4) +
  geom_hline(yintercept=lambda_27_5_weeks,col="goldenrod2",linetype="dotted",linewidth=0.5, alpha=0.4) +
  #geom_hline(yintercept=lambda_27weeks,col="goldenrod2",linetype="dotted",linewidth=0.5, alpha=0.4) +    geom_hline(yintercept=lambda_27weeks,col="goldenrod2",linetype="dotted",linewidth=0.5, alpha=0.4) +
  #geom_hline(yintercept=lambda_21weeks,col="gold3",linetype="dotted",linewidth=0.5, alpha=0.4) +
  #geom_hline(yintercept=lambda_15weeks,col="gold2",linetype="dotted",linewidth=0.5, alpha=0.4) +
  #geom_hline(yintercept=lambda_9weeks,col="gold1",linetype="dotted",linewidth=0.5, alpha=0.4) +
  #geom_hline(yintercept=lambda_3weeks,col="gold",linetype="dotted",linewidth=0.5, alpha=0.4) +
  geom_vline(xintercept=min(decision_example.d$timeframe_sign),linetype="dashed") +
  geom_vline(xintercept=max(decision_example.d$timeframe_sign),linetype="dashed") +
  #geom_vline(xintercept=min(decision_example.d_9w$timeframe_relev),linetype="dotdash",col="gold",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_9w$timeframe_relev),linetype="dotdash",col="gold",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_15w$timeframe_relev),linetype="dotdash",col="gold1",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_15w$timeframe_relev),linetype="dotdash",col="gold1",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_21w$timeframe_relev),linetype="dotdash",col="gold2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_21w$timeframe_relev),linetype="dotdash",col="gold2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_27w$timeframe_relev),linetype="dotdash",col="gold3",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_27w$timeframe_relev),linetype="dotdash",col="gold3",linewidth=0.5, alpha=0.4) +
  geom_vline(xintercept=min(decision_example.d_27_5w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  geom_vline(xintercept=max(decision_example.d_27_5w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_33w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_33w$timeframe_relev),linetype="dotdash",col="goldenrod2",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=min(decision_example.d_39w$timeframe_relev),linetype="dotdash",col="goldenrod3",linewidth=0.5, alpha=0.4) +
  #geom_vline(xintercept=max(decision_example.d_39w$timeframe_relev),linetype="dotdash",col="goldenrod3",linewidth=0.5, alpha=0.4) +
  geom_vline(xintercept=min(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  geom_vline(xintercept=max(decision_example.d$timeframe_relev),linetype="dashed",col="orangered2") +
  annotate("text",y=lambda_45weeks+0.008, x=37, label="0.0130", size = 2.3,col="orangered2") +
  #annotate("text",y=lambda_39weeks+0.007, x=28, label="0.0150", size = 2,col="goldenrod4") +
  #annotate("text",y=lambda_33weeks+0.007, x=34, label="0.0177", size = 2,col="goldenrod3") +
  #annotate("text",y=lambda_27weeks+0.007, x=39, label="0.0217", size = 2,col="goldenrod2") +
  annotate("text",y=lambda_27_5_weeks+0.007, x=43, label="0.0213", size = 2.3,col="goldenrod2") +
  #annotate("text",y=lambda_21weeks+0.007, x=43, label="0.0279", size = 2,col="gold3") +
  #annotate("text",y=lambda_15weeks+0.007, x=43, label="0.0390", size = 2,col="gold2") +
  #annotate("text",y=lambda_9weeks+0.007, x=43, label="0.0650", size = 2,col="gold1") +
  #annotate("text",y=lambda_3weeks+0.007, x=43, label="0.1950", size = 2,col="gold") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),legend.title = element_blank(),legend.text=element_text(size=7),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 
Cd163_cb
ggsave("./plots_tables/003_Cd163_deriv_cb.pdf",width=10,height=10,unit="cm")

Cd163_count+Cd163_cb
ggsave("./plots_tables/024_Cd163.pdf",width=23,height=10,unit="cm")

####Aging####
#WD cases
#plot
ggplot(data=data.frame(x=grid,y=Dbp.WD_modfunction(grid)),mapping = aes(x = x,y=y)) +
  ylim(7, 12) +
  geom_line(linetype="solid") +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Dbp.WD") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

ggsave("./plots_tables/Dbp_WD_gene_counts.pdf",width=5,height=5,unit="cm")

#Plot
ggplot(data=data.frame(x=grid,y=Dbp.WD_modderiv_abs(grid)),aes(x = x,y=y)) +
  geom_line(linetype="solid") +
  ylim(0,0.3) +
  xlab("Time (Weeks)") +
  ylab("Change in  gene count") +
  ggtitle("Dbp.WD") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

ggsave("./plots_tables/Dbp_WD_deriv.pdf",width=5,height=5,unit="cm")

#SD
#plot
ggplot(data=data.frame(x=grid,y=Dbp.SD_modfunction(grid)),mapping = aes(x = x,y=y)) +
  geom_line(linetype="solid") +
  ylim(7, 12) +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Dbp.SD") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

ggsave("./plots_tables/Dbp_SD_gene_counts.pdf",width=5,height=5,unit="cm")

#Plot
ggplot(data=data.frame(x=grid,y=Dbp.SD_modderiv_abs(grid)),aes(x = x,y=y)) +
  geom_line(linetype="solid") +
  ylim(0,0.3) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  ggtitle("Dbp.SD") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

ggsave("./plots_tables/Dbp_SD_deriv.pdf",width=5,height=5,unit="cm")


#Both
Dbp.counts<-ggplot(data=data.frame(x=grid,y1=Dbp.WD_modfunction(grid),y2=Dbp.SD_modfunction(grid)),mapping = aes(x = x,y=y)) +
  ylim(7,12) +
  geom_line(aes(x = x,y=y1,linetype="solid")) +
  geom_line(aes(x = x,y=y2,linetype="dashed")) +
  scale_linetype_manual(values = c("solid","dashed"),labels=c("WD","SD")) +
  xlab("Time (Weeks)") +
  ylab("Gene count") +
  ggtitle("Dbp") +
  geom_vline(xintercept=min(decision_example.SD_Dbp$timeframe_relev),linetype="dotdash",col="orangered2") +
  geom_vline(xintercept=max(decision_example.SD_Dbp$timeframe_relev),linetype="dotdash",col="orangered2") +
  geom_vline(xintercept=min(decision_example.WD_Dbp$timeframe_relev),linetype="dotted",col="orangered2") +
  geom_vline(xintercept=max(decision_example.WD_Dbp$timeframe_relev),linetype="dotted",col="orangered2") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 
Dbp.counts
ggsave("./plots_tables/019_Dbp_counts.pdf",width=7,height=5,unit="cm")


ggplot(data=data.frame(x=grid,y1=Dbp.WD_modderiv_abs(grid),y2=Dbp.SD_modderiv_abs(grid)),mapping = aes(x = x,y=y)) +
  ylim(-0.1,0.3) +
  geom_line(aes(x = x,y=y1,linetype="solid")) +
  geom_line(aes(x = x,y=y2,linetype="dotted")) +
  scale_linetype_manual(values = c("solid","dotted"),labels=c("WD","SD")) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  ggtitle("Dbp") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 

ggsave("./plots_tables/020_Dbp_deriv.pdf",width=7,height=5,unit="cm")


Dbp.deriv_cb<-ggplot(data=data.frame(x=grid,y1=Dbp.WD_modderiv_abs(grid),y2=Dbp.SD_modderiv_abs(grid),z1=conf_example.WD_Dbp,z2=conf_example.SD_Dbp),mapping = aes(x = x,y=y)) +
  ylim(-0.1,0.4) +
  geom_line(aes(x = x,y=y1,linetype="solid",color="black")) +
  geom_line(aes(x = x,y=y2,linetype="dashed",color="black")) +
  geom_line(aes(x = x,y=z1,color="royalblue"),linetype="solid") +
  geom_line(aes(x = x,y=z2,color="royalblue"),linetype="dashed") +
  scale_linetype_manual(values = c("solid","dashed"),labels=c("WD","SD")) +
  scale_color_manual(values = c("black","royalblue"),labels=c("Model Derivative","Confidence Band")) +
  xlab("Time (Weeks)") +
  ylab("Change in gene count") +
  #ggtitle("Dbp") +
  geom_hline(yintercept=0) +
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=min(decision_example.SD_Dbp$timeframe_relev),linetype="dotdash",col="orangered2") +
  geom_vline(xintercept=max(decision_example.SD_Dbp$timeframe_relev),linetype="dotdash",col="orangered2") +
  geom_vline(xintercept=min(decision_example.WD_Dbp$timeframe_relev),linetype="dotted",col="orangered2") +
  geom_vline(xintercept=max(decision_example.WD_Dbp$timeframe_relev),linetype="dotted",col="orangered2") +
  annotate("text",y=lambda_45weeks+0.015, x=10, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white")) 
Dbp.deriv_cb
ggsave("./plots_tables/021_Dbp_deriv.pdf",width=15,height=10,unit="cm")


Dbp.counts+Dbp.deriv_cb
ggsave("./plots_tables/022_Dbp_comparison.pdf",width=23,height=10,unit="cm")


####GO Analysis####
ggplot(data=Gene_results_melted,mapping = aes(x = x,y = value,color=variable)) +
  geom_line(linewidth=0.5)+
  scale_color_manual(values = rep("royalblue",length(Gene_results))) +
  ylim(-0.5,0.5)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=10,col="darkorange",linetype="dotdash") +
  geom_vline(xintercept=25,col="darkorange",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=9),plot.title=element_text(size=10),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

ggsave("./plots_tables/017_GO_full.pdf",width=7,height=5,unit="cm")


color_GO<-rep("skyblue2",length(Gene_results))
color_GO[which(t_frame_dds_subset[,1]>10&t_frame_dds_subset[,2]<25)]<-"royalblue"

Gene_results_df_y<-Gene_results_df[,-1]
Gene_results_df_no<-Gene_results_df_y[,-which(t_frame_dds_subset[,1]>10&t_frame_dds_subset[,2]<25)]
Gene_results_df_yes<-Gene_results_df_y[,which(t_frame_dds_subset[,1]>10&t_frame_dds_subset[,2]<25)]
Gene_results_reorder<-cbind("x"=Gene_results_df[,1],Gene_results_df_no,Gene_results_df_yes)
Gene_results_reorder_melted<-melt(Gene_results_reorder,id="x")
color_GO_alt<-rep("skyblue2",length(Gene_results))
color_GO_alt[(length(color_GO_alt)-ncol(Gene_results_df_yes)):length(color_GO_alt)]<-"royalblue"

ggplot(data=Gene_results_reorder_melted,mapping = aes(x = x)) +
  geom_line(aes(x = x,y = value,alpha=variable,color=variable,linewidth=variable))+
  scale_color_manual(values=color_GO_alt) +
  scale_alpha_manual(values=c(rep(0.75,length(color_GO_alt)))) +
  scale_linewidth_manual(values=c(rep(0.25,length(color_GO_alt)),1)) +
  ylim(-0.3,0.3)+
  geom_hline(yintercept=lambda_45weeks,col="orangered2") +
  geom_vline(xintercept=10,col="orangered2",linetype="dotdash") +
  geom_vline(xintercept=25,col="orangered2",linetype="dotdash") +
  ylab("Change in gene count") +
  xlab("Time (Weeks)") +
  annotate("text",y=lambda_45weeks+0.035, x=40, label="0.0130", size = 2.3,col="orangered2") +
  theme(axis.text=element_text(size=4),axis.title=element_text(size=5),plot.title=element_text(size=6),
        panel.background = element_rect(fill = "gray96",
                                        colour = "gray96",
                                        size = 0.5, linetype = "solid"),
        panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                        colour = "white"), 
        panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                        colour = "white"),legend.position = "none") 

ggsave("./plots_tables/018_GO_full_diff.pdf",width=7,height=5,unit="cm")
ggsave("./plots_tables/018_GO_full_diff.tiff",width=7,height=5,unit="cm",dpi=600, compression = "lzw")



####Save Workingspace####
save.image(file="./plot_generation/plot_generation_WDM_all.RData")
