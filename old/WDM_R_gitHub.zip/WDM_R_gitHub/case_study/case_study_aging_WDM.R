load("./case_study/case_study_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)


#############################
#### Analysis of WD data ####
#############################
#Load count and times
timevector_WD<-subset(example_Dbp$time,example_Dbp$diet=="WD")
example.WD_Dbp<-subset(example_Dbp,example_Dbp$diet=="WD")$count

#Test models
#sigEmax
mod_example.WD_Dbp_sigmoid <- suppressMessages(fitMod(dose=timevector, resp=example.WD_Dbp, model="sigEmax"))
AIC(mod_example.WD_Dbp_sigmoid)
#143.7832

#beta
mod_example.WD_Dbp_beta <- suppressMessages(fitMod(dose=timevector, resp=example.WD_Dbp, model="betaMod"))
AIC(mod_example.WD_Dbp_beta)
#148.4274

#Since the AIC is smaller for the sigEmax model, we will continue with it
#Extract variables
sd_example.WD_Dbp <- sqrt(mod_example.WD_Dbp_sigmoid$RSS/mod_example.WD_Dbp_sigmoid$df)
theta_example.WD_Dbp <- unname(coef(mod_example.WD_Dbp_sigmoid))

#Model function
Dbp.WD_modfunction<-function(t){
  count<-modelfunction_sigmoid(t,theta_example.WD_Dbp)
  return(count)
}


#First derivative and absolute value of first derivative
Dbp.WD_modderiv<-function(t){
  count<-modelderiv_sigmoid(t,theta_example.WD_Dbp)
  return(count)
}
#absolute value of first derivative
Dbp.WD_modderiv_abs<-function(t){
  count<-modelderiv_sigmoid(t,theta_example.WD_Dbp)
  return(abs(count))
}


#Perform analysis
set.seed(23)
#draw seeds for inner bootstrap
seeds_example.WD_Dbp<-sample(1:100000000,B1,replace=F)

outerboot_example.WD_Dbp<-bootstrap(theta=theta_example.WD_Dbp,sd=sd_example.WD_Dbp,B_out=B1,tvector=timevector,model_name = "sigEmax")
crit.val.boot_example.WD_Dbp<-crit.val.boot(theta = theta_example.WD_Dbp,B_out=B1,B_in=B2,outerboot_example.WD_Dbp,model_name = "sigEmax",tvector=timevector,seeds=seeds_example.WD_Dbp)
c_example.WD_Dbp<-crit.val(crit.val.boot =crit.val.boot_example.WD_Dbp)
conf_example.WD_Dbp<-conf.bands(theta = theta_example.WD_Dbp,c=c_example.WD_Dbp,outerboot=outerboot_example.WD_Dbp,model_name = "sigEmax")
decision_example.WD_Dbp<-Test.decision(conf= conf_example.WD_Dbp,lambda=lambda_45weeks)

decision_example.WD_Dbp$result_sign
#1

decision_example.WD_Dbp$result_relev
#1

relev_example.WD_Dbp<-t_points_change(decision_example.WD_Dbp$timeframe_relev)
#beginning       end 
#36.9      45.0 

#relevant
(model_sigmoid(relev_example.WD_Dbp[1],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3],theta_example.WD_Dbp[4])-model_sigmoid(relev_example.WD_Dbp[2],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3],theta_example.WD_Dbp[4]))
#2.212898 
(model_sigmoid(relev_example.WD_Dbp[1],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3],theta_example.WD_Dbp[4])-model_sigmoid(relev_example.WD_Dbp[2],theta_example.WD_Dbp[1],theta_example.WD_Dbp[2],theta_example.WD_Dbp[3],theta_example.WD_Dbp[4]))/(relev_example.WD_Dbp[2]-relev_example.WD_Dbp[1])
#0.2731973 
(relev_example.WD_Dbp[2]-relev_example.WD_Dbp[1])
#8.1 

#############################
#### Analysis of SD data ####
#############################
#Load count and times
timevector_SD<-subset(example_Dbp$time,example_Dbp$diet=="SD")
example.SD_Dbp<-subset(example_Dbp,example_Dbp$diet=="SD")$count

#Test models
#sigEmax
mod_example.SD_Dbp_sigmoid <- suppressMessages(fitMod(dose=timevector_SD, resp=example.SD_Dbp, model="sigEmax"))
AIC(mod_example.SD_Dbp_sigmoid)
#81.63901

#beta
mod_example.SD_Dbp_beta <- suppressMessages(fitMod(dose=timevector_SD, resp=example.SD_Dbp, model="betaMod"))
AIC(mod_example.SD_Dbp_beta)
#88.70041

#Since the AIC is smaller for the sigEmax model, we will continue with it
#Extract variables
sd_example.SD_Dbp <- sqrt(mod_example.SD_Dbp_sigmoid$RSS/mod_example.SD_Dbp_sigmoid$df)
theta_example.SD_Dbp <- unname(coef(mod_example.SD_Dbp_sigmoid))

#Model function
Dbp.SD_modfunction<-function(t){
  count<-modelfunction_sigmoid(t,theta_example.SD_Dbp)
  return(count)
}

#First derivative and absolute value of first derivative
Dbp.SD_modderiv<-function(t){
  count<-modelderiv_sigmoid(t,theta_example.SD_Dbp)
  return(count)
}
#absolute value of first derivative
Dbp.SD_modderiv_abs<-function(t){
  count<-modelderiv_sigmoid(t,theta_example.SD_Dbp)
  return(abs(count))
}



#Perform analysis
set.seed(24)
#draw seeds for inner bootstrap
seeds_example.SD_Dbp<-sample(1:100000000,B1,replace=F)

outerboot_example.SD_Dbp<-bootstrap(theta=theta_example.SD_Dbp,sd=sd_example.SD_Dbp,B_out=B1,tvector=timevector_SD,model_name = "sigEmax")
crit.val.boot_example.SD_Dbp<-crit.val.boot(theta = theta_example.SD_Dbp,B_out=B1,B_in=B2,outerboot_example.SD_Dbp,model_name = "sigEmax",tvector=timevector_SD,seeds=seeds_example.SD_Dbp)
c_example.SD_Dbp<-crit.val(crit.val.boot =crit.val.boot_example.SD_Dbp)
conf_example.SD_Dbp<-conf.bands(theta = theta_example.SD_Dbp,c=c_example.SD_Dbp,outerboot=outerboot_example.SD_Dbp,model_name = "sigEmax")
decision_example.SD_Dbp<-Test.decision(conf= conf_example.SD_Dbp,lambda=lambda_45weeks)
decision_example.SD_Dbp$result_sign
#1

decision_example.SD_Dbp$result_relev
#1

relev_example.SD_Dbp<-t_points_change(decision_example.SD_Dbp$timeframe_relev)
#beginning       end 
#35.5      45.0 

#relevant
(model_sigmoid(relev_example.SD_Dbp[1],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3],theta_example.SD_Dbp[4])-model_sigmoid(relev_example.SD_Dbp[2],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3],theta_example.SD_Dbp[4]))
#2.996189  
(model_sigmoid(relev_example.SD_Dbp[1],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3],theta_example.SD_Dbp[4])-model_sigmoid(relev_example.SD_Dbp[2],theta_example.SD_Dbp[1],theta_example.SD_Dbp[2],theta_example.SD_Dbp[3],theta_example.SD_Dbp[4]))/(relev_example.SD_Dbp[2]-relev_example.SD_Dbp[1])
#0.3153883
(relev_example.SD_Dbp[2]-relev_example.SD_Dbp[1])
#9.5 

########################################################
####Confidence intervals for time frames of interest####
########################################################
#Number of first level bootstrap runs
B3<-500
#if(file.exists("./case_study/Aging_CI.RData")){
#  load("./case_study/Aging_CI.RData")
#} else{
####WD case####
#create seeds
set.seed(300)
seeds_ci_Dbp.WD<-sample(1:100000000,B1*B3,replace=F)

#three level bootstrap
T_CI_boot_Dbp.WD<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_example.WD_Dbp,sd=sd_example.WD_Dbp,model_name="sigEmax",seeds=seeds_ci_Dbp.WD,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Dbp.WD<-t_CI_quantile(T_CI_boot_Dbp.WD,n_changepoints_sign=2,n_changepoints_relev=2)

####SD case####
#create seeds
set.seed(301)
seeds_ci_Dbp.SD<-sample(1:100000000,B1*B3,replace=F)

#three level bootstrap
T_CI_boot_Dbp.SD<-t_CI_boot(B3=B3,B_out=B1,B_in=B2,tvector=timevector,theta=theta_example.SD_Dbp,sd=sd_example.SD_Dbp,model_name="sigEmax",seeds=seeds_ci_Dbp.SD,lambda=lambda_45weeks)

#calculate quantiles
T_CI_quantiles_Dbp.SD<-t_CI_quantile(T_CI_boot_Dbp.SD,n_changepoints_sign=2,n_changepoints_relev=2)

####Difference####
#calculate quantiles
T_CI_diff<-t_CI_quantile_diff(decision_boot1=T_CI_boot_Dbp.SD,decision_boot2 =T_CI_boot_Dbp.WD,n_changepoints_relev = 2)
#save(seeds_ci_Dbp.WD,T_CI_boot_Dbp.WD,T_CI_quantiles_Dbp.WD,seeds_ci_Dbp.SD,T_CI_boot_Dbp.SD,T_CI_quantiles_Dbp.SD,T_CI_diff
#,file="./case_study/Aging_CI.RData")
#}
####Save Working directory####
save.image(file="./case_study/case_study_aging_WDM.RData")
