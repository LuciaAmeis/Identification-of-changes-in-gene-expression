load("./base/base_WDM.RData")
load("./data_preparation/data_preparation_WDM.RData")

#Paralelization
n.cores<-parallel::detectCores()-1
my.cluster<-parallel::makeCluster(
  n.cores,
  type="PSOCK"
)
######################
####Some variables####
######################
alpha <- 0.05 #significance level of the test
B1 <- 500 # "outer" bootstrap for critical value (=quantile)
B2 <- 25 # "inner" bootstrap for standard error
# here we construct a grid 


epsilon <- 0.1
grid <- seq(0.1,45,epsilon) #45 because we regard 48 weeks starting at week 3
                            #and we will transform age to time on study
                            #Please change if another data set is regarded

#Some specific parameters used for the analysis later
timepoints <- unique(example.WD_Cd163$time) #different time points
timevector<-example.WD_Cd163$time #vector of time points
scal<-max(timevector)*1.2

#Different lambda
lambda_45weeks<-lambda.fct(tdiff=45,lambda_absolute = log2(1.5)) #45 weeks on study

lambda_3weeks<-lambda.fct(tdiff=3,lambda_absolute = log2(1.5)) #3 weeks 
lambda_9weeks<-lambda.fct(tdiff=9,lambda_absolute = log2(1.5)) #9 weeks  
lambda_15weeks<-lambda.fct(tdiff=15,lambda_absolute = log2(1.5)) #15 weeks  
lambda_21weeks<-lambda.fct(tdiff=21,lambda_absolute = log2(1.5)) #21 weeks 
lambda_27weeks<-lambda.fct(tdiff=27,lambda_absolute = log2(1.5)) #27.5 weeks  
lambda_33weeks<-lambda.fct(tdiff=33,lambda_absolute = log2(1.5)) #33 weeks  
lambda_39weeks<-lambda.fct(tdiff=39,lambda_absolute = log2(1.5)) #39 weeks  

lambda_27_5_weeks<-lambda.fct(tdiff=27.5,lambda_absolute = log2(1.5)) #33 weeks  
######################
####Analysis Cd163####
######################
#Monotonically decreasing example
data_example.d <- example.WD_Cd163$count
#fit the model and the standard deviation
#sigmoid
mod_example.d_sigmoid <- suppressMessages(fitMod(dose=timevector, resp=data_example.d, model="sigEmax"))
AIC(mod_example.d_sigmoid)
#90.37685

#beta
mod_example.d_beta <- suppressMessages(fitMod(dose=timevector, resp=data_example.d, model="betaMod"))
AIC(mod_example.d_beta)
#98.17804

#Since the AIC is smaller for the sigEmax model, we will continue with it
#Extract variables
sd_example.d <- sqrt(mod_example.d_sigmoid$RSS/mod_example.d_sigmoid$df)
theta_example.d <- unname(coef(mod_example.d_sigmoid))

#Model function
Cd163_modfunction<-function(t){
  count<-modelfunction_sigmoid(t,theta_example.d)
  return(count)
}

#First derivative and absolute value of first derivative
Cd163_modderiv<-function(t){
  count<-modelderiv_sigmoid(t,theta_example.d)
  return(count)
}

Cd163_modderiv_abs<-function(t){
  count<-modelderiv_sigmoid(t,theta_example.d)
  return(abs(count))
}

#Perform analysis
set.seed(1)
#draw seeds for inner bootstrap
seeds_example.d<-sample(1:100000000,B1,replace=F)

outerboot_example.d<-bootstrap(theta=theta_example.d,sd=sd_example.d,B_out=B1,tvector=timevector,model_name = "sigEmax")
crit.val.boot_example.d<-crit.val.boot(theta = theta_example.d,B_out=B1,B_in=B2,outerboot_example.d,model_name = "sigEmax",tvector=timevector,seeds=seeds_example.d)
c_example.d<-crit.val(crit.val.boot =crit.val.boot_example.d)
conf_example.d<-conf.bands(theta = theta_example.d,c=c_example.d,outerboot=outerboot_example.d,model_name = "sigEmax")
decision_example.d<-Test.decision(conf= conf_example.d,lambda=lambda_45weeks)
decision_example.d$result_sign
decision_example.d$timeframe_sign
decision_example.d$result_relev
decision_example.d$timeframe_relev

#check for beginning and end
sign_example.d<-t_points_change(decision_example.d$timeframe_sign)
#beginning       end 
#14.8            20.7 
relev_example.d<-t_points_change(decision_example.d$timeframe_relev)
#beginning       end 
#15.1           20.3 

#Slopes
#significant
(model_sigmoid(sign_example.d[1],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4])-model_sigmoid(sign_example.d[2],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4]))
#1.295353
(model_sigmoid(sign_example.d[1],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4])-model_sigmoid(sign_example.d[2],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4]))/(sign_example.d[2]-sign_example.d[1])
#0.2195513  
(sign_example.d[2]-sign_example.d[1])
#5.9

#relevant
(model_sigmoid(relev_example.d[1],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4])-model_sigmoid(relev_example.d[2],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4]))
#1.189245 
(model_sigmoid(relev_example.d[1],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4])-model_sigmoid(relev_example.d[2],theta_example.d[1],theta_example.d[2],theta_example.d[3],theta_example.d[4]))/(relev_example.d[2]-relev_example.d[1])
#0.2287009  
(relev_example.d[2]-relev_example.d[1])
#5.2


#Decision for half the study time
decision_example.d_27_5w<-Test.decision(conf= conf_example.d,lambda=lambda_27_5_weeks)

#check for beginning and end
relev_example.d_27_5w<-t_points_change(decision_example.d_27_5w$timeframe_relev)
#beginning       end 
#15.3           20.1





#Decision for larger lambdas
#39
decision_example.d_39w<-Test.decision(conf= conf_example.d,lambda=lambda_39weeks)

#check for beginning and end
relev_example.d_39w<-t_points_change(decision_example.d_39w$timeframe_relev)
#beginning       end 
#15.1           20.2 


#33
decision_example.d_33w<-Test.decision(conf= conf_example.d,lambda=lambda_33weeks)

#check for beginning and end
relev_example.d_33w<-t_points_change(decision_example.d_33w$timeframe_relev)
#beginning       end 
#15.2           20.2


#27
decision_example.d_27w<-Test.decision(conf= conf_example.d,lambda=lambda_27weeks)

#check for beginning and end
relev_example.d_27w<-t_points_change(decision_example.d_27w$timeframe_relev)
#beginning       end 
#15.3           20.1



#21
decision_example.d_21w<-Test.decision(conf= conf_example.d,lambda=lambda_21weeks)

#check for beginning and end
relev_example.d_21w<-t_points_change(decision_example.d_21w$timeframe_relev)
#beginning       end 
#15.4           19.9


#15
decision_example.d_15w<-Test.decision(conf= conf_example.d,lambda=lambda_15weeks)

#check for beginning and end
relev_example.d_15w<-t_points_change(decision_example.d_15w$timeframe_relev)
#beginning       end 
#15.6           19.7

#9
decision_example.d_9w<-Test.decision(conf= conf_example.d,lambda=lambda_9weeks)

#check for beginning and end
relev_example.d_9w<-t_points_change(decision_example.d_9w$timeframe_relev)
#beginning       end 
#16.0           19.1

#3
decision_example.d_3w<-Test.decision(conf= conf_example.d,lambda=lambda_3weeks)
#NA


###########################################
####Analysis Fam83a (Used in Section 3)####
###########################################
#Monotonically incressing example
data_example.i <- example.WD_Fam83a$count
# fit the model and the standard deviation
#sigmoid
mod_example.i_sigmoid <- suppressMessages(fitMod(dose=timevector, resp=data_example.i, model="sigEmax"))
AIC(mod_example.i_sigmoid)
#87.25018

#beta
mod_example.i_beta <- suppressMessages(fitMod(dose=timevector, resp=data_example.i, model="betaMod"))
AIC(mod_example.i_beta)
#85.67384

#Since the AIC is smaller for the beta model, we will continue with it

#Extract variables
sd_example.i <- sqrt(mod_example.i_beta$RSS/mod_example.i_beta$df)
theta_example.i <- unname(coef(mod_example.i_beta))

#Model function
Fam83a_modfunction<-function(t){
  count<-modelfunction_beta(t,theta_example.i)
  return(count)
}


#First derivative and absolute value of first derivative
Fam83a_modderiv<-function(t){
  count<-modelderiv_beta(t,theta_example.i)
  return(count)
}

Fam83a_modderiv_abs<-function(t){
  count<-modelderiv_beta(t,theta_example.i)
  return(abs(count))
}

#perform analysis
set.seed(2)
#draw seeds for inner bootstrap
seeds_example.i<-sample(1:100000000,B1,replace=F)

outerboot_example.i<-bootstrap(theta=theta_example.i,sd=sd_example.i,B_out=B1,tvector=timevector,model_name = "betaMod")
crit.val.boot_example.i<-crit.val.boot(theta = theta_example.i,B_out=B1,B_in=B2,outerboot_example.i,model_name = "betaMod",tvector=timevector,seeds=seeds_example.i)
c_example.i<-crit.val(crit.val.boot =crit.val.boot_example.i)
conf_example.i<-conf.bands(theta = theta_example.i,c=c_example.i,outerboot=outerboot_example.i,model_name = "betaMod")
decision_example.i<-Test.decision(conf= conf_example.i,lambda=lambda_45weeks)
decision_example.i$result_sign
decision_example.i$timeframe_sign
decision_example.i$result_relev
decision_example.i$timeframe_relev

#check for beginning and end
sign_example.i<-t_points_change(decision_example.i$timeframe_sign)
#beginning       end 
#0.3            30.1 
relev_example.i<-t_points_change(decision_example.i$timeframe_relev)
#beginning       end 
#0.3             24.9 

#Slopes
#significan
(model_beta(sign_example.i[2],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4])-model_beta(sign_example.i[1],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4]))
#2.528939 
(model_beta(sign_example.i[2],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4])-model_beta(sign_example.i[1],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4]))/(sign_example.i[2]-sign_example.i[1])
#0.08486374 
(sign_example.i[2]-sign_example.i[1])
#29.8

#relevant
(model_beta(relev_example.i[2],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4])-model_beta(relev_example.i[1],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4]))
#2.379744
(model_beta(relev_example.i[2],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4])-model_beta(relev_example.i[1],theta_example.i[1],theta_example.i[2],theta_example.i[3],theta_example.i[4]))/(relev_example.i[2]-relev_example.i[1])
#0.09673755  
(relev_example.i[2]-relev_example.i[1])
#24.6


#Decision for larger lambdas
#39
decision_example.i_39w<-Test.decision(conf= conf_example.i,lambda=lambda_39weeks)

#check for beginning and end
relev_example.i_39w<-t_points_change(decision_example.i_39w$timeframe_relev)
#beginning       end 
#0.3            23.6


#33
decision_example.i_33w<-Test.decision(conf= conf_example.i,lambda=lambda_33weeks)

#check for beginning and end
relev_example.i_33w<-t_points_change(decision_example.i_33w$timeframe_relev)
#beginning       end 
#0.3            21.5


#27
decision_example.i_27w<-Test.decision(conf= conf_example.i,lambda=lambda_27weeks)

#check for beginning and end
relev_example.i_27w<-t_points_change(decision_example.i_27w$timeframe_relev)
#beginning       end 
#0.3             18.3 



#21
decision_example.i_21w<-Test.decision(conf= conf_example.i,lambda=lambda_21weeks)

#check for beginning and end
relev_example.i_21w<-t_points_change(decision_example.i_21w$timeframe_relev)
#beginning       end 
#0.3             14.5 



#15
decision_example.i_15w<-Test.decision(conf= conf_example.i,lambda=lambda_15weeks)

#check for beginning and end
relev_example.i_15w<-t_points_change(decision_example.i_15w$timeframe_relev)
#beginning       end 
#0.3             10.5 


#9
decision_example.i_9w<-Test.decision(conf= conf_example.i,lambda=lambda_9weeks)

#check for beginning and end
relev_example.i_9w<-t_points_change(decision_example.i_9w$timeframe_relev)
#beginning       end 
#0.4             6.0 


#3
decision_example.i_3w<-Test.decision(conf= conf_example.i,lambda=lambda_3weeks)
#NA


####Save Working directory####
save.image(file="./case_study/case_study_WDM.RData")
