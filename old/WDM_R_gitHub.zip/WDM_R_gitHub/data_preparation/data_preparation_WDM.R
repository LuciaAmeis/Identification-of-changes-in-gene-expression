################
####Data Set####
################
#Preprocessing as done in Ghallab et al #
#load("RNASeq_high_fat_gene_level_summary.RData")
#
#
#colData(gse)$diet <- factor(colData(gse)$diet, levels = c("SD", "HFD"))       #
#levels(colData(gse)$diet) <- c("SD", "WD")                                    #
#colData(gse)$diet_weeks <- paste0(colData(gse)$diet,"_", colData(gse)$weeks)  #
#                                                                              #
#                                                                              #
#SD_weeks <- unique(colData(gse)$weeks[colData(gse)$diet == "SD"])             #
#WD_weeks <- unique(colData(gse)$weeks[colData(gse)$diet == "WD"])             #
#                                                                              #
#colData(gse)$diet_weeks <- factor(colData(gse)$diet_weeks, levels =           #
#                                    c(paste0("SD_", SD_weeks),                #
#                                      paste0("WD_", WD_weeks)))               #
#                                                                              #
#colData(gse)$weeks <- factor(colData(gse)$weeks)                              #
#colData(gse)$names <- gsub("HFD", "WD", colData(gse)$names)                   #
#rownames(colData(gse)) <- colData(gse)$names                                  #
#                                                                              #
# dds <- DESeqDataSet(gse, design = ~ diet_weeks)                              #
# keep_ind <- rowSums(counts(dds)) >=10                                        #
# dds <- dds[keep_ind, ]                                                       #
#                                                                              #
# dds <- DESeq(dds)                                                            #
# save(dds, file = "020_dds.RData")                                            #
####

#load original data set
load("./data/RNASeq_high_fat_gene_level_summary.RData")
#load Deseq object
load("./data/020_dds.RData")

#variance stabilization 
vsd <- vst(dds, blind = FALSE)


#Gene examples
#extract monotonically falling example
normalized_Cd163<-vsd[which(rowData(vsd)$gene_name=="Cd163"),]

#create data set with gene specific count data
counts.gen_Cd163<-as.numeric(assay(normalized_Cd163,1))
time<-as.numeric(colData(gse)$weeks) #we use the original weeks since they were 
#were changed to 1-9 in the vsd object
time_beginningofstudy<-time-3
mouse<-as.factor(colData(vsd)$mouse)
diet<-as.factor(colData(vsd)$diet)


example_Cd163<-data.frame(
  "count"= counts.gen_Cd163,
  "time"=time_beginningofstudy,
  "mouse"=mouse,
  "diet"=diet
)

#restrict to WD case
example.WD_Cd163<-subset(example_Cd163,example_Cd163$diet=="WD")


#ectract monotonically increasing example
normalized_Fam83a<-vsd[which(rowData(vsd)$gene_name=="Fam83a"),]

#create data set with gene specific count data 
counts.gen_Fam83a<-as.numeric(assay(normalized_Fam83a,1))

example_Fam83a<-data.frame(
  "count"= counts.gen_Fam83a,
  "time"=time_beginningofstudy,
  "mouse"=mouse,
  "diet"=diet
)

example.WD_Fam83a<-subset(example_Fam83a,example_Fam83a$diet=="WD")



#extracting gene for aging analysis
normalized_Dbp<-vsd[which(rowData(vsd)$gene_name=="Dbp"),]

#create data set with gene specific count data
counts.gen_Dbp<-as.numeric(assay(normalized_Dbp,1))
time<-as.numeric(colData(gse)$weeks) #we use the original weeks since they were 


example_Dbp<-data.frame(
  "count"= counts.gen_Dbp,
  "time"=time_beginningofstudy,
  "mouse"=mouse,
  "diet"=diet
)

####Save Working directory####
save.image(file="./data_preparation/data_preparation_WDM.RData")

